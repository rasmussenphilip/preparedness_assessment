# ==============================================================================
# 09_joint_monte_carlo_uncertainty.R
#
# PURPOSE
# Propagate the four retained uncertainty sources jointly through the
# Preparedness-challenge balance:
#
# 1. IRT factor-score estimation uncertainty
# 2. Contextual Index component weighting
# 3. Preparedness-capacity versus context weighting
# 4. Challenge Index component weighting
#
# This is a post-main-analysis uncertainty analysis. It does not alter the
# deterministic results produced by Scripts 01-08.
#
# INPUTS
# data/exported/raw_irt_factor_scores_long.csv
# results/indices/contextual_diagnostics/contextual_component_breakdown.csv
# results/indices/challenge_diagnostics/challenge_component_breakdown.csv
#
# OUTPUTS
# results/sensitivity/monte_carlo_sensitivity/country_iterations.csv
# results/sensitivity/monte_carlo_sensitivity/joint_monte_carlo_assumptions.csv
# ==============================================================================

suppressPackageStartupMessages({
  library(dplyr)
  library(tidyr)
  library(readr)
  library(tibble)
})

# ==============================================================================
# 1. Settings and paths
# ==============================================================================

n_iterations <- 10000L
batch_size <- 250L
random_seed <- 12345L

context_dirichlet_alpha <- 15
challenge_dirichlet_alpha <- 15

preparedness_beta_alpha <- 5
preparedness_beta_beta <- 5
preparedness_weight_min <- 0.25
preparedness_weight_max <- 0.75

scale_lower <- 0.05
scale_upper <- 0.95

required_diseases <- c(
  "asf",
  "aiv_poultry"
)

context_components <- c(
  "gdp_scaled",
  "governance_scaled",
  "education_scaled",
  "health_scaled"
)

challenge_components <- c(
  "livestock_population_scaled",
  "livestock_density_scaled",
  "live_animal_imports_scaled",
  "wildlife_abundance_scaled"
)

irt_file <- file.path(
  "data",
  "exported",
  "raw_irt_factor_scores_long.csv"
)

context_file <- file.path(
  "results",
  "indices",
  "contextual_diagnostics",
  "contextual_component_breakdown.csv"
)

challenge_file <- file.path(
  "results",
  "indices",
  "challenge_diagnostics",
  "challenge_component_breakdown.csv"
)

output_dir <- file.path(
  "results",
  "sensitivity",
  "monte_carlo_sensitivity"
)

country_iteration_file <- file.path(
  output_dir,
  "country_iterations.csv"
)

assumptions_file <- file.path(
  output_dir,
  "joint_monte_carlo_assumptions.csv"
)

dir.create(
  output_dir,
  recursive = TRUE,
  showWarnings = FALSE
)

# ==============================================================================
# 2. Helpers
# ==============================================================================

read_required_csv <- function(path) {
  if (!file.exists(path)) {
    stop(
      "Required input file was not found: ",
      path,
      call. = FALSE
    )
  }

  read_csv(
    path,
    show_col_types = FALSE,
    progress = FALSE
  )
}

check_required_columns <- function(
    data,
    required_columns,
    object_name
) {
  missing_columns <- setdiff(
    required_columns,
    names(data)
  )

  if (length(missing_columns) > 0L) {
    stop(
      object_name,
      " is missing required columns: ",
      paste(missing_columns, collapse = ", "),
      call. = FALSE
    )
  }
}

check_unique_keys <- function(
    data,
    keys,
    object_name
) {
  duplicates <- data %>%
    count(
      across(
        all_of(keys)
      )
    ) %>%
    filter(
      n != 1L
    )

  if (nrow(duplicates) > 0L) {
    stop(
      object_name,
      " must contain exactly one row per ",
      paste(keys, collapse = " × "),
      ".",
      call. = FALSE
    )
  }
}

standardize_country_name <- function(x) {
  recode(
    as.character(x),
    "Czech Republic" = "Czechia",
    "Turkiye" = "Türkiye",
    "Turkey" = "Türkiye",
    "Slovak Republic" = "Slovakia",
    "Russian Federation" = "Russia",
    .default = as.character(x)
  )
}

rank_scale <- function(
    x,
    lower = scale_lower,
    upper = scale_upper
) {
  if (
    anyNA(x) ||
      any(!is.finite(x))
  ) {
    stop(
      "rank_scale() cannot process missing or non-finite values.",
      call. = FALSE
    )
  }

  n <- length(x)

  if (n < 2L) {
    stop(
      "At least two observations are required for rank scaling.",
      call. = FALSE
    )
  }

  if (length(unique(x)) == 1L) {
    return(
      rep(
        (lower + upper) / 2,
        n
      )
    )
  }

  lower +
    (upper - lower) *
    (rank(x, ties.method = "average") - 1) /
    (n - 1)
}

rank_scale_matrix <- function(x) {
  scaled <- apply(
    x,
    2,
    rank_scale
  )

  if (is.null(dim(scaled))) {
    scaled <- matrix(
      scaled,
      nrow = nrow(x),
      ncol = 1L
    )
  }

  scaled
}

sample_dirichlet <- function(
    n,
    alpha
) {
  alpha <- as.numeric(alpha)

  draws <- matrix(
    rgamma(
      n * length(alpha),
      shape = rep(
        alpha,
        each = n
      ),
      rate = 1
    ),
    nrow = n,
    ncol = length(alpha)
  )

  draws /
    rowSums(draws)
}

# ==============================================================================
# 3. Read and validate inputs
# ==============================================================================

irt_scores <- read_required_csv(
  irt_file
)

context_data <- read_required_csv(
  context_file
)

challenge_data <- read_required_csv(
  challenge_file
)

check_required_columns(
  irt_scores,
  c(
    "country_name",
    "disease",
    "model",
    "score",
    "score_se"
  ),
  "raw_irt_factor_scores_long.csv"
)

check_required_columns(
  context_data,
  c(
    "country_name",
    context_components
  ),
  "contextual_component_breakdown.csv"
)

check_required_columns(
  challenge_data,
  c(
    "country_name",
    "disease",
    challenge_components
  ),
  "challenge_component_breakdown.csv"
)

irt_scores <- irt_scores %>%
  transmute(
    country_name =
      standardize_country_name(
        country_name
      ),
    disease =
      as.character(
        disease
      ),
    model =
      as.character(
        model
      ),
    score =
      as.numeric(
        score
      ),
    score_se =
      as.numeric(
        score_se
      )
  ) %>%
  filter(
    model == "overall_preparedness",
    disease %in% required_diseases
  ) %>%
  select(
    -model
  )

context_data <- context_data %>%
  mutate(
    country_name =
      standardize_country_name(
        country_name
      )
  )

challenge_data <- challenge_data %>%
  mutate(
    country_name =
      standardize_country_name(
        country_name
      ),
    disease =
      as.character(
        disease
      )
  ) %>%
  filter(
    disease %in% required_diseases
  )

check_unique_keys(
  irt_scores,
  c(
    "country_name",
    "disease"
  ),
  "IRT factor scores"
)

check_unique_keys(
  context_data,
  "country_name",
  "Context component data"
)

check_unique_keys(
  challenge_data,
  c(
    "country_name",
    "disease"
  ),
  "Challenge component data"
)

country_order <- context_data %>%
  arrange(
    country_name
  ) %>%
  pull(
    country_name
  )

n_countries <- length(
  country_order
)

if (n_countries < 2L) {
  stop(
    "At least two countries are required.",
    call. = FALSE
  )
}

context_matrix <- context_data %>%
  right_join(
    tibble(
      country_name = country_order
    ),
    by = "country_name"
  ) %>%
  arrange(
    match(
      country_name,
      country_order
    )
  ) %>%
  select(
    all_of(
      context_components
    )
  ) %>%
  as.matrix()

if (
  anyNA(context_matrix) ||
    any(!is.finite(context_matrix)) ||
    any(context_matrix <= 0)
) {
  stop(
    "Context component values must be complete, finite, and positive.",
    call. = FALSE
  )
}

missing_irt_countries <- setdiff(
  expand_grid(
    country_name = country_order,
    disease = required_diseases
  ) %>%
    transmute(
      key = paste(
        country_name,
        disease,
        sep = "||"
      )
    ) %>%
    pull(
      key
    ),
  irt_scores %>%
    transmute(
      key = paste(
        country_name,
        disease,
        sep = "||"
      )
    ) %>%
    pull(
      key
    )
)

if (
  length(
    missing_irt_countries
  ) > 0L
) {
  stop(
    "IRT factor scores are incomplete for the required country × disease combinations.",
    call. = FALSE
  )
}

missing_challenge_countries <- setdiff(
  expand_grid(
    country_name = country_order,
    disease = required_diseases
  ) %>%
    transmute(
      key = paste(
        country_name,
        disease,
        sep = "||"
      )
    ) %>%
    pull(
      key
    ),
  challenge_data %>%
    transmute(
      key = paste(
        country_name,
        disease,
        sep = "||"
      )
    ) %>%
    pull(
      key
    )
)

if (
  length(
    missing_challenge_countries
  ) > 0L
) {
  stop(
    "Challenge component data are incomplete for the required country × disease combinations.",
    call. = FALSE
  )
}

# ==============================================================================
# 4. Generate common structural draws
# ==============================================================================

set.seed(
  random_seed
)

context_weight_draws <- sample_dirichlet(
  n_iterations,
  rep(
    context_dirichlet_alpha,
    length(
      context_components
    )
  )
)

challenge_weight_draws <- sample_dirichlet(
  n_iterations,
  rep(
    challenge_dirichlet_alpha,
    length(
      challenge_components
    )
  )
)

preparedness_capacity_weight_draws <-
  preparedness_weight_min +
  (
    preparedness_weight_max -
      preparedness_weight_min
  ) *
  rbeta(
    n_iterations,
    shape1 = preparedness_beta_alpha,
    shape2 = preparedness_beta_beta
  )

# ==============================================================================
# 5. Joint Monte Carlo propagation
# ==============================================================================

results <- list()
result_index <- 1L

for (
  disease_code in required_diseases
) {
  disease_irt <- irt_scores %>%
    filter(
      disease == disease_code
    ) %>%
    right_join(
      tibble(
        country_name = country_order
      ),
      by = "country_name"
    ) %>%
    arrange(
      match(
        country_name,
        country_order
      )
    )

  if (
    anyNA(disease_irt$score) ||
      anyNA(disease_irt$score_se) ||
      any(!is.finite(disease_irt$score)) ||
      any(!is.finite(disease_irt$score_se)) ||
      any(disease_irt$score_se < 0)
  ) {
    stop(
      "Missing or invalid IRT score/SE for ",
      disease_code,
      ".",
      call. = FALSE
    )
  }

  disease_challenge <- challenge_data %>%
    filter(
      disease == disease_code
    ) %>%
    right_join(
      tibble(
        country_name = country_order
      ),
      by = "country_name"
    ) %>%
    arrange(
      match(
        country_name,
        country_order
      )
    )

  challenge_component_matrix <- disease_challenge %>%
    select(
      all_of(
        challenge_components
      )
    ) %>%
    as.matrix()

  if (
    anyNA(challenge_component_matrix) ||
      any(!is.finite(challenge_component_matrix)) ||
      any(challenge_component_matrix <= 0)
  ) {
    stop(
      "Invalid Challenge component values for ",
      disease_code,
      ".",
      call. = FALSE
    )
  }

  for (
    batch_start in seq(
      1L,
      n_iterations,
      by = batch_size
    )
  ) {
    batch_end <- min(
      n_iterations,
      batch_start +
        batch_size -
        1L
    )

    batch_iterations <- batch_start:batch_end
    batch_n <- length(
      batch_iterations
    )

    latent_draws <- matrix(
      rnorm(
        n_countries *
          batch_n,
        mean = rep(
          disease_irt$score,
          times = batch_n
        ),
        sd = rep(
          disease_irt$score_se,
          times = batch_n
        )
      ),
      nrow = n_countries,
      ncol = batch_n
    )

    preparedness_capacity_scaled <-
      rank_scale_matrix(
        latent_draws
      )

    context_weights <-
      context_weight_draws[
        batch_iterations,
        ,
        drop = FALSE
      ]

    contextual_scaled <- exp(
      log(
        context_matrix
      ) %*%
        t(
          context_weights
        )
    )

    preparedness_capacity_weight <-
      preparedness_capacity_weight_draws[
        batch_iterations
      ]

    preparedness_capacity_weight_matrix <- matrix(
      preparedness_capacity_weight,
      nrow = n_countries,
      ncol = batch_n,
      byrow = TRUE
    )

    context_adjusted_preparedness_matrix <-
      100 *
      (
        preparedness_capacity_scaled ^
          preparedness_capacity_weight_matrix
      ) *
      (
        contextual_scaled ^
          (
            1 -
              preparedness_capacity_weight_matrix
          )
      )

    challenge_weights <-
      challenge_weight_draws[
        batch_iterations,
        ,
        drop = FALSE
      ]

    challenge_index_matrix <-
      100 *
      exp(
        log(
          challenge_component_matrix
        ) %*%
          t(
            challenge_weights
          )
      )

    country_grid <- expand_grid(
      country_index =
        seq_len(
          n_countries
        ),
      batch_column =
        seq_len(
          batch_n
        )
    )

    row_index <- as.integer(
      country_grid$country_index
    )

    column_index <- as.integer(
      country_grid$batch_column
    )

    matrix_index <- cbind(
      row_index,
      column_index
    )

    results[[result_index]] <-
      country_grid %>%
      transmute(
        iteration =
          batch_iterations[
            column_index
          ],
        country_name =
          country_order[
            row_index
          ],
        disease =
          disease_code,
        preparedness_capacity_scaled =
          preparedness_capacity_scaled[
            matrix_index
          ],
        contextual_scaled =
          contextual_scaled[
            matrix_index
          ],
        preparedness_capacity_weight =
          preparedness_capacity_weight[
            column_index
          ],
        context_adjusted_preparedness =
          context_adjusted_preparedness_matrix[
            matrix_index
          ],
        challenge_index =
          challenge_index_matrix[
            matrix_index
          ],
        preparedness_challenge_balance =
          context_adjusted_preparedness_matrix[
            matrix_index
          ] -
          challenge_index_matrix[
            matrix_index
          ]
      )

    result_index <-
      result_index +
      1L
  }
}

country_iterations <- bind_rows(
  results
) %>%
  arrange(
    iteration,
    factor(
      disease,
      levels = required_diseases
    ),
    country_name
  )

# ==============================================================================
# 6. Validate and export
# ==============================================================================

expected_rows <-
  n_iterations *
  n_countries *
  length(
    required_diseases
  )

if (
  nrow(
    country_iterations
  ) != expected_rows
) {
  stop(
    "Unexpected number of rows in country_iterations.csv.",
    call. = FALSE
  )
}

if (
  anyNA(
    country_iterations
  ) ||
    any(
      !is.finite(
        as.matrix(
          country_iterations[
            c(
              "preparedness_capacity_scaled",
              "contextual_scaled",
              "preparedness_capacity_weight",
              "context_adjusted_preparedness",
              "challenge_index",
              "preparedness_challenge_balance"
            )
          ]
        )
      )
    )
) {
  stop(
    "Monte Carlo output contains missing or non-finite analytical values.",
    call. = FALSE
  )
}

write_csv(
  country_iterations,
  country_iteration_file
)

write_csv(
  tibble(
    uncertainty_source = c(
      "IRT estimation uncertainty",
      "Context Index weighting",
      "Context adjustment",
      "Challenge Index weighting"
    ),
    treatment = c(
      "Normal draw centered on MAP factor score using the posterior factor-score SE; rank-scaled within disease and iteration to 0.05-0.95",
      "Dirichlet(15,15,15,15) weights applied to the four bounded Context components using a weighted geometric mean",
      "Beta(5,5) draw rescaled to a Preparedness-capacity weight of 0.25-0.75; the Context weight is its complement",
      "Dirichlet(15,15,15,15) weights applied to the four bounded Challenge components using a weighted geometric mean"
    ),
    n_iterations = n_iterations,
    random_seed = random_seed
  ),
  assumptions_file
)

message(
  "\nJoint Monte Carlo uncertainty analysis completed.\n",
  "Iterations: ",
  n_iterations,
  "\nOutputs:\n",
  "  ",
  country_iteration_file,
  "\n  ",
  assumptions_file,
  "\n"
)
