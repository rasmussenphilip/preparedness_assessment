# ==============================================================================
# 04_irt_models.R
#
# PURPOSE
# Estimate one questionnaire-only Preparedness capacity IRT model for ASF and
# one for avian influenza, with item discrimination fixed at 1.
#
# INPUTS
# data/exported/data_primary_long_asf.csv
# data/exported/irt_model_specification_asf.rds
# data/exported/data_primary_long_aiv_poultry.csv
# data/exported/irt_model_specification_aiv_poultry.rds
#
# OUTPUTS
# data/exported/raw_irt_factor_scores_long.csv
# results/irt_fit_raw/raw_irt_model_summary.csv
# results/irt_fit_raw/raw_irt_item_parameters.csv
# results/irt_fit_raw/irt_model_<disease>_overall_preparedness.rds
# ==============================================================================

suppressPackageStartupMessages({
  library(mirt)
  library(dplyr)
  library(purrr)
  library(tibble)
})

# ==============================================================================
# 1. Settings and paths
# ==============================================================================

export_dir <- file.path("data", "exported")
fit_dir <- file.path("results", "irt_fit_raw")

ncycles <- 2000L
score_method <- "MAP"

model_name <- "overall_preparedness"
model_label <- "Preparedness capacity"

dir.create(
  export_dir,
  recursive = TRUE,
  showWarnings = FALSE
)

dir.create(
  fit_dir,
  recursive = TRUE,
  showWarnings = FALSE
)

# ==============================================================================
# 2. Helpers
# ==============================================================================

make_numeric <- function(data) {
  data.frame(
    lapply(
      data,
      function(x) {
        as.numeric(
          as.character(x)
        )
      }
    ),
    check.names = FALSE
  )
}

validate_items <- function(items, model_id) {
  invalid_prefix <- names(items)[
    !startsWith(names(items), "b_") &
      !startsWith(names(items), "g_")
  ]

  if (length(invalid_prefix) > 0L) {
    stop(
      model_id,
      ": unrecognized item prefixes: ",
      paste(invalid_prefix, collapse = ", "),
      call. = FALSE
    )
  }

  all_missing <- names(items)[
    vapply(
      items,
      function(x) all(is.na(x)),
      logical(1)
    )
  ]

  if (length(all_missing) > 0L) {
    stop(
      model_id,
      ": items contain only missing values: ",
      paste(all_missing, collapse = ", "),
      call. = FALSE
    )
  }

  invariant <- names(items)[
    vapply(
      items,
      function(x) {
        length(
          unique(
            x[!is.na(x)]
          )
        ) < 2L
      },
      logical(1)
    )
  ]

  if (length(invariant) > 0L) {
    stop(
      model_id,
      ": items have no response variation: ",
      paste(invariant, collapse = ", "),
      call. = FALSE
    )
  }

  invisible(TRUE)
}

get_item_types <- function(item_names) {
  ifelse(
    startsWith(item_names, "b_"),
    "2PL",
    "graded"
  )
}

make_fixed_discrimination_values <- function(items, item_types) {
  values <- mirt(
    data = items,
    model = 1,
    itemtype = item_types,
    pars = "values"
  )

  slope_rows <- values$name == "a1"

  if (!any(slope_rows)) {
    stop(
      "No a1 discrimination parameters were found in the mirt parameter table.",
      call. = FALSE
    )
  }

  values$value[slope_rows] <- 1
  values$est[slope_rows] <- FALSE

  values
}

extract_scores <- function(fit, items, country_names, model_id) {
  scores <- fscores(
    fit,
    method = score_method,
    response.pattern = items,
    full.scores = TRUE,
    full.scores.SE = TRUE,
    QMC = FALSE
  ) %>%
    as.data.frame(
      check.names = FALSE
    )

  if (
    nrow(scores) != nrow(items) ||
      ncol(scores) < 2L
  ) {
    stop(
      model_id,
      ": factor-score output must contain scores and posterior standard errors.",
      call. = FALSE
    )
  }

  score_column <- names(scores)[1]

  se_candidates <- names(scores)[
    grepl(
      "(^SE_|_SE$|SE)",
      names(scores),
      ignore.case = TRUE
    )
  ]

  if (length(se_candidates) == 0L) {
    stop(
      model_id,
      ": fscores() did not return a recognizable score-SE column.",
      call. = FALSE
    )
  }

  output <- tibble(
    country_name = country_names,
    score = as.numeric(
      scores[[score_column]]
    ),
    score_se = as.numeric(
      scores[[se_candidates[[1]]]]
    )
  )

  if (
    any(
      !is.finite(output$score) |
        !is.finite(output$score_se) |
        output$score_se < 0
    )
  ) {
    stop(
      model_id,
      ": invalid factor scores or posterior standard errors were returned.",
      call. = FALSE
    )
  }

  output
}

extract_model_summary <- function(
    fit,
    disease,
    n_countries,
    n_items
) {
  marginal_reliability <- tryCatch(
    as.numeric(
      mirt::marginal_rxx(fit)
    )[1],
    error = function(e) NA_real_
  )

  if (
    length(marginal_reliability) == 0L ||
      !is.finite(marginal_reliability)
  ) {
    marginal_reliability <- NA_real_
  }

  tibble(
    disease = disease,
    model = model_name,
    model_label = model_label,
    n_countries = as.integer(n_countries),
    n_items = as.integer(n_items),
    converged = isTRUE(
      fit@OptimInfo$converged
    ),
    marginal_reliability = marginal_reliability
  )
}

extract_item_parameters <- function(
    fit,
    disease,
    model_id
) {
  simplified <- mirt::coef(
    fit,
    simplify = TRUE
  )

  as.data.frame(
    simplified$items,
    check.names = FALSE
  ) %>%
    rownames_to_column(
      "item"
    ) %>%
    mutate(
      disease = disease,
      model = model_name,
      model_label = model_label,
      model_id = model_id,
      .before = 1
    )
}

# ==============================================================================
# 3. Fit one disease-specific Preparedness capacity model
# ==============================================================================

fit_disease_model <- function(
    disease,
    primary_file,
    specification_file
) {
  model_id <- paste(
    disease,
    model_name,
    sep = "_"
  )

  required_files <- c(
    primary_file,
    specification_file
  )

  missing_files <- required_files[
    !file.exists(required_files)
  ]

  if (length(missing_files) > 0L) {
    stop(
      disease,
      ": required files are missing: ",
      paste(missing_files, collapse = ", "),
      call. = FALSE
    )
  }

  primary <- read.csv(
    primary_file,
    stringsAsFactors = FALSE,
    check.names = FALSE
  )

  specification <- readRDS(
    specification_file
  )

  if (!"country_name" %in% names(primary)) {
    stop(
      disease,
      ": primary data must contain country_name.",
      call. = FALSE
    )
  }

  if (anyDuplicated(primary$country_name) > 0L) {
    stop(
      disease,
      ": primary data contain duplicate country names.",
      call. = FALSE
    )
  }

  if (!"overall_items" %in% names(specification)) {
    stop(
      disease,
      ": model specification must contain overall_items.",
      call. = FALSE
    )
  }

  item_names <- specification$overall_items

  if (
    is.null(item_names) ||
      length(item_names) == 0L
  ) {
    stop(
      model_id,
      ": no items are defined.",
      call. = FALSE
    )
  }

  missing_items <- setdiff(
    item_names,
    names(primary)
  )

  if (length(missing_items) > 0L) {
    stop(
      model_id,
      ": required items are missing: ",
      paste(missing_items, collapse = ", "),
      call. = FALSE
    )
  }

  items_all <- primary %>%
    select(
      all_of(item_names)
    ) %>%
    make_numeric()

  usable_rows <- rowSums(
    !is.na(items_all)
  ) > 0L

  if (sum(usable_rows) < 3L) {
    stop(
      model_id,
      ": fewer than three countries have usable responses.",
      call. = FALSE
    )
  }

  items <- items_all[
    usable_rows,
    ,
    drop = FALSE
  ]

  country_names <- primary$country_name[
    usable_rows
  ]

  validate_items(
    items,
    model_id
  )

  item_types <- get_item_types(
    names(items)
  )

  fixed_values <- make_fixed_discrimination_values(
    items,
    item_types
  )

  fit <- mirt(
    data = items,
    model = 1,
    itemtype = item_types,
    pars = fixed_values,
    method = "QMCEM",
    SE = FALSE,
    technical = list(
      NCYCLES = ncycles,
      parallel = TRUE
    )
  )

  if (!isTRUE(fit@OptimInfo$converged)) {
    warning(
      model_id,
      ": model did not satisfy the convergence criterion.",
      call. = FALSE
    )
  }

  fitted_scores <- extract_scores(
    fit,
    items,
    country_names,
    model_id
  )

  scores <- tibble(
    country_name = primary$country_name
  ) %>%
    left_join(
      fitted_scores,
      by = "country_name"
    ) %>%
    mutate(
      disease = disease,
      model = model_name,
      model_label = model_label,
      .after = country_name
    )

  saveRDS(
    fit,
    file.path(
      fit_dir,
      paste0(
        "irt_model_",
        model_id,
        ".rds"
      )
    )
  )

  list(
    scores = scores,
    model_summary = extract_model_summary(
      fit = fit,
      disease = disease,
      n_countries = nrow(items),
      n_items = ncol(items)
    ),
    item_parameters = extract_item_parameters(
      fit = fit,
      disease = disease,
      model_id = model_id
    )
  )
}

# ==============================================================================
# 4. Fit ASF and avian-influenza models
# ==============================================================================

model_results <- list(
  asf = fit_disease_model(
    disease = "asf",
    primary_file = file.path(
      export_dir,
      "data_primary_long_asf.csv"
    ),
    specification_file = file.path(
      export_dir,
      "irt_model_specification_asf.rds"
    )
  ),
  aiv_poultry = fit_disease_model(
    disease = "aiv_poultry",
    primary_file = file.path(
      export_dir,
      "data_primary_long_aiv_poultry.csv"
    ),
    specification_file = file.path(
      export_dir,
      "irt_model_specification_aiv_poultry.rds"
    )
  )
)

# ==============================================================================
# 5. Export retained outputs
# ==============================================================================

factor_scores_long <- bind_rows(
  map(
    model_results,
    "scores"
  )
) %>%
  arrange(
    disease,
    country_name
  )

model_summary <- bind_rows(
  map(
    model_results,
    "model_summary"
  )
) %>%
  arrange(
    disease
  )

item_parameters <- bind_rows(
  map(
    model_results,
    "item_parameters"
  )
) %>%
  arrange(
    disease,
    item
  )

if (nrow(model_summary) != 2L) {
  stop(
    "Expected two fitted-model summary rows.",
    call. = FALSE
  )
}

write.csv(
  factor_scores_long,
  file.path(
    export_dir,
    "raw_irt_factor_scores_long.csv"
  ),
  row.names = FALSE
)

write.csv(
  model_summary,
  file.path(
    fit_dir,
    "raw_irt_model_summary.csv"
  ),
  row.names = FALSE
)

write.csv(
  item_parameters,
  file.path(
    fit_dir,
    "raw_irt_item_parameters.csv"
  ),
  row.names = FALSE
)

message(
  "\nPreparedness capacity IRT estimation completed.\n",
  "Outputs:\n",
  "  ", file.path(export_dir, "raw_irt_factor_scores_long.csv"), "\n",
  "  ", file.path(fit_dir, "raw_irt_model_summary.csv"), "\n",
  "  ", file.path(fit_dir, "raw_irt_item_parameters.csv"), "\n",
  "  fitted model objects in ", fit_dir, "\n"
)
