# ==============================================================================
# 17_plot_sensitivity.R
#
# PURPOSE
# Plot the retained post-main-analysis uncertainty and sensitivity results:
# 1. Country-level distributions of latent Preparedness capacity and
#    Preparedness-challenge balance.
# 2. Variance-based decomposition of uncertainty in country-level profiles and
#    livestock-weighted regional profile composition.
#
# INPUTS
# results/preparedness_challenge/preparedness_challenge_comparison.csv
# results/sensitivity/monte_carlo_sensitivity/country_iterations.csv
# results/sensitivity/monte_carlo_sensitivity/
#   irt_preparedness_capacity_latent_draws.csv
# results/sensitivity/variance_decomposition/
#   profile_variance_decomposition_summary.csv
#
# OUTPUTS
# results/plots/sensitivity/country_preparedness_balance_distributions_panel.png
# results/plots/sensitivity/MC_profile_variance_decomposition_panel.png
# ==============================================================================

suppressPackageStartupMessages({
  library(dplyr)
  library(readr)
  library(ggplot2)
  library(scales)
  library(ggridges)
  library(patchwork)
})

# ==============================================================================
# 1. Paths and settings
# ==============================================================================

comparison_file <- file.path(
  "results",
  "preparedness_challenge",
  "preparedness_challenge_comparison.csv"
)

monte_carlo_dir <- file.path(
  "results",
  "sensitivity",
  "monte_carlo_sensitivity"
)

country_iteration_file <- file.path(
  monte_carlo_dir,
  "country_iterations.csv"
)

irt_capacity_draw_file <- file.path(
  monte_carlo_dir,
  "irt_preparedness_capacity_latent_draws.csv"
)

variance_decomposition_file <- file.path(
  "results",
  "sensitivity",
  "variance_decomposition",
  "profile_variance_decomposition_summary.csv"
)

plot_dir <- file.path(
  "results",
  "plots",
  "sensitivity"
)

plot_dpi <- 600
plot_random_seed <- 24680L
max_density_draws_per_group <- 3000L

disease_colors <- c(
  "AI" = "#FF99BF",
  "ASF" = "#95CC5E"
)

source_labels <- c(
  "IRT estimation uncertainty",
  "Context Index weighting",
  "Context adjustment",
  "Challenge Index weighting",
  "Interactions among sources"
)

dir.create(
  plot_dir,
  recursive = TRUE,
  showWarnings = FALSE
)

# ==============================================================================
# 2. Helpers
# ==============================================================================

read_required_csv <- function(path) {
  if (!file.exists(path)) {
    stop(
      "Required input file was not found: ",
      path,
      call. = FALSE
    )
  }

  read_csv(
    path,
    show_col_types = FALSE,
    progress = FALSE
  )
}

check_required_columns <- function(
    data,
    required_columns,
    object_name
) {
  missing_columns <- setdiff(
    required_columns,
    names(data)
  )

  if (length(missing_columns) > 0L) {
    stop(
      object_name,
      " is missing required columns: ",
      paste(missing_columns, collapse = ", "),
      call. = FALSE
    )
  }
}

check_unique_keys <- function(
    data,
    keys,
    object_name
) {
  duplicates <- data %>%
    count(
      across(
        all_of(keys)
      )
    ) %>%
    filter(
      n != 1L
    )

  if (nrow(duplicates) > 0L) {
    stop(
      object_name,
      " must contain exactly one row per ",
      paste(keys, collapse = " × "),
      ".",
      call. = FALSE
    )
  }
}

standardize_country_name <- function(x) {
  recode(
    as.character(x),
    "Czech Republic" = "Czechia",
    "Turkiye" = "Türkiye",
    "Turkey" = "Türkiye",
    "Slovak Republic" = "Slovakia",
    "Russian Federation" = "Russia",
    .default = as.character(x)
  )
}

rank_high_is_good <- function(x) {
  rank(
    -x,
    ties.method = "average",
    na.last = "keep"
  )
}

sample_within_groups <- function(
    data,
    group_columns,
    maximum_rows
) {
  set.seed(
    plot_random_seed
  )

  data %>%
    group_by(
      across(
        all_of(
          group_columns
        )
      )
    ) %>%
    group_modify(
      function(.x, .y) {
        if (
          nrow(.x) <=
            maximum_rows
        ) {
          .x
        } else {
          slice_sample(
            .x,
            n = maximum_rows
          )
        }
      }
    ) %>%
    ungroup()
}

save_plot <- function(
    plot,
    filename,
    width,
    height
) {
  ggsave(
    filename = file.path(
      plot_dir,
      filename
    ),
    plot = plot,
    width = width,
    height = height,
    dpi = plot_dpi,
    bg = "white"
  )
}

base_theme <- function(
    base_size = 9
) {
  theme_minimal(
    base_size = base_size
  ) +
    theme(
      panel.grid.minor =
        element_blank(),
      axis.text =
        element_text(
          colour = "black"
        ),
      axis.title =
        element_text(
          colour = "black"
        ),
      plot.title =
        element_text(
          face = "bold",
          hjust = 0.5
        ),
      plot.subtitle =
        element_text(
          hjust = 0.5
        ),
      plot.title.position =
        "plot",
      legend.position =
        "top",
      legend.direction =
        "horizontal",
      legend.key.spacing.x =
        grid::unit(
          0.8,
          "cm"
        ),
      plot.margin =
        margin(
          10,
          15,
          10,
          10
        )
    )
}

add_disease_short <- function(data) {
  data %>%
    mutate(
      disease_short =
        factor(
          case_when(
            disease ==
              "aiv_poultry" ~
              "AI",
            disease ==
              "asf" ~
              "ASF",
            TRUE ~
              NA_character_
          ),
          levels = c(
            "AI",
            "ASF"
          )
        )
    )
}

# ==============================================================================
# 3. Read and validate inputs
# ==============================================================================

comparison_data <- read_required_csv(
  comparison_file
)

country_iterations <- read_required_csv(
  country_iteration_file
)

irt_capacity_latent_draws <- read_required_csv(
  irt_capacity_draw_file
)

variance_decomposition <- read_required_csv(
  variance_decomposition_file
)

check_required_columns(
  comparison_data,
  c(
    "country_name",
    "disease",
    "preparedness_capacity_index"
  ),
  "preparedness_challenge_comparison.csv"
)

check_required_columns(
  country_iterations,
  c(
    "iteration",
    "country_name",
    "disease",
    "preparedness_challenge_balance"
  ),
  "country_iterations.csv"
)

check_required_columns(
  irt_capacity_latent_draws,
  c(
    "iteration",
    "country_name",
    "disease",
    "model",
    "preparedness_capacity_latent"
  ),
  "irt_preparedness_capacity_latent_draws.csv"
)

check_required_columns(
  variance_decomposition,
  c(
    "analysis_level",
    "disease",
    "source",
    "contribution_percent"
  ),
  "profile_variance_decomposition_summary.csv"
)

comparison_data <- comparison_data %>%
  mutate(
    country_name =
      standardize_country_name(
        country_name
      ),
    disease =
      as.character(
        disease
      )
  )

country_iterations <- country_iterations %>%
  mutate(
    country_name =
      standardize_country_name(
        country_name
      ),
    disease =
      as.character(
        disease
      )
  )

irt_capacity_latent_draws <-
  irt_capacity_latent_draws %>%
  mutate(
    country_name =
      standardize_country_name(
        country_name
      ),
    disease =
      as.character(
        disease
      )
  ) %>%
  filter(
    model ==
      "overall_preparedness"
  )

check_unique_keys(
  comparison_data,
  c(
    "country_name",
    "disease"
  ),
  "Preparedness-challenge comparison"
)

# ==============================================================================
# 4. Shared anonymous-country key
# ==============================================================================

country_label_key <- comparison_data %>%
  group_by(
    country_name
  ) %>%
  summarise(
    preparedness_capacity_mean =
      mean(
        preparedness_capacity_index,
        na.rm = TRUE
      ),
    .groups =
      "drop"
  ) %>%
  mutate(
    preparedness_capacity_rank =
      rank_high_is_good(
        preparedness_capacity_mean
      )
  ) %>%
  arrange(
    preparedness_capacity_rank,
    country_name
  ) %>%
  mutate(
    anonymous_country =
      paste0(
        "Country ",
        sprintf(
          "%02d",
          row_number()
        )
      )
  ) %>%
  select(
    country_name,
    anonymous_country
  )

check_unique_keys(
  country_label_key,
  "country_name",
  "Anonymous-country key"
)

country_levels <- rev(
  country_label_key$anonymous_country
)

country_iterations <- country_iterations %>%
  left_join(
    country_label_key,
    by = "country_name"
  )

irt_capacity_latent_draws <-
  irt_capacity_latent_draws %>%
  left_join(
    country_label_key,
    by = "country_name"
  )

if (
  anyNA(
    country_iterations$anonymous_country
  ) ||
    anyNA(
      irt_capacity_latent_draws$anonymous_country
    )
) {
  stop(
    "At least one sensitivity input contains a country not present in the shared anonymous-country key.",
    call. = FALSE
  )
}

# ==============================================================================
# 5. Country-level uncertainty distributions
# ==============================================================================

country_balance_density_data <-
  country_iterations %>%
  mutate(
    anonymous_country =
      factor(
        anonymous_country,
        levels =
          country_levels
      )
  ) %>%
  sample_within_groups(
    group_columns = c(
      "country_name",
      "disease"
    ),
    maximum_rows =
      max_density_draws_per_group
  ) %>%
  add_disease_short()

country_capacity_density_data <-
  irt_capacity_latent_draws %>%
  mutate(
    anonymous_country =
      factor(
        anonymous_country,
        levels =
          country_levels
      )
  ) %>%
  sample_within_groups(
    group_columns = c(
      "country_name",
      "disease"
    ),
    maximum_rows =
      max_density_draws_per_group
  ) %>%
  add_disease_short()

make_ridgeline_plot <- function(
    data,
    x_variable,
    x_label,
    panel_title,
    show_y_labels = TRUE,
    zero_line = FALSE
) {
  plot <- ggplot(
    data,
    aes(
      x =
        .data[[x_variable]],
      y =
        anonymous_country,
      fill =
        disease_short,
      group =
        interaction(
          anonymous_country,
          disease_short
        )
    )
  ) +
    ggridges::geom_density_ridges(
      scale = 0.95,
      rel_min_height = 0.01,
      alpha = 0.55,
      colour = NA
    ) +
    ggridges::geom_density_ridges(
      scale = 0.95,
      rel_min_height = 0.01,
      alpha = 0,
      fill = NA,
      colour = "black",
      linewidth = 0.35,
      show.legend = FALSE
    ) +
    scale_y_discrete(
      expand =
        expansion(
          add = c(
            0,
            0.6
          )
        )
    ) +
    scale_fill_manual(
      values =
        disease_colors,
      breaks = c(
        "AI",
        "ASF"
      ),
      drop = FALSE,
      name = NULL,
      guide =
        guide_legend(
          override.aes =
            list(
              colour = "black",
              linewidth = 0.3,
              alpha = 1
            )
        )
    ) +
    labs(
      title =
        panel_title,
      x =
        x_label,
      y =
        NULL
    ) +
    base_theme(
      8
    ) +
    theme(
      panel.grid.major.y =
        element_blank(),
      axis.line =
        element_line(
          colour = "black",
          linewidth = 0.5
        ),
      axis.ticks =
        element_line(
          colour = "black",
          linewidth = 0.5
        ),
      axis.ticks.length =
        grid::unit(
          0.15,
          "cm"
        ),
      axis.text.y =
        if (
          show_y_labels
        ) {
          element_text(
            size = 7
          )
        } else {
          element_blank()
        },
      plot.title =
        element_text(
          face = "bold",
          hjust = 0.5,
          size = 9
        )
    )

  if (
    zero_line
  ) {
    plot <-
      plot +
      geom_vline(
        xintercept = 0,
        linetype = "dashed",
        linewidth = 0.5
      )
  }

  plot
}

plot_capacity <-
  make_ridgeline_plot(
    data =
      country_capacity_density_data,
    x_variable =
      "preparedness_capacity_latent",
    x_label =
      "Latent score",
    panel_title =
      "A. IRT-derived latent Preparedness capacity",
    show_y_labels =
      TRUE,
    zero_line =
      FALSE
  )

plot_balance <-
  make_ridgeline_plot(
    data =
      country_balance_density_data,
    x_variable =
      "preparedness_challenge_balance",
    x_label =
      "Preparedness-Challenge balance",
    panel_title =
      "B. Preparedness-Challenge balance",
    show_y_labels =
      FALSE,
    zero_line =
      TRUE
  )

country_distribution_panel <-
  (
    plot_capacity +
      plot_balance
  ) +
  plot_layout(
    guides = "collect",
    widths = c(
      1,
      1
    )
  ) +
  plot_annotation(
    title =
      "Country-level distributions of Preparedness capacity and Preparedness-Challenge balance",
    subtitle =
      "AI and ASF distributions are overlaid for each anonymous country",
    theme =
      theme(
        plot.title =
          element_text(
            face = "bold",
            hjust = 0.5,
            size = 12
          ),
        plot.subtitle =
          element_text(
            hjust = 0.5,
            size = 10
          ),
        plot.title.position =
          "plot"
      )
  ) &
  theme(
    legend.position =
      "top",
    legend.direction =
      "horizontal",
    legend.key.spacing.x =
      grid::unit(
        0.8,
        "cm"
      )
  )

save_plot(
  country_distribution_panel,
  "country_preparedness_balance_distributions_panel.png",
  width = 10,
  height = 7
)

# ==============================================================================
# 6. Variance-based global sensitivity
# ==============================================================================

variance_plot_data <- variance_decomposition %>%
  mutate(
    analysis_level =
      factor(
        analysis_level,
        levels = c(
          "Country-level profile classification",
          "Livestock-weighted regional profile composition"
        )
      ),
    source =
      recode(
        as.character(
          source
        ),
        "Context Index weighting" =
          "Context Index weighting",
        "Challenge Index weighting" =
          "Challenge Index weighting",
        "Interactions" =
          "Interactions among sources",
        .default =
          as.character(
            source
          )
      )
  ) %>%
  add_disease_short()

missing_sources <- setdiff(
  source_labels,
  unique(
    variance_plot_data$source
  )
)

if (
  length(
    missing_sources
  ) > 0L
) {
  stop(
    "Variance-decomposition summary is missing: ",
    paste(
      missing_sources,
      collapse = ", "
    ),
    call. = FALSE
  )
}

variance_sum_check <- variance_plot_data %>%
  group_by(
    analysis_level,
    disease
  ) %>%
  summarise(
    contribution_sum =
      sum(
        contribution_percent,
        na.rm = TRUE
      ),
    .groups =
      "drop"
  )

if (
  any(
    abs(
      variance_sum_check$contribution_sum -
        100
    ) > 1e-6
  )
) {
  stop(
    "Variance contributions do not sum to 100% within disease and analysis level.",
    call. = FALSE
  )
}

source_order <- variance_plot_data %>%
  group_by(
    source
  ) %>%
  summarise(
    mean_contribution =
      mean(
        contribution_percent,
        na.rm = TRUE
      ),
    .groups =
      "drop"
  ) %>%
  arrange(
    mean_contribution
  ) %>%
  pull(
    source
  )

variance_plot_data <- variance_plot_data %>%
  mutate(
    source =
      factor(
        source,
        levels =
          source_order
      )
  )

variance_x_max <- max(
  variance_plot_data$contribution_percent,
  na.rm = TRUE
)

variance_x_max <- min(
  100,
  max(
    20,
    ceiling(
      variance_x_max *
        1.20 /
        5
    ) *
      5
  )
)

make_variance_plot <- function(
    data,
    panel_title
) {
  ggplot(
    data,
    aes(
      x =
        contribution_percent,
      y =
        source,
      fill =
        disease_short
    )
  ) +
    geom_col(
      position =
        position_dodge2(
          width = 0.72,
          reverse = TRUE
        ),
      width = 0.64,
      colour = "black",
      linewidth = 0.25
    ) +
    geom_text(
      aes(
        label =
          sprintf(
            "%.0f%%",
            contribution_percent
          )
      ),
      position =
        position_dodge2(
          width = 0.72,
          reverse = TRUE
        ),
      hjust = -0.25,
      size = 3
    ) +
    scale_fill_manual(
      values =
        disease_colors,
      breaks = c(
        "AI",
        "ASF"
      ),
      drop = FALSE,
      name = NULL,
      guide =
        guide_legend(
          override.aes =
            list(
              colour = "black",
              linewidth = 0.3,
              alpha = 1
            )
        )
    ) +
    scale_x_continuous(
      breaks =
        pretty_breaks(
          n = 5
        ),
      expand =
        expansion(
          mult = c(
            0,
            0
          )
        )
    ) +
    coord_cartesian(
      xlim = c(
        0,
        variance_x_max
      ),
      clip = "off",
      expand = FALSE
    ) +
    labs(
      title =
        panel_title,
      x =
        "Contribution to total variance (%)",
      y =
        NULL
    ) +
    base_theme(
      9
    ) +
    theme(
      panel.grid.major.y =
        element_blank(),
      axis.line =
        element_line(
          colour = "black",
          linewidth = 0.5
        ),
      axis.ticks =
        element_line(
          colour = "black",
          linewidth = 0.5
        ),
      axis.ticks.length =
        grid::unit(
          0.15,
          "cm"
        ),
      plot.title =
        element_text(
          face = "bold",
          hjust = 0.5,
          size = 10
        ),
      plot.title.position =
        "plot",
      plot.margin =
        margin(
          10,
          24,
          10,
          10
        )
    )
}

plot_variance_country <-
  make_variance_plot(
    variance_plot_data %>%
      filter(
        analysis_level ==
          "Country-level profile classification"
      ),
    "A. Country-level profile classification"
  )

plot_variance_regional <-
  make_variance_plot(
    variance_plot_data %>%
      filter(
        analysis_level ==
          "Livestock-weighted regional profile composition"
      ),
    "B. Livestock-weighted regional profile composition"
  )

variance_panel <-
  (
    guide_area() /
      plot_variance_country /
      plot_variance_regional
  ) +
  plot_layout(
    guides = "collect",
    heights = c(
      0.14,
      1,
      1
    )
  ) +
  plot_annotation(
    title =
      "Sources of uncertainty in Preparedness-Challenge profiles",
    subtitle =
      "Variance-based global sensitivity analysis; contributions sum to 100% within each disease and analysis level",
    theme =
      theme(
        plot.title =
          element_text(
            face = "bold",
            hjust = 0.5,
            size = 12
          ),
        plot.subtitle =
          element_text(
            hjust = 0.5,
            size = 10,
            margin =
              margin(
                b = 6
              )
          ),
        plot.title.position =
          "plot"
      )
  ) &
  theme(
    legend.position =
      "top",
    legend.direction =
      "horizontal",
    legend.key.spacing.x =
      grid::unit(
        0.8,
        "cm"
      ),
    legend.margin =
      margin(
        t = 0,
        r = 0,
        b = 6,
        l = 0
      )
  )

save_plot(
  variance_panel,
  "MC_profile_variance_decomposition_panel.png",
  width = 9,
  height = 8
)

message(
  "\nSensitivity plots completed.\n",
  "Outputs:\n",
  "  ",
  file.path(
    plot_dir,
    "country_preparedness_balance_distributions_panel.png"
  ),
  "\n  ",
  file.path(
    plot_dir,
    "MC_profile_variance_decomposition_panel.png"
  ),
  "\n"
)
