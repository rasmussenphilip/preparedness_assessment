# ==============================================================================
# 13_plot_validation_results.R
#
# PURPOSE
# Plot the retained validation results for the Preparedness-challenge framework.
#
# INPUTS
# results/balance_validation/validation_balance_auc.csv
# results/balance_validation/validation_profile_concordance.csv
#
# OUTPUTS
# results/plots/balance_validation/outbreak_discrimination_auc.png
# results/plots/balance_validation/profile_validation_concordant_contrast.png
# results/plots/balance_validation/profile_validation_discordant_contrast.png
# ==============================================================================

suppressPackageStartupMessages({
  library(dplyr)
  library(readr)
  library(ggplot2)
  library(scales)
})

# ==============================================================================
# 1. Paths and settings
# ==============================================================================

input_dir <- file.path(
  "results",
  "balance_validation"
)

balance_input_file <- file.path(
  input_dir,
  "validation_balance_auc.csv"
)

profile_input_file <- file.path(
  input_dir,
  "validation_profile_concordance.csv"
)

plot_dir <- file.path(
  "results",
  "plots",
  "balance_validation"
)

plot_dpi <- 600

period_levels <- c(
  "2015-2019",
  "2020-2024",
  "2015-2024"
)

disease_colors <- c(
  "AI" = "#FF99BF",
  "ASF" = "#95CC5E"
)

dir.create(
  plot_dir,
  recursive = TRUE,
  showWarnings = FALSE
)

# ==============================================================================
# 2. Helpers
# ==============================================================================

read_required_csv <- function(path) {
  if (!file.exists(path)) {
    stop(
      "Required input file was not found: ",
      path,
      call. = FALSE
    )
  }

  read_csv(
    path,
    show_col_types = FALSE,
    progress = FALSE
  )
}

check_required_columns <- function(
    data,
    required_columns,
    object_name
) {
  missing_columns <- setdiff(
    required_columns,
    names(data)
  )

  if (length(missing_columns) > 0L) {
    stop(
      object_name,
      " is missing required columns: ",
      paste(missing_columns, collapse = ", "),
      call. = FALSE
    )
  }
}

standardize_period <- function(x) {
  x <- as.character(x)

  x <- gsub(
    "–",
    "-",
    x,
    fixed = TRUE
  )

  factor(
    x,
    levels = period_levels
  )
}

validation_theme <- function(
    base_size = 9
) {
  theme_minimal(
    base_size = base_size
  ) +
    theme(
      panel.grid.minor =
        element_blank(),
      panel.grid.major.x =
        element_blank(),
      axis.text =
        element_text(
          colour = "black"
        ),
      axis.title =
        element_text(
          colour = "black"
        ),
      plot.title =
        element_text(
          face = "bold",
          hjust = 0.5
        ),
      plot.subtitle =
        element_text(
          hjust = 0.5
        ),
      legend.position =
        "top",
      legend.direction =
        "horizontal",
      legend.key.spacing.x =
        grid::unit(
          0.8,
          "cm"
        ),
      axis.line =
        element_line(
          colour = "black",
          linewidth = 0.5
        ),
      axis.ticks =
        element_line(
          colour = "black",
          linewidth = 0.5
        ),
      axis.ticks.length =
        grid::unit(
          0.15,
          "cm"
        ),
      axis.title.x =
        element_text(
          margin =
            margin(
              t = 14
            )
        ),
      strip.text =
        element_text(
          face = "bold"
        ),
      strip.background =
        element_blank(),
      plot.margin =
        margin(
          10,
          15,
          10,
          10
        )
    )
}

# ==============================================================================
# 3. Apparent AUC
# ==============================================================================

auc_data <- read_required_csv(
  balance_input_file
)

check_required_columns(
  auc_data,
  c(
    "disease",
    "validation_period",
    "apparent_auc"
  ),
  "validation_balance_auc.csv"
)

auc_plot_data <- auc_data %>%
  mutate(
    validation_period =
      standardize_period(
        validation_period
      ),
    disease_label =
      factor(
        disease,
        levels = c(
          "aiv_poultry",
          "asf"
        ),
        labels = c(
          "AI",
          "ASF"
        )
      )
  )

if (
  anyNA(
    auc_plot_data$validation_period
  )
) {
  stop(
    "Unrecognized validation period in validation_balance_auc.csv.",
    call. = FALSE
  )
}

if (
  anyNA(
    auc_plot_data$disease_label
  )
) {
  stop(
    "Unrecognized disease in validation_balance_auc.csv.",
    call. = FALSE
  )
}

plot_auc <- ggplot(
  auc_plot_data,
  aes(
    x = validation_period,
    y = apparent_auc,
    fill = disease_label
  )
) +
  geom_col(
    width = 0.62,
    position =
      position_dodge(
        width = 0.72
      ),
    colour = "black",
    linewidth = 0.4
  ) +
  geom_text(
    aes(
      label =
        number(
          apparent_auc,
          accuracy = 0.01
        )
    ),
    position =
      position_dodge(
        width = 0.72
      ),
    vjust = -0.35,
    size = 3
  ) +
  geom_hline(
    yintercept = 0.5,
    linetype = "dashed",
    linewidth = 0.5
  ) +
  scale_y_continuous(
    limits = c(
      0,
      1
    ),
    breaks =
      seq(
        0,
        1,
        by = 0.25
      ),
    labels =
      number_format(
        accuracy = 0.01
      ),
    expand =
      expansion(
        mult = c(
          0,
          0.05
        )
      )
  ) +
  scale_fill_manual(
    values = disease_colors,
    breaks = c(
      "AI",
      "ASF"
    ),
    drop = FALSE
  ) +
  labs(
    title =
      "Outbreak discrimination across historical periods",
    subtitle =
      "Apparent AUC for Preparedness-challenge balance",
    x =
      "Historical period",
    y =
      "Area under the ROC curve",
    fill =
      NULL
  ) +
  validation_theme(
    base_size = 9
  )

ggsave(
  filename =
    file.path(
      plot_dir,
      "outbreak_discrimination_auc.png"
    ),
  plot =
    plot_auc,
  width =
    6,
  height =
    6,
  dpi =
    plot_dpi,
  bg =
    "white"
)

# ==============================================================================
# 4. Profile-contrast concordance
# ==============================================================================

profile_data <- read_required_csv(
  profile_input_file
)

check_required_columns(
  profile_data,
  c(
    "disease",
    "validation_period",
    "burden_measure",
    "contrast_id",
    "concordance_probability"
  ),
  "validation_profile_concordance.csv"
)

profile_plot_data <- profile_data %>%
  mutate(
    validation_period =
      standardize_period(
        validation_period
      ),
    validation_period_panel =
      factor(
        as.character(
          validation_period
        ),
        levels =
          period_levels,
        labels = c(
          "A. Historical period 2015-2019",
          "B. Historical period 2020-2024",
          "C. Historical period 2015-2024"
        )
      ),
    disease_label =
      factor(
        disease,
        levels = c(
          "aiv_poultry",
          "asf"
        ),
        labels = c(
          "AI",
          "ASF"
        )
      ),
    burden_measure =
      factor(
        burden_measure,
        levels = c(
          "Frequency",
          "Recurrence",
          "Persistence"
        )
      ),
    bar_label =
      if_else(
        is.na(
          concordance_probability
        ),
        "NA",
        sprintf(
          "%.2f",
          concordance_probability
        )
      ),
    label_y =
      case_when(
        is.na(
          concordance_probability
        ) ~
          NA_real_,
        concordance_probability >=
          0.995 ~
          0.90,
        TRUE ~
          pmin(
            concordance_probability +
              0.035,
            1
          )
      )
  )

if (
  anyNA(
    profile_plot_data$validation_period
  )
) {
  stop(
    "Unrecognized validation period in validation_profile_concordance.csv.",
    call. = FALSE
  )
}

if (
  anyNA(
    profile_plot_data$disease_label
  )
) {
  stop(
    "Unrecognized disease in validation_profile_concordance.csv.",
    call. = FALSE
  )
}

if (
  anyNA(
    profile_plot_data$burden_measure
  )
) {
  stop(
    "Unrecognized burden measure in validation_profile_concordance.csv.",
    call. = FALSE
  )
}

make_profile_contrast_plot <- function(
    data,
    contrast_id,
    plot_title,
    profile_text
) {
  plot_data <- data %>%
    filter(
      .data$contrast_id ==
        .env$contrast_id
    )

  if (
    nrow(
      plot_data
    ) == 0L
  ) {
    stop(
      "No validation results found for contrast: ",
      contrast_id,
      call. = FALSE
    )
  }

  ggplot(
    plot_data,
    aes(
      x = burden_measure,
      y = concordance_probability,
      fill = disease_label
    )
  ) +
    geom_hline(
      yintercept = 0.5,
      linetype = "dashed",
      linewidth = 0.5
    ) +
    geom_col(
      width = 0.62,
      position =
        position_dodge(
          width = 0.72
        ),
      colour = "black",
      linewidth = 0.4,
      na.rm = TRUE
    ) +
    shadowtext::geom_shadowtext(
      aes(
        y = label_y,
        label = bar_label
      ),
      position =
        position_dodge(
          width = 0.72
        ),
      size = 3,
      vjust = 0,
      colour = "black",
      bg.colour = "white",
      bg.r = 0.2,
      show.legend = FALSE,
      na.rm = TRUE
    ) +
    facet_wrap(
      ~ validation_period_panel,
      ncol = 1,
      axes = "all_x",
      axis.labels = "margins"
    ) +
    scale_y_continuous(
      limits = c(
        0,
        1
      ),
      breaks =
        seq(
          0,
          1,
          by = 0.25
        ),
      labels =
        number_format(
          accuracy = 0.01
        ),
      expand =
        expansion(
          mult = c(
            0,
            0.08
          )
        )
    ) +
    scale_fill_manual(
      values = disease_colors,
      breaks = c(
        "AI",
        "ASF"
      ),
      drop = FALSE
    ) +
    labs(
      title =
        plot_title,
      subtitle =
        paste0(
          profile_text,
          "\nValues >0.50 indicate greater burden in the underprepared profile"
        ),
      x =
        "Outbreak burden measure",
      y =
        "Concordance probability",
      fill =
        NULL
    ) +
    validation_theme(
      base_size = 9
    ) +
    theme(
      axis.text.x =
        element_text(
          size = 8
        ),
      strip.text.x =
        element_text(
          face = "bold",
          hjust = 0.5,
          size = 9
        ),
      strip.placement =
        "outside"
    )
}

plot_profile_concordant <-
  make_profile_contrast_plot(
    profile_plot_data,
    contrast_id =
      "concordant",
    plot_title =
      "Concordant preparedness-challenge profile contrast across\nhistorical periods and outbreak burden measures",
    profile_text =
      "Prepared (low challenge) vs Underprepared (high challenge);"
  )

plot_profile_discordant <-
  make_profile_contrast_plot(
    profile_plot_data,
    contrast_id =
      "discordant",
    plot_title =
      "Discordant preparedness-challenge profile contrast across\nhistorical periods and outbreak burden measures",
    profile_text =
      "Prepared (high challenge) vs Underprepared (low challenge);"
  )

ggsave(
  filename =
    file.path(
      plot_dir,
      "profile_validation_concordant_contrast.png"
    ),
  plot =
    plot_profile_concordant,
  width =
    7,
  height =
    8,
  dpi =
    plot_dpi,
  bg =
    "white"
)

ggsave(
  filename =
    file.path(
      plot_dir,
      "profile_validation_discordant_contrast.png"
    ),
  plot =
    plot_profile_discordant,
  width =
    7,
  height =
    8,
  dpi =
    plot_dpi,
  bg =
    "white"
)

message(
  "\nValidation plots completed.\n",
  "Outputs:\n",
  "  ",
  file.path(
    plot_dir,
    "outbreak_discrimination_auc.png"
  ),
  "\n  ",
  file.path(
    plot_dir,
    "profile_validation_concordant_contrast.png"
  ),
  "\n  ",
  file.path(
    plot_dir,
    "profile_validation_discordant_contrast.png"
  ),
  "\n"
)
