# ==============================================================================
# 16_plot_profiles.R
#
# PURPOSE
# Plot the deterministic country-level preparedness-challenge profiles and the
# regional composition of those profiles.
#
# Country profiles are defined by:
# - preparedness adequacy: Context-adjusted preparedness >= Challenge Index
# - challenge level: below/above the disease-specific median Challenge Index
#
# The country-profile figure uses synthetic point coordinates for disclosure
# protection while preserving the real disease-specific profile counts and
# challenge medians.
#
# INPUTS
# results/preparedness_challenge/preparedness_challenge_comparison.csv
# data/exported/data_secondary.csv
# data/region_key.csv
#
# OUTPUTS
# results/plots/profiles/country_profiles.png
# results/plots/profiles/regional_profile_composition.png
# ==============================================================================

suppressPackageStartupMessages({
  library(dplyr)
  library(tidyr)
  library(readr)
  library(ggplot2)
  library(scales)
  library(patchwork)
})

# ==============================================================================
# 1. Paths and settings
# ==============================================================================

comparison_file <- file.path(
  "results",
  "preparedness_challenge",
  "preparedness_challenge_comparison.csv"
)

secondary_file <- file.path(
  "data",
  "exported",
  "data_secondary.csv"
)

region_file <- file.path(
  "data",
  "region_key.csv"
)

plot_dir <- file.path(
  "results",
  "plots",
  "profiles"
)

plot_dpi <- 600
plot_random_seed <- 24680L

illustrative_x_min <- 5
illustrative_x_max <- 95
illustrative_y_min <- 5
illustrative_y_max <- 95

boundary_inset <- 1
edge_inset <- 2

required_diseases <- c(
  "aiv_poultry",
  "asf"
)

disease_labels <- c(
  aiv_poultry = "Avian influenza",
  asf = "African swine fever"
)

region_levels <- c(
  "Central Europe",
  "Northern Europe",
  "Southern Europe",
  "Western Europe"
)

profile_levels <- c(
  "Prepared (low challenge)",
  "Prepared (high challenge)",
  "Underprepared (low challenge)",
  "Underprepared (high challenge)"
)

profile_colors <- c(
  "Prepared (low challenge)" = "#A9D681",
  "Prepared (high challenge)" = "#F4DE45",
  "Underprepared (low challenge)" = "#F1B978",
  "Underprepared (high challenge)" = "#E98F8F"
)

dir.create(
  plot_dir,
  recursive = TRUE,
  showWarnings = FALSE
)

# ==============================================================================
# 2. Helpers
# ==============================================================================

read_required_csv <- function(path) {
  if (!file.exists(path)) {
    stop(
      "Required input file was not found: ",
      path,
      call. = FALSE
    )
  }

  read_csv(
    path,
    show_col_types = FALSE,
    progress = FALSE
  )
}

check_required_columns <- function(
    data,
    required_columns,
    object_name
) {
  missing_columns <- setdiff(
    required_columns,
    names(data)
  )

  if (length(missing_columns) > 0L) {
    stop(
      object_name,
      " is missing required columns: ",
      paste(missing_columns, collapse = ", "),
      call. = FALSE
    )
  }
}

check_unique_keys <- function(
    data,
    keys,
    object_name
) {
  duplicates <- data %>%
    count(
      across(
        all_of(keys)
      )
    ) %>%
    filter(
      n != 1L
    )

  if (nrow(duplicates) > 0L) {
    stop(
      object_name,
      " must contain exactly one row per ",
      paste(keys, collapse = " × "),
      ".",
      call. = FALSE
    )
  }
}

standardize_country_name <- function(x) {
  recode(
    as.character(x),
    "Czech Republic" = "Czechia",
    "Turkiye" = "Türkiye",
    "Turkey" = "Türkiye",
    "Slovak Republic" = "Slovakia",
    "Russian Federation" = "Russia",
    .default = as.character(x)
  )
}

save_plot <- function(
    plot,
    filename,
    width,
    height
) {
  ggsave(
    filename = file.path(
      plot_dir,
      filename
    ),
    plot = plot,
    width = width,
    height = height,
    dpi = plot_dpi,
    bg = "white"
  )
}

base_theme <- function(
    base_size = 9
) {
  theme_minimal(
    base_size = base_size
  ) +
    theme(
      panel.grid.minor =
        element_blank(),
      axis.text =
        element_text(
          colour = "black"
        ),
      axis.title =
        element_text(
          colour = "black"
        ),
      strip.text =
        element_text(
          face = "bold"
        ),
      legend.position =
        "bottom",
      plot.margin =
        margin(
          10,
          15,
          10,
          10
        )
    )
}

# ==============================================================================
# 3. Read and validate deterministic inputs
# ==============================================================================

comparison_data <- read_required_csv(
  comparison_file
)

secondary_data <- read_required_csv(
  secondary_file
)

region_key <- read_required_csv(
  region_file
)

check_required_columns(
  comparison_data,
  c(
    "country_name",
    "disease",
    "context_adjusted_preparedness",
    "challenge_index",
    "preparedness_challenge_balance"
  ),
  "preparedness_challenge_comparison.csv"
)

check_required_columns(
  secondary_data,
  c(
    "country_name",
    "stock_pigs",
    "stock_poultry"
  ),
  "data_secondary.csv"
)

check_required_columns(
  region_key,
  c(
    "country_name",
    "region"
  ),
  "region_key.csv"
)

comparison_data <- comparison_data %>%
  transmute(
    country_name =
      standardize_country_name(
        country_name
      ),
    disease =
      as.character(
        disease
      ),
    context_adjusted_preparedness =
      as.numeric(
        context_adjusted_preparedness
      ),
    challenge_index =
      as.numeric(
        challenge_index
      ),
    preparedness_challenge_balance =
      as.numeric(
        preparedness_challenge_balance
      )
  ) %>%
  filter(
    disease %in%
      required_diseases
  )

secondary_data <- secondary_data %>%
  transmute(
    country_name =
      standardize_country_name(
        country_name
      ),
    stock_pigs =
      as.numeric(
        stock_pigs
      ),
    stock_poultry =
      as.numeric(
        stock_poultry
      )
  )

region_key <- region_key %>%
  transmute(
    country_name =
      standardize_country_name(
        country_name
      ),
    region =
      as.character(
        region
      )
  )

check_unique_keys(
  comparison_data,
  c(
    "country_name",
    "disease"
  ),
  "Preparedness-Challenge comparison"
)

check_unique_keys(
  secondary_data,
  "country_name",
  "Livestock data"
)

check_unique_keys(
  region_key,
  "country_name",
  "Region key"
)

# ==============================================================================
# 4. Deterministic country profiles
# ==============================================================================

real_profile_data <- comparison_data %>%
  group_by(
    disease
  ) %>%
  mutate(
    challenge_median =
      median(
        challenge_index,
        na.rm = TRUE
      ),
    profile =
      case_when(
        preparedness_challenge_balance >= 0 &
          challenge_index <
            challenge_median ~
          "Prepared (low challenge)",

        preparedness_challenge_balance >= 0 &
          challenge_index >=
            challenge_median ~
          "Prepared (high challenge)",

        preparedness_challenge_balance < 0 &
          challenge_index <
            challenge_median ~
          "Underprepared (low challenge)",

        preparedness_challenge_balance < 0 &
          challenge_index >=
            challenge_median ~
          "Underprepared (high challenge)",

        TRUE ~
          NA_character_
      )
  ) %>%
  ungroup()

if (
  anyNA(
    real_profile_data$profile
  )
) {
  stop(
    "At least one country could not be assigned to a Preparedness-Challenge profile.",
    call. = FALSE
  )
}

real_profile_counts <- real_profile_data %>%
  count(
    disease,
    profile,
    name = "n_countries"
  ) %>%
  complete(
    disease,
    profile =
      profile_levels,
    fill = list(
      n_countries = 0L
    )
  )

profile_cuts <- real_profile_data %>%
  distinct(
    disease,
    challenge_median
  )

# ==============================================================================
# 5. Disclosure-safe country-profile figure
# ==============================================================================

generate_synthetic_profile_points <- function(
    disease_code,
    challenge_cut,
    counts
) {
  draw_profile <- function(
      profile_name,
      n_points
  ) {
    if (
      n_points == 0L
    ) {
      return(
        tibble(
          disease = character(),
          profile = character(),
          synthetic_challenge_index = numeric(),
          synthetic_preparedness_index = numeric()
        )
      )
    }

    low_challenge <-
      profile_name %in%
      c(
        "Prepared (low challenge)",
        "Underprepared (low challenge)"
      )

    prepared <-
      profile_name %in%
      c(
        "Prepared (low challenge)",
        "Prepared (high challenge)"
      )

    x_min <-
      if (
        low_challenge
      ) {
        illustrative_x_min +
          edge_inset
      } else {
        challenge_cut +
          boundary_inset
      }

    x_max <-
      if (
        low_challenge
      ) {
        challenge_cut -
          boundary_inset
      } else {
        illustrative_x_max -
          edge_inset
      }

    if (
      prepared
    ) {
      x_max <- min(
        x_max,
        illustrative_y_max -
          edge_inset -
          boundary_inset
      )
    } else {
      x_min <- max(
        x_min,
        illustrative_y_min +
          edge_inset +
          boundary_inset
      )
    }

    if (
      !is.finite(
        x_min
      ) ||
        !is.finite(
          x_max
        ) ||
        x_min >= x_max
    ) {
      stop(
        "No valid synthetic plotting area for ",
        disease_code,
        " / ",
        profile_name,
        ".",
        call. = FALSE
      )
    }

    x <- runif(
      n_points,
      min = x_min,
      max = x_max
    )

    if (
      prepared
    ) {
      y_min <- x +
        boundary_inset

      y_max <- rep(
        illustrative_y_max -
          edge_inset,
        n_points
      )
    } else {
      y_min <- rep(
        illustrative_y_min +
          edge_inset,
        n_points
      )

      y_max <- x -
        boundary_inset
    }

    if (
      any(
        y_min >= y_max
      )
    ) {
      stop(
        "Invalid synthetic y-axis bounds for ",
        disease_code,
        " / ",
        profile_name,
        ".",
        call. = FALSE
      )
    }

    tibble(
      disease =
        disease_code,
      profile =
        profile_name,
      synthetic_challenge_index =
        x,
      synthetic_preparedness_index =
        runif(
          n_points,
          min = y_min,
          max = y_max
        )
    )
  }

  bind_rows(
    lapply(
      profile_levels,
      function(profile_name) {
        n_points <- counts %>%
          filter(
            profile ==
              profile_name
          ) %>%
          pull(
            n_countries
          )

        if (
          length(
            n_points
          ) == 0L
        ) {
          n_points <- 0L
        }

        draw_profile(
          profile_name,
          n_points
        )
      }
    )
  )
}

set.seed(
  plot_random_seed
)

synthetic_points <- bind_rows(
  lapply(
    required_diseases,
    function(disease_code) {
      challenge_cut <-
        profile_cuts %>%
        filter(
          disease ==
            disease_code
        ) %>%
        pull(
          challenge_median
        )

      counts <-
        real_profile_counts %>%
        filter(
          disease ==
            disease_code
        )

      generate_synthetic_profile_points(
        disease_code =
          disease_code,
        challenge_cut =
          challenge_cut,
        counts =
          counts
      )
    }
  )
)

synthetic_count_check <- synthetic_points %>%
  count(
    disease,
    profile,
    name =
      "n_synthetic"
  ) %>%
  complete(
    disease,
    profile =
      profile_levels,
    fill = list(
      n_synthetic = 0L
    )
  ) %>%
  left_join(
    real_profile_counts,
    by = c(
      "disease",
      "profile"
    )
  )

if (
  any(
    synthetic_count_check$n_synthetic !=
      synthetic_count_check$n_countries
  )
) {
  stop(
    "Synthetic point counts do not match deterministic profile counts.",
    call. = FALSE
  )
}

synthetic_points <- synthetic_points %>%
  left_join(
    profile_cuts,
    by = "disease"
  ) %>%
  mutate(
    profile =
      factor(
        profile,
        levels =
          profile_levels
      )
  )


# Spread the three most leftward ASF points in the underprepared/low-challenge
# profile to avoid visual overlap in the synthetic illustration.
asf_low_under_idx <- which(
  synthetic_points$disease == "asf" &
    as.character(synthetic_points$profile) ==
      "Underprepared (low challenge)"
)

if (length(asf_low_under_idx) >= 3L) {
  clustered_idx <- asf_low_under_idx[
    order(
      synthetic_points$synthetic_challenge_index[
        asf_low_under_idx
      ]
    )[1:3]
  ]

  synthetic_points$synthetic_challenge_index[
    clustered_idx
  ] <- c(
    9,
    14,
    19
  )

  synthetic_points$synthetic_preparedness_index[
    clustered_idx
  ] <- c(
    7,
    10,
    13
  )
}

make_profile_panel <- function(
    panel_data,
    panel_title
) {
  challenge_cut <-
    unique(
      panel_data$challenge_median
    )

  if (
    length(
      challenge_cut
    ) != 1L
  ) {
    stop(
      "Expected one disease-specific Challenge Index median per profile panel.",
      call. = FALSE
    )
  }

  background_data <- bind_rows(
    tibble(
      profile =
        "Prepared (low challenge)",
      x = c(
        illustrative_x_min,
        illustrative_x_min,
        challenge_cut,
        challenge_cut
      ),
      y = c(
        illustrative_x_min,
        illustrative_y_max,
        illustrative_y_max,
        challenge_cut
      )
    ),
    tibble(
      profile =
        "Prepared (high challenge)",
      x = c(
        challenge_cut,
        challenge_cut,
        illustrative_x_max,
        illustrative_x_max
      ),
      y = c(
        challenge_cut,
        illustrative_y_max,
        illustrative_y_max,
        illustrative_x_max
      )
    ),
    tibble(
      profile =
        "Underprepared (low challenge)",
      x = c(
        illustrative_x_min,
        challenge_cut,
        challenge_cut,
        illustrative_x_min
      ),
      y = c(
        illustrative_y_min,
        illustrative_y_min,
        challenge_cut,
        illustrative_x_min
      )
    ),
    tibble(
      profile =
        "Underprepared (high challenge)",
      x = c(
        challenge_cut,
        illustrative_x_max,
        illustrative_x_max,
        challenge_cut
      ),
      y = c(
        illustrative_y_min,
        illustrative_y_min,
        illustrative_x_max,
        challenge_cut
      )
    )
  ) %>%
    mutate(
      profile =
        factor(
          profile,
          levels =
            profile_levels
        )
    )

  ggplot() +
    geom_polygon(
      data =
        background_data,
      aes(
        x = x,
        y = y,
        group = profile,
        fill = profile
      ),
      colour = NA
    ) +
    geom_abline(
      intercept = 0,
      slope = 1,
      linetype = "solid",
      linewidth = 0.5
    ) +
    geom_vline(
      xintercept =
        challenge_cut,
      linetype = "dashed",
      linewidth = 0.5
    ) +
    geom_point(
      data =
        panel_data,
      aes(
        x =
          synthetic_challenge_index,
        y =
          synthetic_preparedness_index
      ),
      size = 2.2,
      colour = "black",
      alpha = 0.8
    ) +
    annotate(
      "text",
      x = 93.5,
      y = 7,
      label =
        "*Point positions within profiles are illustrative",
      hjust = 1,
      vjust = 0,
      colour = "black",
      size = 2.5
    ) +
    scale_x_continuous(
      breaks = c(
        25,
        50,
        75
      ),
      expand = c(
        0,
        0
      )
    ) +
    scale_y_continuous(
      breaks = c(
        25,
        50,
        75
      ),
      expand = c(
        0,
        0
      )
    ) +
    coord_cartesian(
      xlim = c(
        illustrative_x_min,
        illustrative_x_max
      ),
      ylim = c(
        illustrative_y_min,
        illustrative_y_max
      ),
      expand = FALSE
    ) +
    scale_fill_manual(
      values =
        profile_colors,
      breaks =
        profile_levels,
      drop = FALSE,
      name =
        "Preparedness-Challenge profile"
    ) +
    guides(
      fill =
        guide_legend(
          title.position =
            "bottom",
          title.hjust =
            0.5,
          byrow =
            TRUE
        )
    ) +
    labs(
      title =
        panel_title,
      x =
        "Challenge Index",
      y =
        "Context-adjusted preparedness"
    ) +
    base_theme() +
    theme(
      panel.grid =
        element_blank(),
      panel.border =
        element_rect(
          colour = "black",
          fill = NA,
          linewidth = 0.6
        ),
      axis.ticks =
        element_line(
          colour = "black",
          linewidth = 0.5
        ),
      axis.ticks.length =
        grid::unit(
          0.15,
          "cm"
        ),
      plot.title =
        element_text(
          face = "bold",
          hjust = 0.5,
          size = 9
        ),
      plot.subtitle =
        element_text(
          hjust = 0.5
        ),
      plot.title.position =
        "plot",
      legend.key =
        element_rect(
          colour = "black",
          fill = NA,
          linewidth = 0.3
        )
    )
}

profile_ai <- make_profile_panel(
  synthetic_points %>%
    filter(
      disease ==
        "aiv_poultry"
    ),
  "A. Avian influenza"
)

profile_asf <- make_profile_panel(
  synthetic_points %>%
    filter(
      disease ==
        "asf"
    ),
  "B. African swine fever"
)

country_profile_plot <-
  (
    guide_area() /
      (
        profile_ai +
          profile_asf
      )
  ) +
  plot_layout(
    guides =
      "collect",
    heights =
      c(
        0.14,
        1
      )
  ) +
  plot_annotation(
    title =
      "Preparedness-Challenge profiles across countries",
    subtitle =
      paste0(
        "Solid diagonal line shows zero balance, dashed vertical line shows disease-specific median Challenge Index;\n",
        "Disease-specific medians and profile counts are real, point positions within profiles are illustrative"
      ),
    theme =
      theme(
        plot.title =
          element_text(
            face = "bold",
            size = 12,
            hjust = 0.5
          ),
        plot.subtitle =
          element_text(
            size = 10,
            hjust = 0.5
          ),
        plot.title.position =
          "plot"
      )
  ) &
  theme(
    legend.position =
      "top",
    legend.direction =
      "horizontal",
    legend.key.spacing.x =
      grid::unit(
        0.5,
        "cm"
      ),
    legend.box.margin =
      margin(
        t = 0,
        b = 0
      )
  )

save_plot(
  country_profile_plot,
  "country_profiles.png",
  width = 10,
  height = 6
)

# ==============================================================================
# 6. Regional composition of country-level profiles
# ==============================================================================

regional_profile_country_data <- real_profile_data %>%
  left_join(
    region_key,
    by =
      "country_name"
  ) %>%
  left_join(
    secondary_data,
    by =
      "country_name"
  ) %>%
  mutate(
    livestock_weight =
      case_when(
        disease ==
          "aiv_poultry" ~
          stock_poultry,
        disease ==
          "asf" ~
          stock_pigs,
        TRUE ~
          NA_real_
      )
  )

invalid_regional_inputs <- regional_profile_country_data %>%
  filter(
    is.na(
      region
    ) |
      !is.finite(
        livestock_weight
      ) |
      livestock_weight < 0
  )

if (
  nrow(
    invalid_regional_inputs
  ) > 0L
) {
  stop(
    "Missing region assignment or invalid livestock weight for at least one country × disease.",
    call. = FALSE
  )
}

regional_unweighted <- regional_profile_country_data %>%
  count(
    region,
    disease,
    profile,
    name =
      "profile_value"
  ) %>%
  complete(
    nesting(
      region,
      disease
    ),
    profile =
      profile_levels,
    fill = list(
      profile_value = 0
    )
  ) %>%
  group_by(
    region,
    disease
  ) %>%
  mutate(
    profile_share =
      profile_value /
      sum(
        profile_value
      )
  ) %>%
  ungroup() %>%
  mutate(
    weighting_scheme =
      "A. Unweighted regional composition",
    "Share of countries"
  )

regional_weighted <- regional_profile_country_data %>%
  group_by(
    region,
    disease,
    profile
  ) %>%
  summarise(
    profile_value =
      sum(
        livestock_weight,
        na.rm = TRUE
      ),
    .groups =
      "drop"
  ) %>%
  complete(
    nesting(
      region,
      disease
    ),
    profile =
      profile_levels,
    fill = list(
      profile_value = 0
    )
  ) %>%
  group_by(
    region,
    disease
  ) %>%
  mutate(
    regional_total =
      sum(
        profile_value
      ),
    profile_share =
      profile_value /
      regional_total
  ) %>%
  ungroup()

if (
  any(
    !is.finite(
      regional_weighted$profile_share
    )
  )
) {
  stop(
    "At least one region has no positive disease-specific livestock total.",
    call. = FALSE
  )
}

regional_weighted <- regional_weighted %>%
  mutate(
    weighting_scheme =
      "B. Livestock-weighted regional composition"
  ) %>%
  select(
    -regional_total
  )

regional_plot_data <- bind_rows(
  regional_unweighted,
  regional_weighted
) %>%
  mutate(
    disease_label =
      factor(
        recode(
          disease,
          !!!disease_labels
        ),
        levels = c(
          "Avian influenza",
          "African swine fever"
        )
      ),
    region =
      factor(
        region,
        levels =
          region_levels
      ),
    region_label =
      factor(
        sub(
          " Europe$",
          "\nEurope",
          as.character(
            region
          )
        ),
        levels =
          sub(
            " Europe$",
            "\nEurope",
            region_levels
          )
      ),
    profile =
      factor(
        profile,
        levels = c(
          "Prepared (low challenge)",
          "Underprepared (low challenge)",
          "Prepared (high challenge)",
          "Underprepared (high challenge)"
        )
      ),
    weighting_scheme =
      factor(
        weighting_scheme,
        levels = c(
          "A. Unweighted regional composition",
          "B. Livestock-weighted regional composition"
        )
      )
  )

regional_share_check <- regional_plot_data %>%
  group_by(
    weighting_scheme,
    region,
    disease
  ) %>%
  summarise(
    share_sum =
      sum(
        profile_share
      ),
    .groups =
      "drop"
  )

if (
  any(
    abs(
      regional_share_check$share_sum -
        1
    ) > 1e-10
  )
) {
  stop(
    "Regional profile shares do not sum to 1.",
    call. = FALSE
  )
}

make_regional_panel <- function(
    data,
    panel_title,
    y_axis_label
) {
  ggplot(
    data,
    aes(
      x =
        region_label,
      y =
        profile_share,
      fill =
        profile
    )
  ) +
    geom_col(
      width = 0.72,
      colour = NA
    ) +
    geom_col(
      data =
        data %>%
        distinct(
          region_label,
          disease_label
        ) %>%
        mutate(
          outline_height = 1
        ),
      aes(
        x =
          region_label,
        y =
          outline_height
      ),
      inherit.aes = FALSE,
      width = 0.72,
      fill = NA,
      colour = "black",
      linewidth = 0.5
    ) +
    facet_wrap(
      ~ disease_label,
      ncol = 2,
      axes = "all_y",
      axis.labels = "margins"
    ) +
    scale_y_continuous(
      breaks = c(
        0,
        0.25,
        0.50,
        0.75,
        1
      ),
      labels =
        percent_format(
          accuracy = 1
        ),
      expand =
        expansion(
          mult = c(
            0,
            0
          )
        )
    ) +
    coord_cartesian(
      ylim = c(
        0,
        1
      ),
      clip = "off"
    ) +
    scale_fill_manual(
      values =
        profile_colors,
      breaks =
        profile_levels,
      drop = FALSE
    ) +
    labs(
      title =
        panel_title,
      x =
        NULL,
      y =
        y_axis_label,
      fill =
        "Preparedness-Challenge profile"
    ) +
    base_theme() +
    theme(
      axis.line =
        element_line(
          colour = "black",
          linewidth = 0.5
        ),
      axis.ticks =
        element_line(
          colour = "black",
          linewidth = 0.5
        ),
      axis.ticks.length =
        grid::unit(
          0.15,
          "cm"
        ),
      axis.text.x =
        element_text(
          hjust = 0.5
        ),
      legend.key =
        element_rect(
          colour = "black",
          fill = NA,
          linewidth = 0.3
        ),
      plot.title =
        element_text(
          face = "bold",
          hjust = 0.5,
          size = 10
        ),
      plot.subtitle =
        element_text(
          hjust = 0.5
        ),
      plot.title.position =
        "plot",
      strip.text =
        element_text(
          face = "bold",
          hjust = 0.5
        )
    ) +
    guides(
      fill =
        guide_legend(
          title.position =
            "bottom",
          title.hjust =
            0.5,
          byrow =
            TRUE
        )
    )
}

regional_unweighted_plot <-
  make_regional_panel(
    regional_plot_data %>%
      filter(
        weighting_scheme ==
          "A. Unweighted regional composition"
      ),
    "A. Unweighted regional composition",
    "Share of countries"
  )

regional_weighted_plot <-
  make_regional_panel(
    regional_plot_data %>%
      filter(
        weighting_scheme ==
          "B. Livestock-weighted regional composition"
      ),
    "B. Livestock-weighted regional composition",
    "Share of livestock population"
  )

regional_profile_plot <-
  (
    guide_area() /
      regional_unweighted_plot /
      regional_weighted_plot
  ) +
  plot_layout(
    guides =
      "collect",
    heights =
      c(
        0.18,
        1,
        1
      )
  ) +
  plot_annotation(
    title =
      "Regional composition of country-level Preparedness-Challenge profiles",
    theme =
      theme(
        plot.title =
          element_text(
            face = "bold",
            hjust = 0.5,
            size = 12
          ),
        plot.subtitle =
          element_text(
            hjust = 0.5
          ),
        plot.title.position =
          "plot"
      )
  ) &
  theme(
    legend.position =
      "top",
    legend.direction =
      "horizontal",
    legend.key.spacing.x =
      grid::unit(
        0.5,
        "cm"
      ),
    legend.box.margin =
      margin(
        t = 0,
        b = 0
      )
  )

save_plot(
  regional_profile_plot,
  "regional_profile_composition.png",
  width = 9,
  height = 8
)

message(
  "\nDeterministic preparedness-profile plots completed.\n",
  "Outputs:\n",
  "  ",
  file.path(
    plot_dir,
    "country_profiles.png"
  ),
  "\n  ",
  file.path(
    plot_dir,
    "regional_profile_composition.png"
  ),
  "\n"
)
