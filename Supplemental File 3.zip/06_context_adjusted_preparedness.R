# ==============================================================================
# 06_context_adjusted_preparedness.R
#
# PURPOSE
# Construct disease-specific Context-adjusted preparedness by combining
# questionnaire-derived Preparedness capacity with the Contextual Index.
#
# INPUTS
# data/exported/raw_irt_factor_scores_long.csv
# results/indices/contextual_index.csv
#
# OUTPUT
# results/indices/context_adjusted_preparedness.csv
# ==============================================================================

suppressPackageStartupMessages({
  library(dplyr)
  library(readr)
})

# ==============================================================================
# 1. Paths and settings
# ==============================================================================

irt_file <- file.path(
  "data",
  "exported",
  "raw_irt_factor_scores_long.csv"
)

context_file <- file.path(
  "results",
  "indices",
  "contextual_index.csv"
)

output_dir <- file.path(
  "results",
  "indices"
)

output_file <- file.path(
  output_dir,
  "context_adjusted_preparedness.csv"
)

analysis_model <- "overall_preparedness"
required_diseases <- c("asf", "aiv_poultry")

scale_lower <- 0.05
scale_upper <- 0.95

preparedness_capacity_weight <- 0.50
context_weight <- 0.50

dir.create(
  output_dir,
  recursive = TRUE,
  showWarnings = FALSE
)

# ==============================================================================
# 2. Helpers
# ==============================================================================

read_required_csv <- function(path) {
  if (!file.exists(path)) {
    stop(
      "Required input file was not found: ",
      path,
      call. = FALSE
    )
  }

  read_csv(
    path,
    show_col_types = FALSE,
    progress = FALSE
  )
}

check_required_columns <- function(
    data,
    required_columns,
    object_name
) {
  missing_columns <- setdiff(
    required_columns,
    names(data)
  )

  if (length(missing_columns) > 0L) {
    stop(
      object_name,
      " is missing required columns: ",
      paste(missing_columns, collapse = ", "),
      call. = FALSE
    )
  }
}

rank_scale <- function(
    x,
    lower = scale_lower,
    upper = scale_upper
) {
  output <- rep(
    NA_real_,
    length(x)
  )

  usable <- is.finite(x)

  if (sum(usable) < 2L) {
    return(output)
  }

  x_use <- x[usable]

  if (length(unique(x_use)) == 1L) {
    output[usable] <- (lower + upper) / 2
    return(output)
  }

  output[usable] <-
    lower +
    (upper - lower) *
    (rank(x_use, ties.method = "average") - 1) /
    (length(x_use) - 1)

  output
}

standardize_country_name <- function(x) {
  recode(
    as.character(x),
    "Czech Republic" = "Czechia",
    "Turkiye" = "Türkiye",
    "Turkey" = "Türkiye",
    "Slovak Republic" = "Slovakia",
    "Russian Federation" = "Russia",
    .default = as.character(x)
  )
}

# ==============================================================================
# 3. Read and validate inputs
# ==============================================================================

irt_scores <- read_required_csv(
  irt_file
)

context <- read_required_csv(
  context_file
)

check_required_columns(
  irt_scores,
  c(
    "country_name",
    "disease",
    "model",
    "score"
  ),
  "raw_irt_factor_scores_long.csv"
)

check_required_columns(
  context,
  c(
    "country_name",
    "contextual_index"
  ),
  "contextual_index.csv"
)

irt_scores <- irt_scores %>%
  mutate(
    country_name = standardize_country_name(country_name)
  ) %>%
  filter(
    model == analysis_model,
    disease %in% required_diseases
  ) %>%
  transmute(
    country_name,
    disease,
    preparedness_capacity_latent = as.numeric(score)
  )

context <- context %>%
  transmute(
    country_name = standardize_country_name(country_name),
    contextual_index = as.numeric(contextual_index)
  )

if (
  anyDuplicated(
    irt_scores[
      c(
        "country_name",
        "disease"
      )
    ]
  ) > 0L
) {
  stop(
    "IRT input contains duplicate country × disease rows.",
    call. = FALSE
  )
}

if (anyDuplicated(context$country_name) > 0L) {
  stop(
    "Contextual Index input contains duplicate countries.",
    call. = FALSE
  )
}

missing_diseases <- setdiff(
  required_diseases,
  unique(irt_scores$disease)
)

if (length(missing_diseases) > 0L) {
  stop(
    "IRT input is missing required diseases: ",
    paste(missing_diseases, collapse = ", "),
    call. = FALSE
  )
}

if (
  anyNA(context$contextual_index) ||
    any(!is.finite(context$contextual_index))
) {
  stop(
    "Contextual Index values must be complete and finite.",
    call. = FALSE
  )
}

if (
  any(
    context$contextual_index <
      100 * scale_lower - 1e-10 |
      context$contextual_index >
        100 * scale_upper + 1e-10
  )
) {
  stop(
    "Contextual Index values fall outside the expected 5-95 range.",
    call. = FALSE
  )
}

if (
  preparedness_capacity_weight <= 0 ||
    context_weight <= 0 ||
    abs(
      preparedness_capacity_weight +
        context_weight -
        1
    ) > 1e-12
) {
  stop(
    "Preparedness-capacity and context weights must be positive and sum to 1.",
    call. = FALSE
  )
}

missing_context_countries <- setdiff(
  unique(irt_scores$country_name),
  context$country_name
)

if (length(missing_context_countries) > 0L) {
  stop(
    "Countries with IRT results but no Contextual Index: ",
    paste(missing_context_countries, collapse = ", "),
    call. = FALSE
  )
}

# ==============================================================================
# 4. Construct Context-adjusted preparedness
# ==============================================================================

context_adjusted_preparedness <- irt_scores %>%
  left_join(
    context,
    by = "country_name"
  ) %>%
  group_by(
    disease
  ) %>%
  mutate(
    preparedness_capacity_scaled =
      rank_scale(
        preparedness_capacity_latent
      ),
    preparedness_capacity_index =
      100 * preparedness_capacity_scaled,
    contextual_scaled =
      contextual_index / 100,
    context_adjusted_preparedness_scaled =
      (preparedness_capacity_scaled ^
         preparedness_capacity_weight) *
      (contextual_scaled ^
         context_weight),
    context_adjusted_preparedness =
      100 *
      context_adjusted_preparedness_scaled
  ) %>%
  ungroup() %>%
  arrange(
    disease,
    desc(context_adjusted_preparedness),
    country_name
  )

valid_rows <- context_adjusted_preparedness %>%
  filter(
    !is.na(context_adjusted_preparedness)
  )

if (
  any(
    valid_rows$preparedness_capacity_index <
      100 * scale_lower - 1e-10 |
      valid_rows$preparedness_capacity_index >
        100 * scale_upper + 1e-10
  )
) {
  stop(
    "Preparedness capacity index values fall outside the expected 5-95 range.",
    call. = FALSE
  )
}

if (
  any(
    valid_rows$context_adjusted_preparedness <
      100 * scale_lower - 1e-10 |
      valid_rows$context_adjusted_preparedness >
        100 * scale_upper + 1e-10
  )
) {
  stop(
    "Context-adjusted preparedness values fall outside the expected 5-95 range.",
    call. = FALSE
  )
}

# ==============================================================================
# 5. Export
# ==============================================================================

write_csv(
  context_adjusted_preparedness,
  output_file
)

message(
  "\nContext-adjusted preparedness completed.\n",
  "Output:\n  ",
  output_file,
  "\n"
)
