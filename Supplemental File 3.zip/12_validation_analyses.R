# ==============================================================================
# 12_validation_analyses.R
#
# PURPOSE
# Validate the Preparedness-challenge framework using recorded disease history.
#
# Two complementary analyses are retained:
# 1. Continuous Preparedness-challenge balance versus any recorded outbreak,
#    summarized using apparent AUC.
# 2. Country-profile contrasts versus quantitative WAHIS disease burden,
#    summarized using pairwise concordance probabilities.
#
# Validation periods are treated equally:
# 2015–2019, 2020–2024, and 2015–2024.
#
# INPUTS
# results/preparedness_challenge/preparedness_challenge_comparison.csv
# data/exported/data_secondary.csv
# WAHIS infur_20250224.xlsx
#
# OUTPUTS
# results/balance_validation/validation_balance_auc.csv
# results/balance_validation/validation_profile_concordance.csv
# ==============================================================================

suppressPackageStartupMessages({
  library(dplyr)
  library(tidyr)
  library(readr)
  library(readxl)
  library(purrr)
  library(tibble)
})

# ==============================================================================
# 1. Paths and analysis definitions
# ==============================================================================

comparison_file <- file.path(
  "results",
  "preparedness_challenge",
  "preparedness_challenge_comparison.csv"
)

secondary_file <- file.path(
  "data",
  "exported",
  "data_secondary.csv"
)

output_dir <- file.path(
  "results",
  "balance_validation"
)

dir.create(
  output_dir,
  recursive = TRUE,
  showWarnings = FALSE
)

required_diseases <- c(
  "asf",
  "aiv_poultry"
)

period_levels <- c(
  "2015–2019",
  "2020–2024",
  "2015–2024"
)

outcome_map <- tibble(
  disease = rep(
    required_diseases,
    each = 3
  ),
  outbreak_variable = c(
    "asf_2015_2019",
    "asf_2020_2024",
    "asf_2015_2024",
    "aiv_2015_2019",
    "aiv_2020_2024",
    "aiv_2015_2024"
  ),
  validation_period = rep(
    period_levels,
    2
  )
)

period_table <- tibble(
  validation_period = factor(
    period_levels,
    levels = period_levels
  ),
  period_start = as.Date(
    c(
      "2015-01-01",
      "2020-01-01",
      "2015-01-01"
    )
  ),
  period_end = as.Date(
    c(
      "2019-12-31",
      "2024-12-31",
      "2024-12-31"
    )
  ),
  period_years = c(
    5,
    5,
    10
  )
)

profile_contrasts <- tribble(
  ~contrast_id, ~contrast_label, ~prepared_profile, ~underprepared_profile,
  "concordant",
  "Concordant contrast",
  "Prepared (low challenge)",
  "Underprepared (high challenge)",
  "discordant",
  "Discordant contrast",
  "Prepared (high challenge)",
  "Underprepared (low challenge)"
)

# ==============================================================================
# 2. Helpers
# ==============================================================================

read_required_csv <- function(path) {
  if (!file.exists(path)) {
    stop(
      "Required input file was not found: ",
      path,
      call. = FALSE
    )
  }

  read_csv(
    path,
    show_col_types = FALSE,
    progress = FALSE
  )
}

check_required_columns <- function(
    data,
    required_columns,
    object_name
) {
  missing_columns <- setdiff(
    required_columns,
    names(data)
  )

  if (length(missing_columns) > 0L) {
    stop(
      object_name,
      " is missing required columns: ",
      paste(missing_columns, collapse = ", "),
      call. = FALSE
    )
  }
}

check_unique_keys <- function(
    data,
    keys,
    object_name
) {
  duplicates <- data %>%
    count(
      across(
        all_of(keys)
      )
    ) %>%
    filter(
      n != 1L
    )

  if (nrow(duplicates) > 0L) {
    stop(
      object_name,
      " must contain exactly one row per ",
      paste(keys, collapse = " × "),
      ".",
      call. = FALSE
    )
  }
}

standardize_country_name <- function(x) {
  recode(
    as.character(x),
    "Czech Republic" = "Czechia",
    "Turkiye" = "Türkiye",
    "Turkey" = "Türkiye",
    "Slovak Republic" = "Slovakia",
    "Russian Federation" = "Russia",
    .default = as.character(x)
  )
}

standardize_disease <- function(x) {
  x <- tolower(
    trimws(
      as.character(x)
    )
  )

  case_when(
    x %in% c(
      "asf",
      "african swine fever"
    ) ~ "asf",

    x %in% c(
      "aiv",
      "ai",
      "aiv_poultry",
      "avian influenza",
      "avian influenza in poultry",
      "avian influenza poultry"
    ) ~ "aiv_poultry",

    TRUE ~ x
  )
}

safe_auc <- function(
    observed,
    predicted
) {
  keep <- complete.cases(
    observed,
    predicted
  )

  observed <- observed[keep]
  predicted <- predicted[keep]

  if (
    length(observed) < 3L ||
      length(unique(observed)) != 2L
  ) {
    return(
      NA_real_
    )
  }

  positive <- predicted[
    observed == 1L
  ]

  negative <- predicted[
    observed == 0L
  ]

  if (
    length(positive) == 0L ||
      length(negative) == 0L
  ) {
    return(
      NA_real_
    )
  }

  comparisons <- outer(
    positive,
    negative,
    "-"
  )

  (
    sum(
      comparisons > 0
    ) +
      0.5 *
      sum(
        comparisons == 0
      )
  ) /
    length(
      comparisons
    )
}

fit_auc <- function(data) {
  model_data <- data %>%
    filter(
      complete.cases(
        preparedness_challenge_balance,
        any_outbreak
      )
    )

  if (
    nrow(model_data) < 6L ||
      length(
        unique(
          model_data$any_outbreak
        )
      ) != 2L ||
      length(
        unique(
          model_data$preparedness_challenge_balance
        )
      ) < 3L
  ) {
    return(
      tibble(
        countries = nrow(
          model_data
        ),
        apparent_auc = NA_real_
      )
    )
  }

  fit <- suppressWarnings(
    glm(
      any_outbreak ~
        preparedness_challenge_balance,
      data = model_data,
      family = binomial()
    )
  )

  tibble(
    countries = nrow(
      model_data
    ),
    apparent_auc = safe_auc(
      model_data$any_outbreak,
      predict(
        fit,
        type = "response"
      )
    )
  )
}

locate_wahis_file <- function() {
  preferred <- c(
    file.path(
      "data",
      "secondary",
      "infur_20250224.xlsx"
    ),
    file.path(
      "data",
      "raw",
      "secondary",
      "infur_20250224.xlsx"
    ),
    file.path(
      "data",
      "infur_20250224.xlsx"
    ),
    "infur_20250224.xlsx"
  )

  existing <- preferred[
    file.exists(
      preferred
    )
  ]

  if (
    length(
      existing
    ) > 0L
  ) {
    return(
      existing[[1]]
    )
  }

  discovered <- list.files(
    "data",
    pattern = "^infur_20250224\\.xlsx$",
    recursive = TRUE,
    full.names = TRUE
  )

  if (
    length(
      discovered
    ) == 1L
  ) {
    return(
      discovered[[1]]
    )
  }

  if (
    length(
      discovered
    ) == 0L
  ) {
    stop(
      "Could not locate infur_20250224.xlsx under data/.",
      call. = FALSE
    )
  }

  stop(
    "Multiple copies of infur_20250224.xlsx were found under data/.",
    call. = FALSE
  )
}

union_active_days <- function(
    start_date,
    end_date
) {
  keep <- complete.cases(
    start_date,
    end_date
  )

  start_date <- as.Date(
    start_date[keep]
  )

  end_date <- as.Date(
    end_date[keep]
  )

  valid <-
    end_date >= start_date

  start_date <-
    start_date[valid]

  end_date <-
    end_date[valid]

  if (
    length(
      start_date
    ) == 0L
  ) {
    return(
      0
    )
  }

  ord <- order(
    start_date,
    end_date
  )

  start_date <- start_date[ord]
  end_date <- end_date[ord]

  current_start <- start_date[[1]]
  current_end <- end_date[[1]]
  total_days <- 0

  if (
    length(
      start_date
    ) > 1L
  ) {
    for (
      i in 2:length(
        start_date
      )
    ) {
      if (
        start_date[[i]] <=
          current_end + 1
      ) {
        current_end <- max(
          current_end,
          end_date[[i]]
        )
      } else {
        total_days <-
          total_days +
          as.numeric(
            current_end -
              current_start
          ) +
          1

        current_start <-
          start_date[[i]]

        current_end <-
          end_date[[i]]
      }
    }
  }

  total_days +
    as.numeric(
      current_end -
        current_start
    ) +
    1
}

summarise_temporal_outcomes <- function(
    outbreaks,
    period_start,
    period_end,
    period_years
) {
  period_start <- as.Date(
    period_start
  )

  period_end <- as.Date(
    period_end
  )

  total_period_days <-
    as.numeric(
      period_end -
        period_start
    ) +
    1

  if (
    nrow(
      outbreaks
    ) == 0L
  ) {
    return(
      tibble(
        outbreak_frequency_per_year = 0,
        active_year_proportion = 0,
        active_day_proportion = 0
      )
    )
  }

  outbreaks <- outbreaks %>%
    mutate(
      outbreak_start =
        as.Date(
          outbreak_start
        ),
      outbreak_end =
        as.Date(
          outbreak_end
        ),
      invalid_end_date =
        !is.na(
          outbreak_end
        ) &
        outbreak_end <
          outbreak_start
    )

  starting <- outbreaks %>%
    filter(
      outbreak_start >=
        period_start,
      outbreak_start <=
        period_end
    )

  active <- outbreaks %>%
    mutate(
      persistence_end = case_when(
        invalid_end_date ~
          outbreak_start,
        is.na(
          outbreak_end
        ) ~
          period_end,
        TRUE ~
          outbreak_end
      ),
      clipped_start = pmax(
        outbreak_start,
        period_start
      ),
      clipped_end = pmin(
        persistence_end,
        period_end
      )
    ) %>%
    filter(
      clipped_start <=
        period_end,
      clipped_end >=
        period_start,
      clipped_end >=
        clipped_start
    )

  active_days <- union_active_days(
    active$clipped_start,
    active$clipped_end
  )

  years <- seq(
    as.integer(
      format(
        period_start,
        "%Y"
      )
    ),
    as.integer(
      format(
        period_end,
        "%Y"
      )
    )
  )

  active_years <- sum(
    vapply(
      years,
      function(year_value) {
        year_start <- as.Date(
          sprintf(
            "%d-01-01",
            year_value
          )
        )

        year_end <- as.Date(
          sprintf(
            "%d-12-31",
            year_value
          )
        )

        if (
          nrow(
            active
          ) == 0L
        ) {
          return(
            FALSE
          )
        }

        any(
          active$clipped_start <=
            year_end &
            active$clipped_end >=
              year_start
        )
      },
      logical(1)
    )
  )

  tibble(
    outbreak_frequency_per_year =
      nrow(
        starting
      ) /
      period_years,
    active_year_proportion =
      active_years /
      period_years,
    active_day_proportion =
      active_days /
      total_period_days
  )
}

profile_concordance <- function(
    profile,
    burden,
    prepared_profile,
    underprepared_profile
) {
  keep <- complete.cases(
    profile,
    burden
  )

  profile <- as.character(
    profile[keep]
  )

  burden <- burden[keep]

  prepared_burden <- burden[
    profile ==
      prepared_profile
  ]

  underprepared_burden <- burden[
    profile ==
      underprepared_profile
  ]

  n_prepared <- length(
    prepared_burden
  )

  n_underprepared <- length(
    underprepared_burden
  )

  if (
    n_prepared == 0L ||
      n_underprepared == 0L
  ) {
    return(
      tibble(
        n_prepared = n_prepared,
        n_underprepared =
          n_underprepared,
        comparable_pairs = 0L,
        concordance_probability =
          NA_real_
      )
    )
  }

  comparisons <- outer(
    underprepared_burden,
    prepared_burden,
    "-"
  )

  tibble(
    n_prepared = n_prepared,
    n_underprepared =
      n_underprepared,
    comparable_pairs =
      length(
        comparisons
      ),
    concordance_probability =
      (
        sum(
          comparisons > 0
        ) +
          0.5 *
          sum(
            comparisons == 0
          )
      ) /
      length(
        comparisons
      )
  )
}

# ==============================================================================
# 3. Prepare deterministic preparedness-challenge profiles
# ==============================================================================

comparison_data <- read_required_csv(
  comparison_file
)

check_required_columns(
  comparison_data,
  c(
    "country_name",
    "disease",
    "challenge_index",
    "preparedness_challenge_balance"
  ),
  "preparedness_challenge_comparison.csv"
)

comparison_data <- comparison_data %>%
  transmute(
    country_name =
      standardize_country_name(
        country_name
      ),
    disease =
      standardize_disease(
        disease
      ),
    challenge_index =
      as.numeric(
        challenge_index
      ),
    preparedness_challenge_balance =
      as.numeric(
        preparedness_challenge_balance
      )
  ) %>%
  filter(
    disease %in%
      required_diseases
  ) %>%
  group_by(
    disease
  ) %>%
  mutate(
    challenge_median =
      median(
        challenge_index,
        na.rm = TRUE
      ),
    profile = case_when(
      preparedness_challenge_balance >= 0 &
        challenge_index <
          challenge_median ~
        "Prepared (low challenge)",

      preparedness_challenge_balance >= 0 &
        challenge_index >=
          challenge_median ~
        "Prepared (high challenge)",

      preparedness_challenge_balance < 0 &
        challenge_index <
          challenge_median ~
        "Underprepared (low challenge)",

      preparedness_challenge_balance < 0 &
        challenge_index >=
          challenge_median ~
        "Underprepared (high challenge)",

      TRUE ~
        NA_character_
    )
  ) %>%
  ungroup()

check_unique_keys(
  comparison_data,
  c(
    "country_name",
    "disease"
  ),
  "Preparedness-challenge comparison data"
)

if (
  anyNA(
    comparison_data$profile
  )
) {
  stop(
    "At least one country could not be assigned to a preparedness-challenge profile.",
    call. = FALSE
  )
}

# ==============================================================================
# 4. Continuous balance validation: apparent AUC
# ==============================================================================

secondary_data <- read_required_csv(
  secondary_file
)

source_outbreak_variables <- c(
  "asf_recent_5yr",
  "asf_events_10yr",
  "aiv_recent_5yr",
  "aiv_events_10yr"
)

check_required_columns(
  secondary_data,
  c(
    "country_name",
    source_outbreak_variables
  ),
  "data_secondary.csv"
)

secondary_data <- secondary_data %>%
  transmute(
    country_name =
      standardize_country_name(
        country_name
      ),
    across(
      all_of(
        source_outbreak_variables
      ),
      as.numeric
    )
  ) %>%
  mutate(
    asf_2015_2019 =
      asf_events_10yr -
      asf_recent_5yr,

    asf_2020_2024 =
      asf_recent_5yr,

    asf_2015_2024 =
      asf_events_10yr,

    aiv_2015_2019 =
      aiv_events_10yr -
      aiv_recent_5yr,

    aiv_2020_2024 =
      aiv_recent_5yr,

    aiv_2015_2024 =
      aiv_events_10yr
  )

if (
  any(
    secondary_data$asf_2015_2019 < 0,
    na.rm = TRUE
  ) ||
    any(
      secondary_data$aiv_2015_2019 < 0,
      na.rm = TRUE
    )
) {
  stop(
    "At least one derived 2015–2019 outbreak count is negative.",
    call. = FALSE
  )
}

check_unique_keys(
  secondary_data,
  "country_name",
  "data_secondary.csv"
)

outbreak_long <- secondary_data %>%
  pivot_longer(
    cols =
      all_of(
        outcome_map$outbreak_variable
      ),
    names_to =
      "outbreak_variable",
    values_to =
      "outbreak_events"
  ) %>%
  left_join(
    outcome_map,
    by = "outbreak_variable"
  ) %>%
  filter(
    !is.na(
      disease
    )
  ) %>%
  mutate(
    validation_period = factor(
      validation_period,
      levels = period_levels
    ),
    any_outbreak =
      as.integer(
        outbreak_events > 0
      )
  )

balance_auc <- comparison_data %>%
  select(
    country_name,
    disease,
    preparedness_challenge_balance
  ) %>%
  inner_join(
    outbreak_long,
    by = c(
      "country_name",
      "disease"
    )
  ) %>%
  group_by(
    disease,
    validation_period
  ) %>%
  group_modify(
    ~ fit_auc(.x)
  ) %>%
  ungroup() %>%
  arrange(
    factor(
      disease,
      levels = required_diseases
    ),
    validation_period
  )

write_csv(
  balance_auc,
  file.path(
    output_dir,
    "validation_balance_auc.csv"
  )
)

# ==============================================================================
# 5. WAHIS temporal disease-burden outcomes
# ==============================================================================

wahis_file <- locate_wahis_file()

wahis_raw <- read_excel(
  wahis_file,
  sheet = "infur_20250224"
)

check_required_columns(
  wahis_raw,
  c(
    "disease_eng",
    "country_name",
    "is_wild",
    "Outbreak_id",
    "Outbreak_start_date",
    "Outbreak_end_date"
  ),
  "WAHIS infur_20250224 sheet"
)

wahis_disease_map <- tibble(
  disease = c(
    "asf",
    "aiv_poultry",
    "aiv_poultry",
    "aiv_poultry"
  ),
  disease_eng = c(
    "African swine fever virus (Inf. with)",
    "High pathogenicity avian influenza viruses (poultry) (Inf. with)",
    "Low pathogenic avian influenza (poultry) (2006-2021)",
    "Influenza A virus (Inf. with)"
  )
)

study_countries <- sort(
  unique(
    comparison_data$country_name
  )
)

domestic_outbreaks <- wahis_raw %>%
  transmute(
    country_name =
      standardize_country_name(
        country_name
      ),
    disease_eng =
      as.character(
        disease_eng
      ),
    is_domestic =
      tolower(
        trimws(
          as.character(
            is_wild
          )
        )
      ) %in%
      c(
        "false",
        "0",
        "no"
      ),
    outbreak_id =
      as.character(
        Outbreak_id
      ),
    outbreak_start =
      as.Date(
        Outbreak_start_date
      ),
    outbreak_end =
      as.Date(
        Outbreak_end_date
      )
  ) %>%
  inner_join(
    wahis_disease_map,
    by = "disease_eng"
  ) %>%
  filter(
    is_domestic,
    country_name %in%
      study_countries,
    !is.na(
      outbreak_id
    ),
    !is.na(
      outbreak_start
    )
  ) %>%
  group_by(
    country_name,
    disease,
    outbreak_id
  ) %>%
  summarise(
    outbreak_start =
      min(
        outbreak_start,
        na.rm = TRUE
      ),
    outbreak_end =
      if (
        all(
          is.na(
            outbreak_end
          )
        )
      ) {
        as.Date(
          NA
        )
      } else {
        max(
          outbreak_end,
          na.rm = TRUE
        )
      },
    .groups = "drop"
  )

temporal_grid <- crossing(
  country_name =
    study_countries,
  disease =
    required_diseases
) %>%
  crossing(
    period_table
  )

temporal_metrics <- pmap_dfr(
  temporal_grid,
  function(
      country_name,
      disease,
      validation_period,
      period_start,
      period_end,
      period_years
  ) {
    country_outbreaks <-
      domestic_outbreaks %>%
      filter(
        .data$country_name ==
          .env$country_name,
        .data$disease ==
          .env$disease
      )

    bind_cols(
      tibble(
        country_name =
          country_name,
        disease =
          disease,
        validation_period =
          factor(
            as.character(
              validation_period
            ),
            levels =
              period_levels
          )
      ),
      summarise_temporal_outcomes(
        country_outbreaks,
        period_start,
        period_end,
        period_years
      )
    )
  }
)

temporal_qc <- temporal_metrics %>%
  group_by(
    disease,
    validation_period
  ) %>%
  summarise(
    total_frequency =
      sum(
        outbreak_frequency_per_year,
        na.rm = TRUE
      ),
    distinct_frequency =
      n_distinct(
        outbreak_frequency_per_year,
        na.rm = TRUE
      ),
    distinct_recurrence =
      n_distinct(
        active_year_proportion,
        na.rm = TRUE
      ),
    distinct_persistence =
      n_distinct(
        active_day_proportion,
        na.rm = TRUE
      ),
    .groups = "drop"
  )

if (
  any(
    temporal_qc$total_frequency > 0 &
      temporal_qc$distinct_frequency <= 1 &
      temporal_qc$distinct_recurrence <= 1 &
      temporal_qc$distinct_persistence <= 1
  )
) {
  stop(
    "WAHIS temporal QC failed: no between-country variation despite recorded domestic outbreaks.",
    call. = FALSE
  )
}

# ==============================================================================
# 6. Profile-contrast concordance
# ==============================================================================

temporal_long <- comparison_data %>%
  select(
    country_name,
    disease,
    profile
  ) %>%
  inner_join(
    temporal_metrics,
    by = c(
      "country_name",
      "disease"
    ),
    relationship = "many-to-many"
  ) %>%
  pivot_longer(
    cols = c(
      outbreak_frequency_per_year,
      active_year_proportion,
      active_day_proportion
    ),
    names_to =
      "burden_measure",
    values_to =
      "burden_value"
  ) %>%
  mutate(
    burden_measure = recode(
      burden_measure,
      outbreak_frequency_per_year =
        "Frequency",
      active_year_proportion =
        "Recurrence",
      active_day_proportion =
        "Persistence"
    ),
    burden_measure = factor(
      burden_measure,
      levels = c(
        "Frequency",
        "Recurrence",
        "Persistence"
      )
    )
  )

profile_concordance_results <- temporal_long %>%
  group_by(
    disease,
    validation_period,
    burden_measure
  ) %>%
  group_modify(
    function(.x, .y) {
      bind_rows(
        lapply(
          seq_len(
            nrow(
              profile_contrasts
            )
          ),
          function(i) {
            definition <-
              profile_contrasts[
                i,
              ]

            profile_concordance(
              profile =
                .x$profile,
              burden =
                .x$burden_value,
              prepared_profile =
                definition$prepared_profile[[1]],
              underprepared_profile =
                definition$underprepared_profile[[1]]
            ) %>%
              mutate(
                contrast_id =
                  definition$contrast_id[[1]],
                contrast_label =
                  definition$contrast_label[[1]],
                prepared_profile =
                  definition$prepared_profile[[1]],
                underprepared_profile =
                  definition$underprepared_profile[[1]],
                .before = 1
              )
          }
        )
      )
    }
  ) %>%
  ungroup() %>%
  arrange(
    factor(
      disease,
      levels = required_diseases
    ),
    contrast_id,
    burden_measure,
    validation_period
  )

write_csv(
  profile_concordance_results,
  file.path(
    output_dir,
    "validation_profile_concordance.csv"
  )
)

message(
  "\nValidation analyses completed.\n",
  "Outputs:\n",
  "  ",
  file.path(
    output_dir,
    "validation_balance_auc.csv"
  ),
  "\n  ",
  file.path(
    output_dir,
    "validation_profile_concordance.csv"
  ),
  "\n"
)
