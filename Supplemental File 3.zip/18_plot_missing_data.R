# ==============================================================================
# 18_plot_missing_data.R
#
# PURPOSE
# Plot regional completeness of the 15 conceptual preparedness-questionnaire
# items shown in Table 2 and the chord diagram.
#
# INPUTS
# data/exported/data_primary_long.csv
# data/mapping.xlsx
# data/region_key.csv
#
# OUTPUT
# results/plots/missing_data/missing_data_regional.png
# ==============================================================================

suppressPackageStartupMessages({
  library(dplyr)
  library(tidyr)
  library(readr)
  library(readxl)
  library(stringr)
  library(ggplot2)
  library(scales)
  library(grid)
})

# ==============================================================================
# 1. Paths and settings
# ==============================================================================

primary_file <- file.path(
  "data",
  "exported",
  "data_primary_long.csv"
)

mapping_file <- file.path(
  "data",
  "mapping.xlsx"
)

region_file <- file.path(
  "data",
  "region_key.csv"
)

plot_dir <- file.path(
  "results",
  "plots",
  "missing_data"
)

plot_dpi <- 600

regional_plot_width <- 6
regional_plot_height <- 7

region_levels <- c(
  "Central Europe",
  "Northern Europe",
  "Southern Europe",
  "Western Europe"
)

dir.create(
  plot_dir,
  recursive = TRUE,
  showWarnings = FALSE
)

# ==============================================================================
# 2. Helpers
# ==============================================================================

read_required_csv <- function(path) {
  if (!file.exists(path)) {
    stop(
      "Required input file was not found: ",
      path,
      call. = FALSE
    )
  }

  read_csv(
    path,
    show_col_types = FALSE,
    progress = FALSE,
    na = c(
      "",
      "NA"
    )
  )
}

check_required_columns <- function(
    data,
    required_columns,
    object_name
) {
  missing_columns <- setdiff(
    required_columns,
    names(data)
  )

  if (length(missing_columns) > 0L) {
    stop(
      object_name,
      " is missing required columns: ",
      paste(
        missing_columns,
        collapse = ", "
      ),
      call. = FALSE
    )
  }
}

normalize_text <- function(x) {
  x %>%
    as.character() %>%
    str_trim() %>%
    str_squish()
}

standardize_country_name <- function(x) {
  x <- normalize_text(
    x
  )

  recode(
    x,
    "Czech Republic" = "Czechia",
    "Turkiye" = "Türkiye",
    "Turkey" = "Türkiye",
    "Slovak Republic" = "Slovakia",
    "Russian Federation" = "Russia",
    .default = x
  )
}

prepared_item_name <- function(item_name) {
  recode(
    as.character(
      item_name
    ),
    "n_train_asf" =
      "g_train_asf",
    "n_train_aiv" =
      "g_train_aiv",
    .default =
      as.character(
        item_name
      )
  )
}

wrap_item_label <- function(
    x,
    width = 33
) {
  str_wrap(
    as.character(
      x
    ),
    width = width
  )
}

# ==============================================================================
# 3. Build the conceptual item key
# ==============================================================================

if (!file.exists(mapping_file)) {
  stop(
    "Required mapping file was not found: ",
    mapping_file,
    call. = FALSE
  )
}

mapping_raw <- read_excel(
  mapping_file
)

check_required_columns(
  mapping_raw,
  c(
    "item",
    "definition"
  ),
  "mapping.xlsx"
)

mapping_items <- mapping_raw %>%
  transmute(
    item =
      prepared_item_name(
        normalize_text(
          item
        )
      ),
    definition =
      normalize_text(
        definition
      )
  ) %>%
  filter(
    item != "",
    !is.na(
      definition
    ),
    definition != ""
  ) %>%
  distinct()

table2_item_definitions <- mapping_items %>%
  distinct(
    definition
  ) %>%
  pull(
    definition
  )

if (
  length(
    table2_item_definitions
  ) != 15L
) {
  stop(
    "mapping.xlsx must contain exactly 15 unique questionnaire definitions for the missing-data figure.",
    call. = FALSE
  )
}

item_order_table <- mapping_items %>%
  filter(
    definition %in%
      table2_item_definitions
  ) %>%
  group_by(
    definition
  ) %>%
  summarise(
    source_items =
      list(
        unique(
          item
        )
      ),
    .groups =
      "drop"
  ) %>%
  mutate(
    item_order =
      match(
        definition,
        table2_item_definitions
      )
  ) %>%
  arrange(
    item_order
  ) %>%
  mutate(
    item_id =
      paste0(
        "item_",
        sprintf(
          "%02d",
          row_number()
        )
      ),
    item_label =
      wrap_item_label(
        definition
      )
  )

if (
  nrow(
    item_order_table
  ) != 15L ||
    n_distinct(
      item_order_table$definition
    ) != 15L
) {
  stop(
    "The missing-data figure must contain exactly the 15 Table 2 questionnaire items.",
    call. = FALSE
  )
}

# ==============================================================================
# 4. Questionnaire-item completeness by country
# ==============================================================================

primary <- read_required_csv(
  primary_file
)

check_required_columns(
  primary,
  "country_name",
  "data_primary_long.csv"
)

primary <- primary %>%
  mutate(
    country_name =
      standardize_country_name(
        country_name
      )
  )

if (
  anyDuplicated(
    primary$country_name
  ) > 0L
) {
  stop(
    "data_primary_long.csv contains duplicate countries after name standardization.",
    call. = FALSE
  )
}

mapped_items <- unique(
  unlist(
    item_order_table$source_items,
    use.names = FALSE
  )
)

missing_items <- setdiff(
  mapped_items,
  names(
    primary
  )
)

if (
  length(
    missing_items
  ) > 0L
) {
  stop(
    "Mapped questionnaire items were not found in data_primary_long.csv: ",
    paste(
      missing_items,
      collapse = ", "
    ),
    call. = FALSE
  )
}

primary_source_long <- primary %>%
  select(
    country_name,
    all_of(
      mapped_items
    )
  ) %>%
  pivot_longer(
    cols =
      all_of(
        mapped_items
      ),
    names_to =
      "item",
    values_to =
      "value",
    values_transform =
      list(
        value =
          as.character
      )
  ) %>%
  mutate(
    present =
      !is.na(
        value
      )
  ) %>%
  select(
    country_name,
    item,
    present
  )

item_source_key <- item_order_table %>%
  select(
    item_id,
    definition,
    item_label,
    source_items
  ) %>%
  unnest(
    source_items
  ) %>%
  rename(
    item =
      source_items
  )

primary_long <- item_source_key %>%
  left_join(
    primary_source_long,
    by = "item",
    relationship = "many-to-many"
  ) %>%
  group_by(
    country_name,
    item_id,
    definition,
    item_label
  ) %>%
  summarise(
    present =
      all(
        present
      ),
    .groups =
      "drop"
  )

item_levels <- rev(
  item_order_table$item_id
)

# ==============================================================================
# 5. Regional completeness
# ==============================================================================

region_key <- read_required_csv(
  region_file
)

check_required_columns(
  region_key,
  c(
    "country_name",
    "region"
  ),
  "region_key.csv"
)

region_key <- region_key %>%
  transmute(
    country_name =
      standardize_country_name(
        country_name
      ),
    region =
      normalize_text(
        region
      )
  )

if (
  anyDuplicated(
    region_key$country_name
  ) > 0L
) {
  stop(
    "region_key.csv contains duplicate countries after name standardization.",
    call. = FALSE
  )
}

regional_plot_data <- primary_long %>%
  left_join(
    region_key,
    by =
      "country_name",
    relationship =
      "many-to-one"
  )

if (
  anyNA(
    regional_plot_data$region
  )
) {
  stop(
    "At least one questionnaire country is missing from data/region_key.csv.",
    call. = FALSE
  )
}

unexpected_regions <- setdiff(
  unique(
    regional_plot_data$region
  ),
  region_levels
)

if (
  length(
    unexpected_regions
  ) > 0L
) {
  stop(
    "Unexpected region labels in region_key.csv: ",
    paste(
      unexpected_regions,
      collapse = ", "
    ),
    call. = FALSE
  )
}

regional_plot_data <- regional_plot_data %>%
  group_by(
    region,
    item_id
  ) %>%
  summarise(
    n_countries =
      n(),
    n_present =
      sum(
        present
      ),
    prop_present =
      n_present /
      n_countries,
    .groups =
      "drop"
  ) %>%
  mutate(
    region =
      factor(
        region,
        levels =
          region_levels
      ),
    item_id =
      factor(
        item_id,
        levels =
          item_levels
      )
  )

region_label_map <- setNames(
  str_replace(
    region_levels,
    " Europe$",
    "\nEurope"
  ),
  region_levels
)

item_label_map <- setNames(
  item_order_table$item_label,
  item_order_table$item_id
)

# ==============================================================================
# 6. Plot
# ==============================================================================

regional_plot <- ggplot(
  regional_plot_data,
  aes(
    x =
      region,
    y =
      item_id,
    fill =
      prop_present
  )
) +
  geom_tile(
    colour = NA,
    linewidth = 0
  ) +
  scale_fill_gradient(
    low =
      "black",
    high =
      "grey85",
    limits = c(
      0,
      1
    ),
    breaks = c(
      0,
      0.25,
      0.50,
      0.75,
      1
    ),
    labels =
      percent_format(
        accuracy = 1
      ),
    name =
      "Data present",
    guide =
      guide_colorbar(
        direction =
          "vertical",
        title.position =
          "top",
        title.hjust =
          0.5,
        barheight =
          unit(
            4.0,
            "cm"
          ),
        barwidth =
          unit(
            0.45,
            "cm"
          ),
        frame.colour =
          "black",
        frame.linewidth =
          0.3,
        ticks =
          FALSE
      )
  ) +
  scale_x_discrete(
    labels =
      region_label_map,
    expand =
      c(
        0,
        0
      )
  ) +
  scale_y_discrete(
    labels =
      item_label_map,
    drop =
      TRUE,
    expand =
      c(
        0,
        0
      )
  ) +
  labs(
    title =
      "Completeness of preparedness questionnaire\nacross regions and indicators",
    subtitle =
      "Cells show the share of participating countries with data present;\nIndicators marked with an asterisk (*) have disease- or species-specific variants",
    x =
      NULL,
    y =
      NULL
  ) +
  theme_minimal(
    base_size = 9
  ) +
  theme(
    panel.grid =
      element_blank(),
    panel.border =
      element_rect(
        colour = "black",
        fill = NA,
        linewidth = 0.4
      ),
    panel.background =
      element_rect(
        fill = "white",
        colour = NA
      ),
    plot.background =
      element_rect(
        fill = "white",
        colour = NA
      ),
    axis.text.x =
      element_text(
        hjust = 0.5,
        size = 8,
        colour = "black",
        lineheight = 0.95
      ),
    axis.text.y =
      element_text(
        size = 6.7,
        colour = "black",
        lineheight = 0.95
      ),
    axis.ticks =
      element_line(
        colour = "black",
        linewidth = 0.35
      ),
    axis.ticks.length =
      unit(
        0.10,
        "cm"
      ),
    plot.title =
      element_text(
        face = "bold",
        hjust = 0.5,
        size = 12
      ),
    plot.subtitle =
      element_text(
        hjust = 0.5,
        size = 9
      ),
    legend.position =
      "right",
    legend.ticks =
      element_blank(),
    legend.ticks.length =
      unit(
        0,
        "cm"
      ),
    plot.margin =
      margin(
        8,
        8,
        8,
        8
      )
  )

ggsave(
  filename =
    file.path(
      plot_dir,
      "missing_data_regional.png"
    ),
  plot =
    regional_plot,
  width =
    regional_plot_width,
  height =
    regional_plot_height,
  dpi =
    plot_dpi,
  bg =
    "white"
)

message(
  "\nRegional missing-data figure completed.\n",
  "Output:\n  ",
  file.path(
    plot_dir,
    "missing_data_regional.png"
  ),
  "\n"
)
