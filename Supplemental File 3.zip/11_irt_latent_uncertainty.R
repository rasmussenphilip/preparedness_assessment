# ==============================================================================
# 11_irt_latent_uncertainty.R
#
# PURPOSE
# Generate country-level Monte Carlo draws for uncertainty in the IRT-derived
# Preparedness capacity score on the original latent IRT scale.
#
# INPUT
# data/exported/raw_irt_factor_scores_long.csv
#
# OUTPUT
# results/sensitivity/monte_carlo_sensitivity/
#   irt_preparedness_capacity_latent_draws.csv
# ==============================================================================

suppressPackageStartupMessages({
  library(dplyr)
  library(readr)
  library(tibble)
})

# ==============================================================================
# 1. Settings and paths
# ==============================================================================

n_iterations <- 10000L
random_seed <- 24680L

analysis_model <- "overall_preparedness"

required_diseases <- c(
  "aiv_poultry",
  "asf"
)

irt_file <- file.path(
  "data",
  "exported",
  "raw_irt_factor_scores_long.csv"
)

output_dir <- file.path(
  "results",
  "sensitivity",
  "monte_carlo_sensitivity"
)

output_file <- file.path(
  output_dir,
  "irt_preparedness_capacity_latent_draws.csv"
)

dir.create(
  output_dir,
  recursive = TRUE,
  showWarnings = FALSE
)

# ==============================================================================
# 2. Helpers
# ==============================================================================

read_required_csv <- function(path) {
  if (!file.exists(path)) {
    stop(
      "Required input file was not found: ",
      path,
      call. = FALSE
    )
  }

  read_csv(
    path,
    show_col_types = FALSE,
    progress = FALSE
  )
}

check_required_columns <- function(
    data,
    required_columns,
    object_name
) {
  missing_columns <- setdiff(
    required_columns,
    names(data)
  )

  if (length(missing_columns) > 0L) {
    stop(
      object_name,
      " is missing required columns: ",
      paste(missing_columns, collapse = ", "),
      call. = FALSE
    )
  }
}

standardize_country_name <- function(x) {
  recode(
    as.character(x),
    "Czech Republic" = "Czechia",
    "Turkiye" = "Türkiye",
    "Turkey" = "Türkiye",
    "Slovak Republic" = "Slovakia",
    "Russian Federation" = "Russia",
    .default = as.character(x)
  )
}

# ==============================================================================
# 3. Read and validate IRT factor scores
# ==============================================================================

irt_scores <- read_required_csv(
  irt_file
)

check_required_columns(
  irt_scores,
  c(
    "country_name",
    "disease",
    "model",
    "score",
    "score_se"
  ),
  "raw_irt_factor_scores_long.csv"
)

irt_reference <- irt_scores %>%
  transmute(
    country_name =
      standardize_country_name(
        country_name
      ),
    disease =
      as.character(
        disease
      ),
    model =
      as.character(
        model
      ),
    score =
      as.numeric(
        score
      ),
    score_se =
      as.numeric(
        score_se
      )
  ) %>%
  filter(
    model == analysis_model,
    disease %in% required_diseases
  ) %>%
  arrange(
    disease,
    country_name
  )

missing_diseases <- setdiff(
  required_diseases,
  unique(
    irt_reference$disease
  )
)

if (
  length(
    missing_diseases
  ) > 0L
) {
  stop(
    "IRT input is missing required diseases: ",
    paste(
      missing_diseases,
      collapse = ", "
    ),
    call. = FALSE
  )
}

invalid_rows <- irt_reference %>%
  filter(
    !is.finite(score) |
      !is.finite(score_se) |
      score_se < 0
  )

if (
  nrow(
    invalid_rows
  ) > 0L
) {
  stop(
    "Missing or invalid IRT score or score_se for at least one country.",
    call. = FALSE
  )
}

duplicate_keys <- irt_reference %>%
  count(
    country_name,
    disease,
    model
  ) %>%
  filter(
    n != 1L
  )

if (
  nrow(
    duplicate_keys
  ) > 0L
) {
  stop(
    "Expected exactly one IRT row per country × disease × model.",
    call. = FALSE
  )
}

# ==============================================================================
# 4. Generate latent-scale uncertainty draws
# ==============================================================================

set.seed(
  random_seed
)

draw_parts <- vector(
  "list",
  nrow(
    irt_reference
  )
)

for (
  row_index in seq_len(
    nrow(
      irt_reference
    )
  )
) {
  current <- irt_reference[
    row_index,
    ,
    drop = FALSE
  ]

  latent_draws <- rnorm(
    n_iterations,
    mean = current$score[[1]],
    sd = current$score_se[[1]]
  )

  draw_parts[[row_index]] <- tibble(
    iteration =
      seq_len(
        n_iterations
      ),
    country_name =
      current$country_name[[1]],
    disease =
      current$disease[[1]],
    model =
      current$model[[1]],
    irt_score_point_estimate =
      current$score[[1]],
    irt_score_se =
      current$score_se[[1]],
    preparedness_capacity_latent =
      latent_draws
  )
}

latent_draws <- bind_rows(
  draw_parts
) %>%
  arrange(
    disease,
    country_name,
    iteration
  )

expected_rows <-
  nrow(
    irt_reference
  ) *
  n_iterations

if (
  nrow(
    latent_draws
  ) != expected_rows
) {
  stop(
    "Unexpected number of latent-scale uncertainty draws.",
    call. = FALSE
  )
}

if (
  any(
    !is.finite(
      latent_draws$preparedness_capacity_latent
    )
  )
) {
  stop(
    "Non-finite latent IRT draws were generated.",
    call. = FALSE
  )
}

# ==============================================================================
# 5. Export
# ==============================================================================

write_csv(
  latent_draws,
  output_file
)

message(
  "\nLatent-scale Preparedness capacity uncertainty completed.\n",
  "Iterations per country × disease: ",
  n_iterations,
  "\nOutput:\n  ",
  output_file,
  "\n"
)
