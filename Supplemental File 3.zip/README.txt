01_index_data_preparation.R: Combines country-level context, livestock, import, outbreak-history, wildlife, and density data into the secondary datasets used by the pipeline.

02_questionnaire_data_preparation.R: Cleans the country questionnaire data and uses `mapping.xlsx` to identify the disease-specific items for the overall Preparedness capacity models.

03_irt_preparation.R: Creates separate ASF and avian-influenza questionnaire datasets and item specifications for IRT estimation.

04_irt_models.R: Fits one overall Preparedness capacity IRT model per disease and exports country factor scores, item parameters, and model summaries.

05_contextual_index.R: Scales GDP per capita, health expenditure per capita, government effectiveness, and advanced education to construct the country-level Contextual Index.

06_context_adjusted_preparedness.R: Combines disease-specific Preparedness capacity scores with the Contextual Index to calculate Context-adjusted preparedness.

07_challenge_index.R: Constructs ASF and avian-influenza Challenge Indices from livestock population, livestock density, live-animal imports, and relevant wildlife abundance.

08_preparedness_challenge_balance.R: Calculates each country’s disease-specific Preparedness-challenge balance from Context-adjusted preparedness and the Challenge Index.

09_joint_monte_carlo_uncertainty.R: Propagates uncertainty in IRT scores and index component weights through the Preparedness-challenge balance using joint Monte Carlo draws.

10_profile_variance_decomposition.R: Estimates how IRT uncertainty, index weights, context adjustment, and their interactions contribute to variation in country profiles and regional profile composition.

11_irt_latent_uncertainty.R: Generates country-level Monte Carlo draws of Preparedness capacity on the latent IRT scale.

12_historical_comparison.R: Calculates Harrell's C for the association of Preparedness-challenge balance with recorded outbreak occurrence, frequency, recurrence, and persistence, separately by disease and historical period. Writes results to results/historical_comparison/.

13_plot_historical_comparison.R: Produces one four-panel figure of Harrell's C for occurrence, frequency, recurrence, and persistence in results/plots/historical_comparison/.

14_plot_chord_diagram.R: Draws a chord diagram linking mapped questionnaire items to the three conceptual preparedness domains.

15_plot_maps.R: Maps study regions, contextual indicators and the Contextual Index, and disease-specific Challenge Indices and their components.

16_plot_profiles.R: Plots country-level preparedness-challenge profiles using illustrative point positions, including an AI example pair with equal balance in different profiles, and plots their unweighted and livestock-weighted regional composition.

17_plot_sensitivity.R: Plots country-level uncertainty distributions and variance-decomposition results for country and regional profiles.

18_plot_missing_data.R: Plots regional completeness of the 15 conceptual questionnaire indicators using the current labels in `mapping.xlsx`.

19_table_irt_results.R: Produces a supplementary table of anonymized country-level Preparedness capacity IRT results for ASF and avian influenza.
