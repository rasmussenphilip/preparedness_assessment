# ==============================================================================
# 02_questionnaire_data_preparation.R
#
# PURPOSE
# -------
# Prepare the primary questionnaire dataset and construct the disease-specific
# item lists used by the overall Preparedness capacity IRT models.
#
# INPUTS
# ------
# data/primary_long.xlsx
# data/exported/data_secondary.csv
# data/mapping.xlsx
#
# OUTPUTS
# -------
# data/exported/data_primary_long.csv
# data/exported/irt_items.rds
#
# The mapping workbook remains the authoritative source of questionnaire-item
# inclusion and conceptual domain assignment. This script uses it only to build
# the disease-specific overall IRT item sets. Domain-specific IRT models are no
# longer prepared or estimated; Script 15 reads mapping.xlsx directly for the
# conceptual domain/chord visualization.
# ==============================================================================

suppressPackageStartupMessages({
  library(dplyr)
  library(readxl)
  library(purrr)
  library(stringr)
})

# ==============================================================================
# 1. Paths and settings
# ==============================================================================

primary_file <- file.path("data", "primary_long.xlsx")
secondary_file <- file.path("data", "exported", "data_secondary.csv")
mapping_file <- file.path("data", "mapping.xlsx")
export_dir <- file.path("data", "exported")

required_diseases <- c("asf", "aiv")
recognized_mapping_codes <- c("wor", "mas", "res")

dir.create(export_dir, recursive = TRUE, showWarnings = FALSE)

# ==============================================================================
# 2. Helpers
# ==============================================================================

infer_item_diseases <- function(item) {
  item <- tolower(as.character(item))

  if (str_detect(item, "asf|pig")) {
    return("asf")
  }

  if (str_detect(item, "aiv|pou")) {
    return("aiv")
  }

  required_diseases
}

split_mapping_codes <- function(x) {
  x <- tolower(trimws(as.character(x)))
  codes <- str_split(x, pattern = "[^a-z]+")[[1]]
  unique(codes[nzchar(codes)])
}

# ==============================================================================
# 3. Read inputs
# ==============================================================================

required_files <- c(primary_file, secondary_file, mapping_file)
missing_files <- required_files[!file.exists(required_files)]

if (length(missing_files) > 0L) {
  stop(
    "The following required input files are missing: ",
    paste(missing_files, collapse = ", "),
    call. = FALSE
  )
}

primary_data <- read_excel(primary_file)

secondary_data <- read.csv(
  secondary_file,
  stringsAsFactors = FALSE,
  check.names = FALSE
)

mapping_raw <- read_excel(mapping_file)

# ==============================================================================
# 4. Align primary data to the final study-country set
# ==============================================================================

if (!"country_name" %in% names(primary_data)) {
  stop("primary_long.xlsx must contain a country_name column.", call. = FALSE)
}

if (!"country_name" %in% names(secondary_data)) {
  stop("data_secondary.csv must contain a country_name column.", call. = FALSE)
}

if (anyDuplicated(primary_data$country_name) > 0L) {
  stop("primary_long.xlsx contains duplicate country names.", call. = FALSE)
}

if (anyDuplicated(secondary_data$country_name) > 0L) {
  stop("data_secondary.csv contains duplicate country names.", call. = FALSE)
}

missing_primary_countries <- setdiff(
  secondary_data$country_name,
  primary_data$country_name
)

if (length(missing_primary_countries) > 0L) {
  stop(
    "Countries in data_secondary.csv missing from primary_long.xlsx: ",
    paste(missing_primary_countries, collapse = ", "),
    call. = FALSE
  )
}

primary_data <- primary_data %>%
  filter(country_name %in% secondary_data$country_name) %>%
  slice(match(secondary_data$country_name, country_name))

if (!identical(
  as.character(primary_data$country_name),
  as.character(secondary_data$country_name)
)) {
  stop(
    "Country ordering could not be matched between the primary and secondary data.",
    call. = FALSE
  )
}

# ==============================================================================
# 5. Prepare questionnaire variables
# ==============================================================================

primary_data <- primary_data %>%
  mutate(across(-country_name, ~ as.numeric(.x)))

already_graded <- c("n_train_asf", "n_train_aiv")
missing_graded <- setdiff(already_graded, names(primary_data))

if (length(missing_graded) > 0L) {
  stop(
    "Missing expected graded variables: ",
    paste(missing_graded, collapse = ", "),
    call. = FALSE
  )
}

primary_data <- primary_data %>%
  rename(
    g_train_asf = n_train_asf,
    g_train_aiv = n_train_aiv
  )

continuous_variables <- names(primary_data)[
  startsWith(names(primary_data), "n_")
]

primary_data <- primary_data %>%
  relocate(all_of(continuous_variables), .after = last_col())

# ==============================================================================
# 6. Validate mapping.xlsx
# ==============================================================================

names(mapping_raw) <- tolower(trimws(names(mapping_raw)))

required_mapping_columns <- c("item", "model")
missing_mapping_columns <- setdiff(
  required_mapping_columns,
  names(mapping_raw)
)

if (length(missing_mapping_columns) > 0L) {
  stop(
    "mapping.xlsx is missing required columns: ",
    paste(missing_mapping_columns, collapse = ", "),
    call. = FALSE
  )
}

mapping_clean <- mapping_raw %>%
  transmute(
    item_original = trimws(as.character(item)),
    model_codes_raw = trimws(as.character(model))
  ) %>%
  filter(
    !is.na(item_original),
    item_original != "",
    !is.na(model_codes_raw),
    model_codes_raw != ""
  ) %>%
  mutate(
    item = recode(
      item_original,
      n_train_asf = "g_train_asf",
      n_train_aiv = "g_train_aiv",
      .default = item_original
    ),
    model_codes = map(model_codes_raw, split_mapping_codes),
    diseases = map(item_original, infer_item_diseases)
  )

if (nrow(mapping_clean) == 0L) {
  stop("mapping.xlsx contains no usable item mappings.", call. = FALSE)
}

duplicate_mapping_rows <- mapping_clean %>%
  count(item_original, model_codes_raw, name = "rows") %>%
  filter(rows > 1L)

if (nrow(duplicate_mapping_rows) > 0L) {
  stop(
    "mapping.xlsx contains duplicate item/model rows for: ",
    paste(
      paste0(
        duplicate_mapping_rows$item_original,
        " [",
        duplicate_mapping_rows$model_codes_raw,
        "]"
      ),
      collapse = ", "
    ),
    call. = FALSE
  )
}

all_mapping_codes <- unique(unlist(mapping_clean$model_codes, use.names = FALSE))
unknown_mapping_codes <- setdiff(all_mapping_codes, recognized_mapping_codes)

if (length(unknown_mapping_codes) > 0L) {
  stop(
    "mapping.xlsx contains unrecognized model codes: ",
    paste(unknown_mapping_codes, collapse = ", "),
    ". Recognized codes are: ",
    paste(recognized_mapping_codes, collapse = ", "),
    ".",
    call. = FALSE
  )
}

empty_mapping_codes <- map_lgl(mapping_clean$model_codes, ~ length(.x) == 0L)

if (any(empty_mapping_codes)) {
  stop(
    "At least one mapping row does not contain a recognized domain code.",
    call. = FALSE
  )
}

missing_mapped_items <- setdiff(
  unique(mapping_clean$item),
  names(primary_data)
)

if (length(missing_mapped_items) > 0L) {
  stop(
    "The following items in mapping.xlsx are missing from the prepared primary data: ",
    paste(missing_mapped_items, collapse = ", "),
    call. = FALSE
  )
}

# ==============================================================================
# 7. Construct disease-specific overall Preparedness capacity item lists
# ==============================================================================

irt_overall_items <- setNames(
  map(
    required_diseases,
    function(disease_code) {
      mapping_clean %>%
        filter(map_lgl(diseases, ~ disease_code %in% .x)) %>%
        pull(item) %>%
        unique()
    }
  ),
  required_diseases
)

empty_disease_item_sets <- names(irt_overall_items)[
  lengths(irt_overall_items) == 0L
]

if (length(empty_disease_item_sets) > 0L) {
  stop(
    "No mapped items were found for: ",
    paste(empty_disease_item_sets, collapse = ", "),
    call. = FALSE
  )
}

specified_items <- unique(unlist(irt_overall_items, use.names = FALSE))
missing_specified_items <- setdiff(specified_items, names(primary_data))

if (length(missing_specified_items) > 0L) {
  stop(
    "Mapped IRT items are missing from the prepared primary data: ",
    paste(missing_specified_items, collapse = ", "),
    call. = FALSE
  )
}

# ==============================================================================
# 8. Export
# ==============================================================================

write.csv(
  primary_data,
  file.path(export_dir, "data_primary_long.csv"),
  row.names = FALSE
)

saveRDS(
  list(overall_items = irt_overall_items),
  file.path(export_dir, "irt_items.rds")
)

message(
  "\nPrimary questionnaire data and overall IRT item lists completed.\n",
  "Outputs:\n",
  "  ", file.path(export_dir, "data_primary_long.csv"), "\n",
  "  ", file.path(export_dir, "irt_items.rds"), "\n"
)
