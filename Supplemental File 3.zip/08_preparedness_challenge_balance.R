# ==============================================================================
# 08_preparedness_challenge_balance.R
#
# PURPOSE
# Combine disease-specific Context-adjusted preparedness with the Challenge
# Index and calculate the country-level Preparedness-challenge balance.
#
# INPUTS
# results/indices/context_adjusted_preparedness.csv
# results/indices/challenge_index.csv
#
# OUTPUT
# results/preparedness_challenge/preparedness_challenge_comparison.csv
# ==============================================================================

suppressPackageStartupMessages({
  library(dplyr)
  library(readr)
})

# ==============================================================================
# 1. Paths and settings
# ==============================================================================

preparedness_file <- file.path(
  "results",
  "indices",
  "context_adjusted_preparedness.csv"
)

challenge_file <- file.path(
  "results",
  "indices",
  "challenge_index.csv"
)

output_dir <- file.path(
  "results",
  "preparedness_challenge"
)

output_file <- file.path(
  output_dir,
  "preparedness_challenge_comparison.csv"
)

required_diseases <- c(
  "asf",
  "aiv_poultry"
)

dir.create(
  output_dir,
  recursive = TRUE,
  showWarnings = FALSE
)

# ==============================================================================
# 2. Helpers
# ==============================================================================

read_required_csv <- function(path) {
  if (!file.exists(path)) {
    stop(
      "Required input file was not found: ",
      path,
      call. = FALSE
    )
  }

  read_csv(
    path,
    show_col_types = FALSE,
    progress = FALSE
  )
}

check_required_columns <- function(
    data,
    required_columns,
    object_name
) {
  missing_columns <- setdiff(
    required_columns,
    names(data)
  )

  if (length(missing_columns) > 0L) {
    stop(
      object_name,
      " is missing required columns: ",
      paste(missing_columns, collapse = ", "),
      call. = FALSE
    )
  }
}

check_unique_keys <- function(
    data,
    keys,
    object_name
) {
  duplicates <- data %>%
    count(
      across(
        all_of(keys)
      )
    ) %>%
    filter(
      n != 1L
    )

  if (nrow(duplicates) > 0L) {
    stop(
      object_name,
      " must contain exactly one row per ",
      paste(keys, collapse = " × "),
      ".",
      call. = FALSE
    )
  }
}

standardize_country_name <- function(x) {
  recode(
    as.character(x),
    "Czech Republic" = "Czechia",
    "Turkiye" = "Türkiye",
    "Turkey" = "Türkiye",
    "Slovak Republic" = "Slovakia",
    "Russian Federation" = "Russia",
    .default = as.character(x)
  )
}

# ==============================================================================
# 3. Read and validate inputs
# ==============================================================================

preparedness <- read_required_csv(
  preparedness_file
)

challenge <- read_required_csv(
  challenge_file
)

check_required_columns(
  preparedness,
  c(
    "country_name",
    "disease",
    "preparedness_capacity_latent",
    "preparedness_capacity_index",
    "contextual_index",
    "context_adjusted_preparedness"
  ),
  "context_adjusted_preparedness.csv"
)

check_required_columns(
  challenge,
  c(
    "country_name",
    "disease",
    "challenge_index"
  ),
  "challenge_index.csv"
)

preparedness <- preparedness %>%
  mutate(
    country_name =
      standardize_country_name(
        country_name
      ),
    disease =
      as.character(
        disease
      )
  ) %>%
  filter(
    disease %in% required_diseases
  )

challenge <- challenge %>%
  mutate(
    country_name =
      standardize_country_name(
        country_name
      ),
    disease =
      as.character(
        disease
      )
  ) %>%
  filter(
    disease %in% required_diseases
  )

check_unique_keys(
  preparedness,
  c(
    "country_name",
    "disease"
  ),
  "Context-adjusted preparedness input"
)

check_unique_keys(
  challenge,
  c(
    "country_name",
    "disease"
  ),
  "Challenge Index input"
)

missing_preparedness_diseases <- setdiff(
  required_diseases,
  unique(preparedness$disease)
)

if (
  length(
    missing_preparedness_diseases
  ) > 0L
) {
  stop(
    "Context-adjusted preparedness input is missing diseases: ",
    paste(
      missing_preparedness_diseases,
      collapse = ", "
    ),
    call. = FALSE
  )
}

missing_challenge_diseases <- setdiff(
  required_diseases,
  unique(challenge$disease)
)

if (
  length(
    missing_challenge_diseases
  ) > 0L
) {
  stop(
    "Challenge Index input is missing diseases: ",
    paste(
      missing_challenge_diseases,
      collapse = ", "
    ),
    call. = FALSE
  )
}

preparedness_keys <- preparedness %>%
  distinct(
    country_name,
    disease
  )

challenge_keys <- challenge %>%
  distinct(
    country_name,
    disease
  )

missing_challenge_rows <- anti_join(
  preparedness_keys,
  challenge_keys,
  by = c(
    "country_name",
    "disease"
  )
)

missing_preparedness_rows <- anti_join(
  challenge_keys,
  preparedness_keys,
  by = c(
    "country_name",
    "disease"
  )
)

if (
  nrow(
    missing_challenge_rows
  ) > 0L
) {
  stop(
    "At least one country × disease preparedness row has no matching Challenge Index.",
    call. = FALSE
  )
}

if (
  nrow(
    missing_preparedness_rows
  ) > 0L
) {
  stop(
    "At least one country × disease Challenge Index row has no matching preparedness value.",
    call. = FALSE
  )
}

# ==============================================================================
# 4. Calculate Preparedness-challenge balance
# ==============================================================================

preparedness_challenge <- preparedness %>%
  select(
    country_name,
    disease,
    preparedness_capacity_latent,
    preparedness_capacity_index,
    contextual_index,
    context_adjusted_preparedness
  ) %>%
  inner_join(
    challenge %>%
      select(
        country_name,
        disease,
        challenge_index
      ),
    by = c(
      "country_name",
      "disease"
    ),
    relationship = "one-to-one"
  ) %>%
  mutate(
    preparedness_challenge_balance =
      context_adjusted_preparedness -
      challenge_index
  ) %>%
  arrange(
    factor(
      disease,
      levels = required_diseases
    ),
    desc(
      preparedness_challenge_balance
    ),
    country_name
  )

# ==============================================================================
# 5. Validate final comparison table
# ==============================================================================

numeric_columns <- c(
  "preparedness_capacity_latent",
  "preparedness_capacity_index",
  "contextual_index",
  "context_adjusted_preparedness",
  "challenge_index",
  "preparedness_challenge_balance"
)

invalid_numeric <- numeric_columns[
  vapply(
    preparedness_challenge[
      numeric_columns
    ],
    function(x) {
      anyNA(x) ||
        any(
          !is.finite(
            x
          )
        )
    },
    logical(1)
  )
]

if (
  length(
    invalid_numeric
  ) > 0L
) {
  stop(
    "Final comparison table contains missing or non-finite values in: ",
    paste(
      invalid_numeric,
      collapse = ", "
    ),
    call. = FALSE
  )
}

bounded_index_columns <- c(
  "preparedness_capacity_index",
  "contextual_index",
  "context_adjusted_preparedness",
  "challenge_index"
)

out_of_range <- bounded_index_columns[
  vapply(
    preparedness_challenge[
      bounded_index_columns
    ],
    function(x) {
      any(
        x < 5 - 1e-8 |
          x > 95 + 1e-8
      )
    },
    logical(1)
  )
]

if (
  length(
    out_of_range
  ) > 0L
) {
  stop(
    "Index values fall outside the expected 5-95 range in: ",
    paste(
      out_of_range,
      collapse = ", "
    ),
    call. = FALSE
  )
}

if (
  any(
    preparedness_challenge$preparedness_challenge_balance <
      -90 - 1e-8 |
      preparedness_challenge$preparedness_challenge_balance >
        90 + 1e-8
  )
) {
  stop(
    "Preparedness-challenge balance falls outside the theoretical -90 to +90 range.",
    call. = FALSE
  )
}

check_unique_keys(
  preparedness_challenge,
  c(
    "country_name",
    "disease"
  ),
  "Final preparedness-challenge comparison"
)

# ==============================================================================
# 6. Export
# ==============================================================================

write_csv(
  preparedness_challenge,
  output_file
)

message(
  "\nPreparedness-challenge balance completed.\n",
  "Output:\n  ",
  output_file,
  "\n"
)
