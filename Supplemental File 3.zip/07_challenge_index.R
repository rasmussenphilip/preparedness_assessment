# ==============================================================================
# 07_challenge_index.R
#
# PURPOSE
# Construct disease-specific Challenge Indices for ASF in domestic pigs and
# avian influenza in poultry.
#
# COMPONENTS
# 1. Domestic livestock population
# 2. Domestic livestock density
# 3. Total live-animal imports
# 4. Relevant wildlife abundance
#
# ASF uses pigs and wild boar; AI uses poultry and wild birds.
#
# INPUTS
# data/exported/data_secondary.csv
# data/exported/density_by_species.csv
#
# OUTPUTS
# results/indices/challenge_index.csv
# results/indices/challenge_diagnostics/challenge_component_breakdown.csv
# ==============================================================================

suppressPackageStartupMessages({
  library(dplyr)
  library(tidyr)
  library(purrr)
})

# ==============================================================================
# 1. Paths and settings
# ==============================================================================

secondary_file <- file.path(
  "data",
  "exported",
  "data_secondary.csv"
)

density_file <- file.path(
  "data",
  "exported",
  "density_by_species.csv"
)

output_dir <- file.path(
  "results",
  "indices"
)

diagnostics_dir <- file.path(
  output_dir,
  "challenge_diagnostics"
)

challenge_output_file <- file.path(
  output_dir,
  "challenge_index.csv"
)

breakdown_output_file <- file.path(
  diagnostics_dir,
  "challenge_component_breakdown.csv"
)

component_floor <- 0.05
component_ceiling <- 0.95
validation_tolerance <- 1e-10

required_diseases <- c(
  "asf",
  "aiv_poultry"
)

dir.create(
  output_dir,
  recursive = TRUE,
  showWarnings = FALSE
)

dir.create(
  diagnostics_dir,
  recursive = TRUE,
  showWarnings = FALSE
)

# ==============================================================================
# 2. Helpers
# ==============================================================================

read_required_csv <- function(path) {
  if (!file.exists(path)) {
    stop(
      "Required input file was not found: ",
      path,
      call. = FALSE
    )
  }

  read.csv(
    path,
    stringsAsFactors = FALSE,
    check.names = FALSE,
    fileEncoding = "UTF-8-BOM"
  )
}

standardize_country_name <- function(x) {
  recode(
    as.character(x),
    "Czech Republic" = "Czechia",
    "Turkiye" = "Türkiye",
    "Turkey" = "Türkiye",
    "Slovak Republic" = "Slovakia",
    "Russian Federation" = "Russia",
    .default = as.character(x)
  )
}

check_unique_countries <- function(
    data,
    object_name
) {
  if (!"country_name" %in% names(data)) {
    stop(
      object_name,
      " must contain country_name.",
      call. = FALSE
    )
  }

  duplicates <- unique(
    data$country_name[
      duplicated(data$country_name)
    ]
  )

  if (length(duplicates) > 0L) {
    stop(
      object_name,
      " contains duplicate countries: ",
      paste(duplicates, collapse = ", "),
      call. = FALSE
    )
  }
}

as_numeric_strict <- function(
    x,
    variable_name
) {
  original <- x

  numeric_x <- suppressWarnings(
    as.numeric(
      as.character(x)
    )
  )

  newly_missing <-
    is.na(numeric_x) &
    !is.na(original) &
    trimws(as.character(original)) != ""

  if (any(newly_missing)) {
    stop(
      variable_name,
      " contains non-numeric values.",
      call. = FALSE
    )
  }

  numeric_x
}

validate_nonnegative <- function(
    x,
    variable_name
) {
  if (any(x < 0, na.rm = TRUE)) {
    stop(
      variable_name,
      " contains negative values.",
      call. = FALSE
    )
  }
}

rank_position <- function(x) {
  x <- as.numeric(x)
  n <- length(x)

  if (n == 0L) {
    return(numeric(0))
  }

  if (
    n == 1L ||
      length(unique(x)) == 1L
  ) {
    return(
      rep(0.5, n)
    )
  }

  (
    rank(
      x,
      ties.method = "average"
    ) -
      1
  ) /
    (n - 1)
}

bounded_scale <- function(
    relative_position,
    lower = component_floor,
    upper = component_ceiling
) {
  lower +
    (upper - lower) *
    relative_position
}

rank_scale_with_neutral_missing <- function(
    x,
    variable_name
) {
  x <- as.numeric(x)
  observed <- !is.na(x)

  if (!any(observed)) {
    stop(
      variable_name,
      " contains only missing values.",
      call. = FALSE
    )
  }

  relative_position <- rep(
    0.50,
    length(x)
  )

  relative_position[observed] <-
    rank_position(
      x[observed]
    )

  list(
    raw = x,
    missing_neutral = as.integer(!observed),
    relative_position = relative_position,
    scaled = bounded_scale(relative_position)
  )
}

log_minmax_scale_with_neutral_missing <- function(
    x,
    variable_name
) {
  x <- as.numeric(x)
  observed <- !is.na(x)

  if (!any(observed)) {
    stop(
      variable_name,
      " contains only missing values.",
      call. = FALSE
    )
  }

  log_value <- rep(
    NA_real_,
    length(x)
  )

  log_value[observed] <-
    log1p(
      x[observed]
    )

  relative_position <- rep(
    0.50,
    length(x)
  )

  observed_log <- log_value[observed]

  if (
    length(observed_log) == 1L ||
      length(unique(observed_log)) == 1L
  ) {
    relative_position[observed] <- 0.50
  } else {
    observed_min <- min(observed_log)
    observed_max <- max(observed_log)

    relative_position[observed] <-
      (
        observed_log -
          observed_min
      ) /
      (
        observed_max -
          observed_min
      )
  }

  list(
    raw = x,
    log_value = log_value,
    missing_neutral = as.integer(!observed),
    relative_position = relative_position,
    scaled = bounded_scale(relative_position)
  )
}

geometric_mean_rows <- function(data) {
  values <- as.matrix(data)

  if (
    any(!is.finite(values)) ||
      any(values <= 0)
  ) {
    stop(
      "Challenge components must be finite and strictly positive.",
      call. = FALSE
    )
  }

  exp(
    rowMeans(
      log(values)
    )
  )
}

# ==============================================================================
# 3. Prepare domestic livestock density
# ==============================================================================

prepare_density_data <- function(data) {
  names(data) <- tolower(
    names(data)
  )

  country_candidates <- c(
    "country_name",
    "country",
    "area",
    "nation"
  )

  country_column <- country_candidates[
    country_candidates %in% names(data)
  ][1]

  if (is.na(country_column)) {
    stop(
      "density_by_species.csv must contain a country identifier.",
      call. = FALSE
    )
  }

  data <- data %>%
    rename(
      country_name = all_of(country_column)
    ) %>%
    mutate(
      country_name =
        standardize_country_name(
          country_name
        )
    )

  species_candidates <- c(
    "species",
    "livestock_species",
    "animal_species"
  )

  value_candidates <- c(
    "density",
    "density_value",
    "value",
    "animals_per_km2"
  )

  species_column <- species_candidates[
    species_candidates %in% names(data)
  ][1]

  value_column <- value_candidates[
    value_candidates %in% names(data)
  ][1]

  if (
    !is.na(species_column) &&
      !is.na(value_column)
  ) {
    return(
      data %>%
        transmute(
          country_name,
          species =
            tolower(
              trimws(
                as.character(
                  .data[[species_column]]
                )
              )
            ),
          density =
            as_numeric_strict(
              .data[[value_column]],
              value_column
            )
        ) %>%
        mutate(
          species = case_when(
            grepl(
              "pig|swine",
              species
            ) ~ "pigs",
            grepl(
              "poultry|chicken|duck|goose|geese|turkey",
              species
            ) ~ "poultry",
            TRUE ~ NA_character_
          )
        ) %>%
        filter(
          !is.na(species)
        ) %>%
        group_by(
          country_name,
          species
        ) %>%
        summarise(
          density = mean(
            density,
            na.rm = TRUE
          ),
          .groups = "drop"
        ) %>%
        mutate(
          density_name =
            paste0(
              "density_",
              species
            )
        ) %>%
        select(
          country_name,
          density_name,
          density
        ) %>%
        pivot_wider(
          names_from = density_name,
          values_from = density
        )
    )
  }

  pig_candidates <- c(
    "density_pigs",
    "pig_density",
    "pigs_density",
    "swine_density",
    "density_swine",
    "pigs_per_km2"
  )

  poultry_candidates <- c(
    "density_poultry",
    "poultry_density",
    "chicken_density",
    "density_chickens",
    "poultry_per_km2"
  )

  pig_column <- pig_candidates[
    pig_candidates %in% names(data)
  ][1]

  poultry_column <- poultry_candidates[
    poultry_candidates %in% names(data)
  ][1]

  if (
    is.na(pig_column) ||
      is.na(poultry_column)
  ) {
    stop(
      "Could not identify pig and poultry density columns in density_by_species.csv.",
      call. = FALSE
    )
  }

  data %>%
    transmute(
      country_name,
      density_pigs =
        as_numeric_strict(
          .data[[pig_column]],
          pig_column
        ),
      density_poultry =
        as_numeric_strict(
          .data[[poultry_column]],
          poultry_column
        )
    )
}

# ==============================================================================
# 4. Read and validate source data
# ==============================================================================

secondary_data <- read_required_csv(
  secondary_file
) %>%
  mutate(
    country_name =
      standardize_country_name(
        country_name
      )
  )

density_data <- read_required_csv(
  density_file
) %>%
  prepare_density_data()

check_unique_countries(
  secondary_data,
  "data_secondary.csv"
)

check_unique_countries(
  density_data,
  "density_by_species.csv"
)

required_secondary_variables <- c(
  "country_name",
  "stock_pigs",
  "stock_poultry",
  "import_pigs",
  "import_poultry",
  "boar_abundance",
  "avian_abundance"
)

missing_secondary_variables <- setdiff(
  required_secondary_variables,
  names(secondary_data)
)

if (
  length(
    missing_secondary_variables
  ) > 0L
) {
  stop(
    "data_secondary.csv is missing required variables: ",
    paste(
      missing_secondary_variables,
      collapse = ", "
    ),
    call. = FALSE
  )
}

required_density_variables <- c(
  "country_name",
  "density_pigs",
  "density_poultry"
)

missing_density_variables <- setdiff(
  required_density_variables,
  names(density_data)
)

if (
  length(
    missing_density_variables
  ) > 0L
) {
  stop(
    "Prepared density data are missing: ",
    paste(
      missing_density_variables,
      collapse = ", "
    ),
    call. = FALSE
  )
}

missing_density_countries <- setdiff(
  secondary_data$country_name,
  density_data$country_name
)

if (
  length(
    missing_density_countries
  ) > 0L
) {
  stop(
    "Countries missing from density_by_species.csv: ",
    paste(
      missing_density_countries,
      collapse = ", "
    ),
    call. = FALSE
  )
}

challenge_source <- secondary_data %>%
  left_join(
    density_data,
    by = "country_name"
  )

numeric_source_variables <- c(
  "stock_pigs",
  "stock_poultry",
  "import_pigs",
  "import_poultry",
  "boar_abundance",
  "avian_abundance",
  "density_pigs",
  "density_poultry"
)

challenge_source <- challenge_source %>%
  mutate(
    across(
      all_of(
        numeric_source_variables
      ),
      ~ as_numeric_strict(
        .x,
        cur_column()
      )
    )
  )

walk(
  numeric_source_variables,
  ~ validate_nonnegative(
    challenge_source[[.x]],
    .x
  )
)

# ==============================================================================
# 5. Construct disease-specific Challenge Indices
# ==============================================================================

construct_challenge_index <- function(
    data,
    disease
) {
  disease <- match.arg(
    disease,
    required_diseases
  )

  if (disease == "asf") {
    disease_label <- "African swine fever"
    population_variable <- "stock_pigs"
    density_variable <- "density_pigs"
    imports_variable <- "import_pigs"
    wildlife_variable <- "boar_abundance"
  } else {
    disease_label <- "Avian influenza"
    population_variable <- "stock_poultry"
    density_variable <- "density_poultry"
    imports_variable <- "import_poultry"
    wildlife_variable <- "avian_abundance"
  }

  disease_data <- data %>%
    transmute(
      country_name,
      disease,
      disease_label,
      livestock_population_raw =
        .data[[population_variable]],
      livestock_density_raw =
        .data[[density_variable]],
      live_animal_imports_raw =
        .data[[imports_variable]],
      wildlife_abundance_raw =
        .data[[wildlife_variable]]
    )

  population <- rank_scale_with_neutral_missing(
    disease_data$livestock_population_raw,
    paste0(
      disease,
      ": livestock population"
    )
  )

  density <- log_minmax_scale_with_neutral_missing(
    disease_data$livestock_density_raw,
    paste0(
      disease,
      ": livestock density"
    )
  )

  imports <- rank_scale_with_neutral_missing(
    disease_data$live_animal_imports_raw,
    paste0(
      disease,
      ": live-animal imports"
    )
  )

  wildlife <- rank_scale_with_neutral_missing(
    disease_data$wildlife_abundance_raw,
    paste0(
      disease,
      ": wildlife abundance"
    )
  )

  disease_data <- disease_data %>%
    mutate(
      livestock_population_missing_neutral =
        population$missing_neutral,
      livestock_population_scaled =
        population$scaled,

      livestock_density_log =
        density$log_value,
      livestock_density_missing_neutral =
        density$missing_neutral,
      livestock_density_scaled =
        density$scaled,

      live_animal_imports_missing_neutral =
        imports$missing_neutral,
      live_animal_imports_scaled =
        imports$scaled,

      wildlife_abundance_missing_neutral =
        wildlife$missing_neutral,
      wildlife_abundance_scaled =
        wildlife$scaled
    )

  component_data <- disease_data %>%
    select(
      livestock_population_scaled,
      livestock_density_scaled,
      live_animal_imports_scaled,
      wildlife_abundance_scaled
    )

  disease_data %>%
    mutate(
      challenge_score =
        geometric_mean_rows(
          component_data
        ),
      challenge_index =
        100 *
        challenge_score
    ) %>%
    arrange(
      desc(challenge_index),
      country_name
    )
}

challenge_component_breakdown <- map_dfr(
  required_diseases,
  ~ construct_challenge_index(
    challenge_source,
    .x
  )
) %>%
  arrange(
    factor(
      disease,
      levels = required_diseases
    ),
    desc(challenge_index),
    country_name
  )

# ==============================================================================
# 6. Validate results
# ==============================================================================

expected_rows <-
  nrow(challenge_source) *
  length(required_diseases)

if (
  nrow(
    challenge_component_breakdown
  ) != expected_rows
) {
  stop(
    "Challenge output has ",
    nrow(challenge_component_breakdown),
    " rows; expected ",
    expected_rows,
    ".",
    call. = FALSE
  )
}

duplicate_keys <- challenge_component_breakdown %>%
  count(
    country_name,
    disease
  ) %>%
  filter(
    n != 1L
  )

if (
  nrow(
    duplicate_keys
  ) > 0L
) {
  stop(
    "Each country × disease combination must occur exactly once.",
    call. = FALSE
  )
}

component_columns <- c(
  "livestock_population_scaled",
  "livestock_density_scaled",
  "live_animal_imports_scaled",
  "wildlife_abundance_scaled"
)

component_matrix <- as.matrix(
  challenge_component_breakdown[
    component_columns
  ]
)

if (
  any(
    component_matrix <
      component_floor -
      validation_tolerance |
      component_matrix >
        component_ceiling +
        validation_tolerance
  )
) {
  stop(
    "A scaled Challenge component falls outside the expected 0.05-0.95 range.",
    call. = FALSE
  )
}

if (
  any(
    !is.finite(
      challenge_component_breakdown$challenge_index
    )
  ) ||
    any(
      challenge_component_breakdown$challenge_index <
        100 *
        component_floor -
        validation_tolerance |
        challenge_component_breakdown$challenge_index >
          100 *
          component_ceiling +
          validation_tolerance
    )
) {
  stop(
    "Challenge Index values are invalid or outside the expected 5-95 range.",
    call. = FALSE
  )
}

# ==============================================================================
# 7. Export retained outputs
# ==============================================================================

challenge_index <- challenge_component_breakdown %>%
  select(
    country_name,
    disease,
    disease_label,
    challenge_score,
    challenge_index
  )

write.csv(
  challenge_index,
  challenge_output_file,
  row.names = FALSE
)

write.csv(
  challenge_component_breakdown,
  breakdown_output_file,
  row.names = FALSE
)

message(
  "\nChallenge Index completed.\n",
  "Countries indexed: ",
  nrow(challenge_source),
  "\nOutputs:\n",
  "  ",
  challenge_output_file,
  "\n  ",
  breakdown_output_file,
  "\n"
)
