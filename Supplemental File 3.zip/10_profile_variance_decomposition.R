# ==============================================================================
# 10_profile_variance_decomposition.R
#
# PURPOSE
# Decompose uncertainty in country-level preparedness-challenge profiles and
# livestock-weighted regional profile composition using a grouped variance-based
# global sensitivity analysis.
#
# UNCERTAINTY SOURCES
# 1. IRT estimation uncertainty
# 2. Context Index weighting
# 3. Context adjustment
# 4. Challenge Index weighting
# 5. Interactions among sources
#
# Two independent Monte Carlo base samples and symmetrized pick-freeze hybrids
# are used. First-order variance contributions are estimated for each source;
# the residual variance is retained as interactions.
#
# INPUTS
# data/exported/raw_irt_factor_scores_long.csv
# data/exported/data_secondary.csv
# data/region_key.csv
# results/indices/contextual_diagnostics/contextual_component_breakdown.csv
# results/indices/challenge_diagnostics/challenge_component_breakdown.csv
#
# OUTPUTS
# results/sensitivity/variance_decomposition/profile_variance_decomposition_summary.csv
# results/sensitivity/variance_decomposition/profile_variance_decomposition_qc.csv
# results/sensitivity/variance_decomposition/variance_decomposition_assumptions.csv
# ==============================================================================

suppressPackageStartupMessages({
  library(dplyr)
  library(tidyr)
  library(readr)
  library(tibble)
})

# ==============================================================================
# 1. Settings
# ==============================================================================

n_iterations <- 10000L
random_seed <- 54321L

context_dirichlet_alpha <- 15
challenge_dirichlet_alpha <- 15

preparedness_beta_alpha <- 5
preparedness_beta_beta <- 5
preparedness_weight_min <- 0.25
preparedness_weight_max <- 0.75

scale_lower <- 0.05
scale_upper <- 0.95

required_diseases <- c(
  "aiv_poultry",
  "asf"
)

analysis_model <- "overall_preparedness"

context_components <- c(
  "gdp_scaled",
  "governance_scaled",
  "education_scaled",
  "health_scaled"
)

challenge_components <- c(
  "livestock_population_scaled",
  "livestock_density_scaled",
  "live_animal_imports_scaled",
  "wildlife_abundance_scaled"
)

profile_levels <- c(
  "Prepared (low challenge)",
  "Prepared (high challenge)",
  "Underprepared (low challenge)",
  "Underprepared (high challenge)"
)

source_levels <- c(
  "IRT estimation uncertainty",
  "Context Index weighting",
  "Context adjustment",
  "Challenge Index weighting"
)

all_component_levels <- c(
  source_levels,
  "Interactions"
)

analysis_levels <- c(
  "Country-level profile classification",
  "Livestock-weighted regional profile composition"
)

# ==============================================================================
# 2. Paths
# ==============================================================================

irt_file <- file.path(
  "data",
  "exported",
  "raw_irt_factor_scores_long.csv"
)

secondary_file <- file.path(
  "data",
  "exported",
  "data_secondary.csv"
)

context_file <- file.path(
  "results",
  "indices",
  "contextual_diagnostics",
  "contextual_component_breakdown.csv"
)

challenge_file <- file.path(
  "results",
  "indices",
  "challenge_diagnostics",
  "challenge_component_breakdown.csv"
)

region_file <- file.path(
  "data",
  "region_key.csv"
)

output_dir <- file.path(
  "results",
  "sensitivity",
  "variance_decomposition"
)

summary_file <- file.path(
  output_dir,
  "profile_variance_decomposition_summary.csv"
)

qc_file <- file.path(
  output_dir,
  "profile_variance_decomposition_qc.csv"
)

assumptions_file <- file.path(
  output_dir,
  "variance_decomposition_assumptions.csv"
)

dir.create(
  output_dir,
  recursive = TRUE,
  showWarnings = FALSE
)

# ==============================================================================
# 3. Helpers
# ==============================================================================

read_required_csv <- function(path) {
  if (!file.exists(path)) {
    stop(
      "Required input file was not found: ",
      path,
      call. = FALSE
    )
  }

  read_csv(
    path,
    show_col_types = FALSE,
    progress = FALSE
  )
}

check_required_columns <- function(
    data,
    required_columns,
    object_name
) {
  missing_columns <- setdiff(
    required_columns,
    names(data)
  )

  if (length(missing_columns) > 0L) {
    stop(
      object_name,
      " is missing required columns: ",
      paste(missing_columns, collapse = ", "),
      call. = FALSE
    )
  }
}

check_unique_keys <- function(
    data,
    keys,
    object_name
) {
  duplicates <- data %>%
    count(
      across(
        all_of(keys)
      )
    ) %>%
    filter(
      n != 1L
    )

  if (nrow(duplicates) > 0L) {
    stop(
      object_name,
      " must contain exactly one row per ",
      paste(keys, collapse = " × "),
      ".",
      call. = FALSE
    )
  }
}

standardize_country_name <- function(x) {
  recode(
    as.character(x),
    "Czech Republic" = "Czechia",
    "Turkiye" = "Türkiye",
    "Turkey" = "Türkiye",
    "Slovak Republic" = "Slovakia",
    "Russian Federation" = "Russia",
    .default = as.character(x)
  )
}

rank_scale <- function(
    x,
    lower = scale_lower,
    upper = scale_upper
) {
  if (
    anyNA(x) ||
      any(!is.finite(x))
  ) {
    stop(
      "rank_scale() cannot process missing or non-finite values.",
      call. = FALSE
    )
  }

  n <- length(x)

  if (n < 2L) {
    stop(
      "At least two observations are required for rank scaling.",
      call. = FALSE
    )
  }

  if (length(unique(x)) == 1L) {
    return(
      rep(
        (lower + upper) / 2,
        n
      )
    )
  }

  lower +
    (upper - lower) *
    (rank(x, ties.method = "average") - 1) /
    (n - 1)
}

rank_scale_matrix <- function(x) {
  scaled <- apply(
    x,
    2,
    rank_scale
  )

  if (is.null(dim(scaled))) {
    scaled <- matrix(
      scaled,
      nrow = nrow(x),
      ncol = 1L
    )
  }

  scaled
}

sample_dirichlet <- function(
    n,
    alpha
) {
  draws <- matrix(
    rgamma(
      n * length(alpha),
      shape = rep(
        alpha,
        each = n
      ),
      rate = 1
    ),
    nrow = n,
    ncol = length(alpha)
  )

  draws /
    rowSums(draws)
}

sample_preparedness_capacity_weight <- function(n) {
  preparedness_weight_min +
    (
      preparedness_weight_max -
        preparedness_weight_min
    ) *
    rbeta(
      n,
      shape1 = preparedness_beta_alpha,
      shape2 = preparedness_beta_beta
    )
}

profile_code_from_matrices <- function(
    preparedness_matrix,
    challenge_matrix
) {
  challenge_median <- apply(
    challenge_matrix,
    2,
    median
  )

  low_challenge <- sweep(
    challenge_matrix,
    2,
    challenge_median,
    FUN = "<"
  )

  prepared <-
    preparedness_matrix >= challenge_matrix

  profile_code <- matrix(
    4L,
    nrow = nrow(preparedness_matrix),
    ncol = ncol(preparedness_matrix)
  )

  profile_code[
    prepared &
      low_challenge
  ] <- 1L

  profile_code[
    prepared &
      !low_challenge
  ] <- 2L

  profile_code[
    !prepared &
      low_challenge
  ] <- 3L

  profile_code
}

regional_profile_shares <- function(
    profile_code,
    region_vector,
    livestock_weights,
    region_levels
) {
  n_draws <- ncol(
    profile_code
  )

  output <- array(
    0,
    dim = c(
      length(region_levels),
      length(profile_levels),
      n_draws
    ),
    dimnames = list(
      region = region_levels,
      profile = profile_levels,
      iteration = NULL
    )
  )

  for (
    r in seq_along(
      region_levels
    )
  ) {
    region_index <- which(
      region_vector ==
        region_levels[[r]]
    )

    region_weights <-
      livestock_weights[
        region_index
      ]

    region_total <- sum(
      region_weights
    )

    if (
      !is.finite(
        region_total
      ) ||
        region_total <= 0
    ) {
      stop(
        "Region ",
        region_levels[[r]],
        " has no positive livestock total.",
        call. = FALSE
      )
    }

    region_profiles <-
      profile_code[
        region_index,
        ,
        drop = FALSE
      ]

    for (
      k in seq_along(
        profile_levels
      )
    ) {
      is_profile <-
        region_profiles == k

      output[r, k, ] <-
        colSums(
          sweep(
            is_profile,
            1,
            region_weights,
            FUN = "*"
          )
        ) /
        region_total
    }
  }

  output
}

make_draw_set <- function(
    n_countries
) {
  list(
    irt_z = matrix(
      rnorm(
        n_countries *
          n_iterations
      ),
      nrow = n_countries,
      ncol = n_iterations
    ),
    context_weights =
      sample_dirichlet(
        n_iterations,
        rep(
          context_dirichlet_alpha,
          length(
            context_components
          )
        )
      ),
    preparedness_capacity_weight =
      sample_preparedness_capacity_weight(
        n_iterations
      ),
    challenge_weights =
      sample_dirichlet(
        n_iterations,
        rep(
          challenge_dirichlet_alpha,
          length(
            challenge_components
          )
        )
      )
  )
}

mix_draw_sets <- function(
    primary,
    secondary,
    source_from_primary
) {
  list(
    irt_z =
      if (
        source_from_primary ==
          "IRT estimation uncertainty"
      ) {
        primary$irt_z
      } else {
        secondary$irt_z
      },

    context_weights =
      if (
        source_from_primary ==
          "Context Index weighting"
      ) {
        primary$context_weights
      } else {
        secondary$context_weights
      },

    preparedness_capacity_weight =
      if (
        source_from_primary ==
          "Context adjustment"
      ) {
        primary$preparedness_capacity_weight
      } else {
        secondary$preparedness_capacity_weight
      },

    challenge_weights =
      if (
        source_from_primary ==
          "Challenge Index weighting"
      ) {
        primary$challenge_weights
      } else {
        secondary$challenge_weights
      }
  )
}

symmetrized_first_order_variance <- function(
    y_a,
    y_b,
    y_c,
    y_d
) {
  0.5 *
    (
      cov(
        y_a,
        y_c
      ) +
        cov(
          y_b,
          y_d
        )
    )
}

stabilize_components <- function(
    total_variance,
    raw_main_components
) {
  if (
    !is.finite(
      total_variance
    ) ||
      total_variance <= 0
  ) {
    return(
      list(
        main = setNames(
          rep(
            0,
            length(
              raw_main_components
            )
          ),
          names(
            raw_main_components
          )
        ),
        interaction = 0,
        adjusted = FALSE
      )
    )
  }

  main_nonnegative <- pmax(
    raw_main_components,
    0
  )

  main_sum <- sum(
    main_nonnegative
  )

  adjusted <- any(
    raw_main_components < 0
  )

  if (
    main_sum >
      total_variance
  ) {
    main_nonnegative <-
      main_nonnegative *
      total_variance /
      main_sum

    main_sum <-
      total_variance

    adjusted <- TRUE
  }

  list(
    main = main_nonnegative,
    interaction = max(
      total_variance -
        main_sum,
      0
    ),
    adjusted = adjusted
  )
}

# ==============================================================================
# 4. Read and validate deterministic inputs
# ==============================================================================

irt_scores <- read_required_csv(
  irt_file
)

secondary_data <- read_required_csv(
  secondary_file
)

context_data <- read_required_csv(
  context_file
)

challenge_data <- read_required_csv(
  challenge_file
)

region_key <- read_required_csv(
  region_file
)

check_required_columns(
  irt_scores,
  c(
    "country_name",
    "disease",
    "model",
    "score",
    "score_se"
  ),
  "raw_irt_factor_scores_long.csv"
)

check_required_columns(
  secondary_data,
  c(
    "country_name",
    "stock_pigs",
    "stock_poultry"
  ),
  "data_secondary.csv"
)

check_required_columns(
  context_data,
  c(
    "country_name",
    context_components
  ),
  "contextual_component_breakdown.csv"
)

check_required_columns(
  challenge_data,
  c(
    "country_name",
    "disease",
    challenge_components
  ),
  "challenge_component_breakdown.csv"
)

check_required_columns(
  region_key,
  c(
    "country_name",
    "region"
  ),
  "region_key.csv"
)

context_data <- context_data %>%
  mutate(
    country_name =
      standardize_country_name(
        country_name
      )
  )

check_unique_keys(
  context_data,
  "country_name",
  "Context component data"
)

country_order <- context_data %>%
  arrange(
    country_name
  ) %>%
  pull(
    country_name
  )

n_countries <- length(
  country_order
)

context_matrix <- context_data %>%
  right_join(
    tibble(
      country_name = country_order
    ),
    by = "country_name"
  ) %>%
  arrange(
    match(
      country_name,
      country_order
    )
  ) %>%
  select(
    all_of(
      context_components
    )
  ) %>%
  as.matrix()

if (
  anyNA(
    context_matrix
  ) ||
    any(
      !is.finite(
        context_matrix
      )
    ) ||
    any(
      context_matrix <= 0
    )
) {
  stop(
    "Context component values must be complete, finite, and positive.",
    call. = FALSE
  )
}

region_key <- region_key %>%
  transmute(
    country_name =
      standardize_country_name(
        country_name
      ),
    region =
      as.character(
        region
      )
  ) %>%
  distinct()

check_unique_keys(
  region_key,
  "country_name",
  "Region key"
)

region_key <- tibble(
  country_name = country_order
) %>%
  left_join(
    region_key,
    by = "country_name"
  )

if (
  anyNA(
    region_key$region
  )
) {
  stop(
    "Region mapping is incomplete.",
    call. = FALSE
  )
}

region_levels <- sort(
  unique(
    region_key$region
  )
)

livestock_data <- secondary_data %>%
  transmute(
    country_name =
      standardize_country_name(
        country_name
      ),
    stock_pigs =
      as.numeric(
        stock_pigs
      ),
    stock_poultry =
      as.numeric(
        stock_poultry
      )
  ) %>%
  distinct()

check_unique_keys(
  livestock_data,
  "country_name",
  "Livestock data"
)

livestock_data <- tibble(
  country_name = country_order
) %>%
  left_join(
    livestock_data,
    by = "country_name"
  )

if (
  anyNA(
    livestock_data$stock_pigs
  ) ||
    anyNA(
      livestock_data$stock_poultry
    ) ||
    any(
      !is.finite(
        livestock_data$stock_pigs
      )
    ) ||
    any(
      !is.finite(
        livestock_data$stock_poultry
      )
    ) ||
    any(
      livestock_data$stock_pigs < 0
    ) ||
    any(
      livestock_data$stock_poultry < 0
    )
) {
  stop(
    "Livestock weights must be complete, finite, and non-negative.",
    call. = FALSE
  )
}

country_metadata <- tibble(
  country_name = country_order,
  region = region_key$region,
  stock_pigs = livestock_data$stock_pigs,
  stock_poultry = livestock_data$stock_poultry
)

irt_scores <- irt_scores %>%
  transmute(
    country_name =
      standardize_country_name(
        country_name
      ),
    disease =
      as.character(
        disease
      ),
    model =
      as.character(
        model
      ),
    score =
      as.numeric(
        score
      ),
    score_se =
      as.numeric(
        score_se
      )
  ) %>%
  filter(
    model == analysis_model,
    disease %in% required_diseases
  )

check_unique_keys(
  irt_scores,
  c(
    "country_name",
    "disease",
    "model"
  ),
  "IRT factor scores"
)

challenge_data <- challenge_data %>%
  mutate(
    country_name =
      standardize_country_name(
        country_name
      ),
    disease =
      as.character(
        disease
      )
  ) %>%
  filter(
    disease %in% required_diseases
  )

check_unique_keys(
  challenge_data,
  c(
    "country_name",
    "disease"
  ),
  "Challenge component data"
)

# ==============================================================================
# 5. Evaluate one complete set of uncertainty draws
# ==============================================================================

evaluate_draw_set <- function(
    disease_irt,
    fixed_challenge_components,
    livestock_weights,
    draws
) {
  latent_matrix <-
    matrix(
      disease_irt$score,
      nrow = n_countries,
      ncol = n_iterations
    ) +
    matrix(
      disease_irt$score_se,
      nrow = n_countries,
      ncol = n_iterations
    ) *
    draws$irt_z

  preparedness_capacity_scaled <-
    rank_scale_matrix(
      latent_matrix
    )

  contextual_scaled <- exp(
    log(
      context_matrix
    ) %*%
      t(
        draws$context_weights
      )
  )

  preparedness_capacity_weight <- matrix(
    draws$preparedness_capacity_weight,
    nrow = n_countries,
    ncol = n_iterations,
    byrow = TRUE
  )

  context_adjusted_preparedness <-
    100 *
    (
      preparedness_capacity_scaled ^
        preparedness_capacity_weight
    ) *
    (
      contextual_scaled ^
        (
          1 -
            preparedness_capacity_weight
        )
    )

  challenge_index <-
    100 *
    exp(
      log(
        fixed_challenge_components
      ) %*%
        t(
          draws$challenge_weights
        )
    )

  profile_code <-
    profile_code_from_matrices(
      context_adjusted_preparedness,
      challenge_index
    )

  regional_shares <-
    regional_profile_shares(
      profile_code,
      country_metadata$region,
      livestock_weights,
      region_levels
    )

  list(
    profile_code = profile_code,
    regional_shares = regional_shares
  )
}

# ==============================================================================
# 6. Grouped variance decomposition
# ==============================================================================

set.seed(
  random_seed
)

all_detail <- list()
detail_index <- 1L

for (
  disease_code in required_diseases
) {
  message(
    "\nDisease: ",
    disease_code
  )

  disease_irt <- irt_scores %>%
    filter(
      disease == disease_code
    ) %>%
    right_join(
      tibble(
        country_name = country_order
      ),
      by = "country_name"
    ) %>%
    arrange(
      match(
        country_name,
        country_order
      )
    )

  if (
    anyNA(
      disease_irt$score
    ) ||
      anyNA(
        disease_irt$score_se
      ) ||
      any(
        !is.finite(
          disease_irt$score
        )
      ) ||
      any(
        !is.finite(
          disease_irt$score_se
        )
      ) ||
      any(
        disease_irt$score_se < 0
      )
  ) {
    stop(
      "Missing or invalid IRT score/SE for ",
      disease_code,
      ".",
      call. = FALSE
    )
  }

  disease_challenge <- challenge_data %>%
    filter(
      disease == disease_code
    ) %>%
    right_join(
      tibble(
        country_name = country_order
      ),
      by = "country_name"
    ) %>%
    arrange(
      match(
        country_name,
        country_order
      )
    )

  fixed_challenge_components <-
    disease_challenge %>%
    select(
      all_of(
        challenge_components
      )
    ) %>%
    as.matrix()

  if (
    anyNA(
      fixed_challenge_components
    ) ||
      any(
        !is.finite(
          fixed_challenge_components
        )
      ) ||
      any(
        fixed_challenge_components <= 0
      )
  ) {
    stop(
      "Invalid Challenge component values for ",
      disease_code,
      ".",
      call. = FALSE
    )
  }

  livestock_weights <-
    if (
      disease_code ==
        "aiv_poultry"
    ) {
      country_metadata$stock_poultry
    } else {
      country_metadata$stock_pigs
    }

  draws_a <- make_draw_set(
    n_countries
  )

  draws_b <- make_draw_set(
    n_countries
  )

  eval_a <- evaluate_draw_set(
    disease_irt,
    fixed_challenge_components,
    livestock_weights,
    draws_a
  )

  eval_b <- evaluate_draw_set(
    disease_irt,
    fixed_challenge_components,
    livestock_weights,
    draws_b
  )

  hybrid_a <- list()
  hybrid_b <- list()

  for (
    source_name in source_levels
  ) {
    message(
      "  Pick-freeze source: ",
      source_name
    )

    draws_c <- mix_draw_sets(
      primary = draws_a,
      secondary = draws_b,
      source_from_primary = source_name
    )

    draws_d <- mix_draw_sets(
      primary = draws_b,
      secondary = draws_a,
      source_from_primary = source_name
    )

    hybrid_a[[source_name]] <-
      evaluate_draw_set(
        disease_irt,
        fixed_challenge_components,
        livestock_weights,
        draws_c
      )

    hybrid_b[[source_name]] <-
      evaluate_draw_set(
        disease_irt,
        fixed_challenge_components,
        livestock_weights,
        draws_d
      )
  }

  # Country-level profile classification
  for (
    i in seq_len(
      n_countries
    )
  ) {
    for (
      k in seq_along(
        profile_levels
      )
    ) {
      y_a <- as.numeric(
        eval_a$profile_code[i, ] ==
          k
      )

      y_b <- as.numeric(
        eval_b$profile_code[i, ] ==
          k
      )

      total_variance <-
        0.5 *
        (
          var(y_a) +
            var(y_b)
        )

      raw_main <- setNames(
        numeric(
          length(
            source_levels
          )
        ),
        source_levels
      )

      for (
        source_name in source_levels
      ) {
        y_c <- as.numeric(
          hybrid_a[[source_name]]$profile_code[i, ] ==
            k
        )

        y_d <- as.numeric(
          hybrid_b[[source_name]]$profile_code[i, ] ==
            k
        )

        raw_main[[source_name]] <-
          symmetrized_first_order_variance(
            y_a,
            y_b,
            y_c,
            y_d
          )
      }

      stabilized <-
        stabilize_components(
          total_variance,
          raw_main
        )

      all_detail[[detail_index]] <-
        bind_rows(
          lapply(
            source_levels,
            function(source_name) {
              tibble(
                analysis_level = analysis_levels[[1]],
                disease = disease_code,
                unit = country_order[[i]],
                profile = profile_levels[[k]],
                source = source_name,
                total_variance = total_variance,
                raw_component_variance =
                  raw_main[[source_name]],
                component_variance =
                  stabilized$main[[source_name]],
                finite_sample_adjusted =
                  stabilized$adjusted
              )
            }
          ),
          tibble(
            analysis_level = analysis_levels[[1]],
            disease = disease_code,
            unit = country_order[[i]],
            profile = profile_levels[[k]],
            source = "Interactions",
            total_variance = total_variance,
            raw_component_variance = NA_real_,
            component_variance =
              stabilized$interaction,
            finite_sample_adjusted =
              stabilized$adjusted
          )
        )

      detail_index <-
        detail_index +
        1L
    }
  }

  # Livestock-weighted regional profile composition
  for (
    r in seq_along(
      region_levels
    )
  ) {
    for (
      k in seq_along(
        profile_levels
      )
    ) {
      y_a <-
        eval_a$regional_shares[
          r,
          k,
        ]

      y_b <-
        eval_b$regional_shares[
          r,
          k,
        ]

      total_variance <-
        0.5 *
        (
          var(y_a) +
            var(y_b)
        )

      raw_main <- setNames(
        numeric(
          length(
            source_levels
          )
        ),
        source_levels
      )

      for (
        source_name in source_levels
      ) {
        y_c <-
          hybrid_a[[source_name]]$regional_shares[
            r,
            k,
          ]

        y_d <-
          hybrid_b[[source_name]]$regional_shares[
            r,
            k,
          ]

        raw_main[[source_name]] <-
          symmetrized_first_order_variance(
            y_a,
            y_b,
            y_c,
            y_d
          )
      }

      stabilized <-
        stabilize_components(
          total_variance,
          raw_main
        )

      all_detail[[detail_index]] <-
        bind_rows(
          lapply(
            source_levels,
            function(source_name) {
              tibble(
                analysis_level = analysis_levels[[2]],
                disease = disease_code,
                unit = region_levels[[r]],
                profile = profile_levels[[k]],
                source = source_name,
                total_variance = total_variance,
                raw_component_variance =
                  raw_main[[source_name]],
                component_variance =
                  stabilized$main[[source_name]],
                finite_sample_adjusted =
                  stabilized$adjusted
              )
            }
          ),
          tibble(
            analysis_level = analysis_levels[[2]],
            disease = disease_code,
            unit = region_levels[[r]],
            profile = profile_levels[[k]],
            source = "Interactions",
            total_variance = total_variance,
            raw_component_variance = NA_real_,
            component_variance =
              stabilized$interaction,
            finite_sample_adjusted =
              stabilized$adjusted
          )
        )

      detail_index <-
        detail_index +
        1L
    }
  }
}

variance_detail <- bind_rows(
  all_detail
) %>%
  mutate(
    analysis_level = factor(
      analysis_level,
      levels = analysis_levels
    ),
    source = factor(
      source,
      levels = all_component_levels
    )
  )

# ==============================================================================
# 7. Aggregate variance components
# ==============================================================================

variance_summary <- variance_detail %>%
  group_by(
    analysis_level,
    disease,
    source
  ) %>%
  summarise(
    component_variance = sum(
      component_variance,
      na.rm = TRUE
    ),
    .groups = "drop"
  ) %>%
  group_by(
    analysis_level,
    disease
  ) %>%
  mutate(
    total_decomposed_variance = sum(
      component_variance,
      na.rm = TRUE
    ),
    contribution_percent =
      if_else(
        total_decomposed_variance > 0,
        100 *
          component_variance /
          total_decomposed_variance,
        0
      )
  ) %>%
  ungroup() %>%
  mutate(
    source = factor(
      source,
      levels = all_component_levels
    )
  ) %>%
  arrange(
    analysis_level,
    disease,
    source
  )

# ==============================================================================
# 8. QC
# ==============================================================================

variance_qc <- variance_detail %>%
  group_by(
    analysis_level,
    disease
  ) %>%
  summarise(
    n_outcomes =
      n_distinct(
        interaction(
          unit,
          profile,
          drop = TRUE
        )
      ),
    n_variable_outcomes =
      n_distinct(
        interaction(
          unit[
            total_variance > 0
          ],
          profile[
            total_variance > 0
          ],
          drop = TRUE
        )
      ),
    n_outcomes_with_finite_sample_adjustment =
      n_distinct(
        interaction(
          unit[
            finite_sample_adjusted
          ],
          profile[
            finite_sample_adjusted
          ],
          drop = TRUE
        )
      ),
    summed_decomposed_variance =
      sum(
        component_variance,
        na.rm = TRUE
      ),
    .groups = "drop"
  )

variance_total_qc <- variance_detail %>%
  distinct(
    analysis_level,
    disease,
    unit,
    profile,
    total_variance
  ) %>%
  group_by(
    analysis_level,
    disease
  ) %>%
  summarise(
    summed_total_outcome_variance =
      sum(
        total_variance,
        na.rm = TRUE
      ),
    .groups = "drop"
  )

variance_qc <- variance_qc %>%
  left_join(
    variance_total_qc,
    by = c(
      "analysis_level",
      "disease"
    )
  ) %>%
  mutate(
    decomposition_difference =
      summed_decomposed_variance -
      summed_total_outcome_variance
  )

# ==============================================================================
# 9. Export retained outputs
# ==============================================================================

write_csv(
  variance_summary,
  summary_file
)

write_csv(
  variance_qc,
  qc_file
)

write_csv(
  tibble(
    source = all_component_levels,
    specification = c(
      "Country- and disease-specific latent IRT scores drawn independently from Normal(MAP, posterior SE), then rank-scaled within disease and iteration",
      paste0(
        "Symmetric Dirichlet alpha ",
        context_dirichlet_alpha,
        " for the four Context Index component weights"
      ),
      paste0(
        "Preparedness-capacity weight = ",
        preparedness_weight_min,
        " + ",
        preparedness_weight_max -
          preparedness_weight_min,
        " × Beta(",
        preparedness_beta_alpha,
        ", ",
        preparedness_beta_beta,
        ")"
      ),
      paste0(
        "Symmetric Dirichlet alpha ",
        challenge_dirichlet_alpha,
        " for the four Challenge Index component weights"
      ),
      "Residual variance after the four grouped first-order contributions; includes higher-order interactions among uncertainty sources"
    )
  ),
  assumptions_file
)

message(
  "\nVariance-based global sensitivity analysis completed.\n",
  "Iterations per base sample: ",
  n_iterations,
  "\nOutputs:\n",
  "  ",
  summary_file,
  "\n  ",
  qc_file,
  "\n  ",
  assumptions_file,
  "\n"
)
