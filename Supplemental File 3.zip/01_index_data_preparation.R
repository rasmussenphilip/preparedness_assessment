# ==============================================================================
# 01_index_data_preparation.R
# Date: 2026-09-19
# Purpose: Prepare the index data required by the final preparedness pipeline.
# ==============================================================================

suppressPackageStartupMessages({
  library(dplyr)
  library(readxl)
  library(tidyr)
  library(purrr)
})

secondary_dir <- file.path("data", "secondary_data")
export_dir <- file.path("data", "exported")
dir.create(export_dir, recursive = TRUE, showWarnings = FALSE)

standardize_country_name <- function(x) {
  recode(
    as.character(x),
    "Czech Republic" = "Czechia",
    "Turkiye" = "Türkiye",
    "Turkey" = "Türkiye",
    "Slovak Republic" = "Slovakia",
    "Russian Federation" = "Russia",
    "The Netherlands" = "Netherlands",
    "Netherlands (Kingdom of the)" = "Netherlands",
    "United Kingdom of Great Britain and Northern Ireland" = "United Kingdom",
    "Republic of Moldova" = "Moldova",
    .default = as.character(x)
  )
}

normalize_source_column_names <- function(x) {
  x <- iconv(x, from = "", to = "ASCII//TRANSLIT")
  x <- tolower(x)
  x <- gsub("[^a-z0-9]+", "_", x)
  x <- gsub("^_+|_+$", "", x)
  make.unique(x, sep = "_")
}

trim_world_bank_indicator <- function(input_file, value_name) {
  data <- read_excel(input_file)
  normalized_names <- normalize_source_column_names(names(data))

  if (!"country_name" %in% normalized_names) {
    data <- read_excel(input_file, sheet = "Data", skip = 3)
    normalized_names <- normalize_source_column_names(names(data))
  }

  names(data) <- normalized_names

  if (!"country_name" %in% names(data)) {
    stop("Could not identify country_name in World Bank file: ", input_file)
  }

  year_columns <- names(data)[grepl("^[0-9]{4}$", names(data))]

  if (length(year_columns) == 0L) {
    stop("No year columns were found in World Bank file: ", input_file)
  }

  data %>%
    transmute(
      country_name = standardize_country_name(country_name),
      across(all_of(year_columns))
    ) %>%
    pivot_longer(
      cols = all_of(year_columns),
      names_to = "year",
      values_to = "value"
    ) %>%
    filter(!is.na(value)) %>%
    mutate(
      year = as.numeric(year),
      value = as.numeric(value)
    ) %>%
    group_by(country_name) %>%
    slice_max(order_by = year, n = 1, with_ties = FALSE) %>%
    ungroup() %>%
    select(country_name, value) %>%
    rename(!!value_name := value)
}

trim_faostat_livestock <- function(
    input_file,
    prefix,
    poultry_unit_multiplier = 1
) {
  read.csv(input_file) %>%
    mutate(country_name = standardize_country_name(country_name)) %>%
    select(country_name, Item, Year, Value) %>%
    filter(
      !is.na(Value),
      Item %in% c("Swine / pigs", "Chickens", "Ducks", "Geese", "Turkeys")
    ) %>%
    group_by(country_name, Item) %>%
    slice_max(order_by = Year, n = 1, with_ties = FALSE) %>%
    ungroup() %>%
    mutate(
      species = if_else(Item == "Swine / pigs", "pigs", "poultry"),
      Value = if_else(
        species == "poultry",
        Value * poultry_unit_multiplier,
        Value
      )
    ) %>%
    group_by(country_name, species) %>%
    summarise(value = sum(Value, na.rm = TRUE), .groups = "drop") %>%
    mutate(variable = paste(prefix, species, sep = "_")) %>%
    select(country_name, variable, value) %>%
    pivot_wider(
      names_from = variable,
      values_from = value,
      values_fill = 0
    )
}

prepare_land_area <- function(input_file) {
  land_area <- read.csv(
    input_file,
    fileEncoding = "UTF-8-BOM",
    check.names = FALSE,
    stringsAsFactors = FALSE
  )

  required_columns <- c(
    "Area",
    "Element",
    "Item",
    "Year",
    "Unit",
    "Value"
  )

  missing_columns <- setdiff(required_columns, names(land_area))

  if (length(missing_columns) > 0L) {
    stop(
      "Land area - FAO STAT.csv is missing required columns: ",
      paste(missing_columns, collapse = ", ")
    )
  }

  land_area %>%
    filter(
      Element == "Area",
      Item == "Land area",
      !is.na(Value)
    ) %>%
    transmute(
      country_name = standardize_country_name(Area),
      year = as.numeric(Year),
      unit = trimws(as.character(Unit)),
      land_area_raw = as.numeric(Value),
      land_area_km2 = case_when(
        unit == "1000 ha" ~ land_area_raw * 10,
        unit == "ha" ~ land_area_raw * 0.01,
        unit %in% c("km2", "km^2", "km²") ~ land_area_raw,
        TRUE ~ NA_real_
      )
    ) %>%
    group_by(country_name) %>%
    slice_max(order_by = year, n = 1, with_ties = FALSE) %>%
    ungroup() %>%
    mutate(
      land_area_km2 = if_else(
        is.finite(land_area_km2) & land_area_km2 > 0,
        land_area_km2,
        NA_real_
      )
    ) %>%
    select(country_name, land_area_km2)
}

# Context variables ------------------------------------------------------------

gdppc_ppp <- trim_world_bank_indicator(
  file.path(secondary_dir, "API_NY.GDP.PCAP.PP.CD_DS2_en_excel_v2_334239.xls"),
  "gdppc_ppp"
)

health_exp_pc_ppp <- trim_world_bank_indicator(
  file.path(secondary_dir, "API_SH.XPD.CHEX.PP.CD_DS2_en_excel_v2_329411.xls"),
  "health_exp_pc_ppp"
)

adv_ed <- trim_world_bank_indicator(
  file.path(secondary_dir, "API_SL.TLF.ADVN.ZS_DS2_en_excel_v2_2186.xls"),
  "adv_ed"
)

wgi <- read_excel(
  file.path(secondary_dir, "P_Data_Extract_From_Worldwide_Governance_Indicators.xlsx")
) %>%
  select(-2, -3) %>%
  mutate(country_name = standardize_country_name(country_name))

wgi[wgi == ".."] <- NA
colnames(wgi)[3:16] <- as.character(2010:2023)
colnames(wgi)[2] <- "estimate"

wgi <- wgi %>%
  pivot_longer(
    cols = matches("^20[0-9]{2}$"),
    names_to = "year",
    values_to = "value"
  ) %>%
  filter(!is.na(value)) %>%
  mutate(
    year = as.numeric(year),
    value = as.numeric(value)
  ) %>%
  group_by(country_name, estimate) %>%
  slice_max(order_by = year, n = 1, with_ties = FALSE) %>%
  ungroup() %>%
  select(country_name, estimate, value) %>%
  pivot_wider(names_from = estimate, values_from = value)

colnames(wgi) <- c(
  "country_name",
  "cc_score",
  "ge_score",
  "pv_score",
  "rq_score",
  "rl_score",
  "va_score"
)

wgi <- wgi %>%
  select(country_name, ge_score)

# Livestock stocks, imports, and land area -------------------------------------

stocks <- trim_faostat_livestock(
  file.path(secondary_dir, "Live animal stocks - FAOSTAT.csv"),
  prefix = "stock",
  poultry_unit_multiplier = 1000
)

imports <- trim_faostat_livestock(
  file.path(secondary_dir, "Live animal imports - FAOSTAT.csv"),
  prefix = "import"
)

land_area <- prepare_land_area(
  file.path(secondary_dir, "Land area - FAO STAT.csv")
)

# Outbreak-history variables used by validation -------------------------------

wahis <- read_excel(
  file.path(secondary_dir, "infur_20250224.xlsx"),
  sheet = 2
) %>%
  rename(event_start_date = `event_start date`) %>%
  mutate(
    event_start_date = as.Date(event_start_date, format = "%d-%m-%Y"),
    event_year = as.integer(format(event_start_date, "%Y")),
    country_name = standardize_country_name(country_name)
  )

disease_map <- list(
  asf = "African swine fever virus (Inf. with)",
  aiv = c(
    "High pathogenicity avian influenza viruses (poultry) (Inf. with)",
    "Low pathogenic avian influenza (poultry) (2006-2021)",
    "Influenza A virus (Inf. with)"
  )
)

count_events <- function(disease_code, disease_names) {
  wahis %>%
    filter(disease_eng %in% disease_names) %>%
    group_by(country_name) %>%
    summarise(
      "{disease_code}_recent_5yr" :=
        n_distinct(epi_event_id[event_year %in% 2020:2024]),
      "{disease_code}_events_10yr" :=
        n_distinct(epi_event_id[event_year %in% 2015:2024]),
      .groups = "drop"
    )
}

events <- imap(
  disease_map,
  ~ count_events(.y, .x)
) %>%
  reduce(full_join, by = "country_name") %>%
  mutate(across(-country_name, ~ replace_na(.x, 0)))

# Wildlife abundance -----------------------------------------------------------

avian_abundance_observed <- read.csv(
  file.path(secondary_dir, "avian_observed_by_country.csv")
) %>%
  transmute(
    country_name = standardize_country_name(country_name),
    avian_abundance = as.numeric(individuals)
  ) %>%
  filter(!is.na(country_name), country_name != "")

if (anyDuplicated(avian_abundance_observed$country_name) > 0L) {
  stop("Duplicate countries were found in avian_observed_by_country.csv.")
}

boar_abundance_raw <- read.csv(
  file.path(secondary_dir, "boar_density_observed_by_country.csv"),
  check.names = FALSE,
  stringsAsFactors = FALSE
)

names(boar_abundance_raw) <- normalize_source_column_names(names(boar_abundance_raw))

occurrence_density_col <- which(names(boar_abundance_raw) == "occurrence_model")
hunting_density_col <- which(names(boar_abundance_raw) == "hunting_model")

if (length(occurrence_density_col) != 1L || length(hunting_density_col) != 1L) {
  stop(
    "Could not uniquely identify the occurrence- and hunting-model columns in ",
    "boar_density_observed_by_country.csv."
  )
}

occurrence_total_col <- occurrence_density_col + 1L
hunting_total_col <- hunting_density_col + 1L

if (
  occurrence_total_col > ncol(boar_abundance_raw) ||
    hunting_total_col > ncol(boar_abundance_raw)
) {
  stop("Could not identify total-population columns in the wild-boar source.")
}

parse_boar_number <- function(x) {
  suppressWarnings(as.numeric(gsub(",", "", as.character(x), fixed = TRUE)))
}

boar_range_limited_countries <- c(
  "Albania",
  "Denmark",
  "Finland",
  "Netherlands",
  "Norway",
  "United Kingdom"
)

boar_unreliable_hunting_countries <- c(
  "Albania",
  "Armenia",
  "Azerbaijan",
  "Georgia",
  "Türkiye"
)

boar_abundance_observed <- tibble::tibble(
  country = boar_abundance_raw[["country"]],
  occurrence_total = boar_abundance_raw[[occurrence_total_col]],
  hunting_total = boar_abundance_raw[[hunting_total_col]]
) %>%
  transmute(
    country_name = standardize_country_name(
      trimws(sub("\\*$", "", as.character(country)))
    ),
    occurrence_total = parse_boar_number(occurrence_total),
    hunting_total = parse_boar_number(hunting_total)
  ) %>%
  filter(!is.na(country_name), country_name != "") %>%
  mutate(
    boar_abundance = case_when(
      country_name %in% boar_range_limited_countries &
        !is.na(occurrence_total) &
        !is.na(hunting_total) ~
          pmin(occurrence_total, hunting_total),
      country_name %in% boar_unreliable_hunting_countries ~
        occurrence_total,
      !is.na(occurrence_total) & !is.na(hunting_total) ~
        (occurrence_total + hunting_total) / 2,
      !is.na(occurrence_total) ~ occurrence_total,
      !is.na(hunting_total) ~ hunting_total,
      TRUE ~ NA_real_
    )
  ) %>%
  select(country_name, boar_abundance)

if (anyDuplicated(boar_abundance_observed$country_name) > 0L) {
  stop("Duplicate countries were found in boar_density_observed_by_country.csv.")
}

# Final study countries and wildlife completion --------------------------------

study_countries <- read_excel(file.path("data", "primary_long.xlsx")) %>%
  transmute(country_name = standardize_country_name(country_name)) %>%
  distinct()

avian_abundance <- study_countries %>%
  left_join(avian_abundance_observed, by = "country_name")

boar_zero_countries <- c("Iceland", "Ireland", "Cyprus", "Malta")

boar_abundance <- study_countries %>%
  left_join(boar_abundance_observed, by = "country_name") %>%
  mutate(
    boar_abundance = if_else(
      country_name %in% boar_zero_countries,
      0,
      boar_abundance
    )
  )

missing_boar_abundance_countries <- boar_abundance %>%
  filter(is.na(boar_abundance)) %>%
  pull(country_name)

if (length(missing_boar_abundance_countries) > 0L) {
  stop(
    "No wild-boar abundance estimate could be obtained for: ",
    paste(missing_boar_abundance_countries, collapse = ", ")
  )
}

# Domestic livestock density --------------------------------------------------

density_by_species <- study_countries %>%
  left_join(stocks, by = "country_name") %>%
  left_join(land_area, by = "country_name")

missing_land_area_countries <- density_by_species %>%
  filter(is.na(land_area_km2)) %>%
  pull(country_name)

if (length(missing_land_area_countries) > 0L) {
  stop(
    "No usable land-area value could be obtained for: ",
    paste(missing_land_area_countries, collapse = ", ")
  )
}

density_by_species <- density_by_species %>%
  transmute(
    country_name,
    density_pigs = stock_pigs / land_area_km2,
    density_poultry = stock_poultry / land_area_km2
  )

# Merge and export -------------------------------------------------------------

covariate_data <- list(
  gdppc_ppp,
  health_exp_pc_ppp,
  adv_ed,
  wgi,
  stocks,
  imports,
  events,
  avian_abundance,
  boar_abundance
)

data_secondary <- reduce(
  covariate_data,
  left_join,
  .init = study_countries,
  by = "country_name"
) %>%
  mutate(
    across(
      c(
        asf_recent_5yr,
        asf_events_10yr,
        aiv_recent_5yr,
        aiv_events_10yr,
        import_pigs,
        import_poultry
      ),
      ~ replace_na(.x, 0)
    )
  ) %>%
  select(
    country_name,
    gdppc_ppp,
    health_exp_pc_ppp,
    adv_ed,
    ge_score,
    stock_pigs,
    stock_poultry,
    import_pigs,
    import_poultry,
    asf_recent_5yr,
    asf_events_10yr,
    aiv_recent_5yr,
    aiv_events_10yr,
    avian_abundance,
    boar_abundance
  )

write.csv(
  data_secondary,
  file.path(export_dir, "data_secondary.csv"),
  row.names = FALSE
)

write.csv(
  density_by_species,
  file.path(export_dir, "density_by_species.csv"),
  row.names = FALSE
)
