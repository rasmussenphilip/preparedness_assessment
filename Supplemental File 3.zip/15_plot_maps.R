# ==============================================================================
# 15_plot_maps.R
#
# PURPOSE
# Plot the retained geographic figures for study regions, the Contextual Index,
# and disease-specific Challenge Indices and components.
#
# INPUTS
# data/region_key.csv
# results/indices/contextual_diagnostics/contextual_component_breakdown.csv
# results/indices/challenge_diagnostics/challenge_component_breakdown.csv
#
# OUTPUTS
# results/plots/maps/study_regions.png
# results/plots/maps/context_variables_and_index.png
# results/plots/maps/challenge_indices_AI_ASF.png
# results/plots/maps/challenge_components_AI.png
# results/plots/maps/challenge_components_ASF.png
# ==============================================================================

suppressPackageStartupMessages({
  library(dplyr)
  library(readr)
  library(ggplot2)
  library(countrycode)
  library(rnaturalearth)
  library(sf)
  library(patchwork)
})

# ==============================================================================
# 1. Paths and settings
# ==============================================================================

region_file <- file.path(
  "data",
  "region_key.csv"
)

context_file <- file.path(
  "results",
  "indices",
  "contextual_diagnostics",
  "contextual_component_breakdown.csv"
)

challenge_file <- file.path(
  "results",
  "indices",
  "challenge_diagnostics",
  "challenge_component_breakdown.csv"
)

output_dir <- file.path(
  "results",
  "plots",
  "maps"
)

plot_dpi <- 300

region_levels <- c(
  "Central Europe",
  "Northern Europe",
  "Southern Europe",
  "Western Europe",
  "Not included"
)

region_colors <- c(
  "Central Europe" = "#FFB900",
  "Northern Europe" = "#65CCFF",
  "Southern Europe" = "#FF99BF",
  "Western Europe" = "#95CC5E",
  "Not included" = "#EEE9E9"
)

dir.create(
  output_dir,
  recursive = TRUE,
  showWarnings = FALSE
)

# ==============================================================================
# 2. Helpers
# ==============================================================================

read_required_csv <- function(path) {
  if (!file.exists(path)) {
    stop(
      "Required input file was not found: ",
      path,
      call. = FALSE
    )
  }

  read_csv(
    path,
    show_col_types = FALSE,
    progress = FALSE
  )
}

check_required_columns <- function(
    data,
    required_columns,
    object_name
) {
  missing_columns <- setdiff(
    required_columns,
    names(data)
  )

  if (length(missing_columns) > 0L) {
    stop(
      object_name,
      " is missing required columns: ",
      paste(missing_columns, collapse = ", "),
      call. = FALSE
    )
  }
}

check_unique_keys <- function(
    data,
    keys,
    object_name
) {
  duplicates <- data %>%
    count(
      across(
        all_of(keys)
      )
    ) %>%
    filter(
      n != 1L
    )

  if (nrow(duplicates) > 0L) {
    stop(
      object_name,
      " must contain exactly one row per ",
      paste(keys, collapse = " × "),
      ".",
      call. = FALSE
    )
  }
}

standardize_country_name <- function(x) {
  recode(
    as.character(x),
    "Czech Republic" = "Czechia",
    "Slovak Republic" = "Slovakia",
    "Republic of Moldova" = "Moldova",
    "Macedonia" = "North Macedonia",
    "Bosnia-Herzegovina" = "Bosnia and Herzegovina",
    "Turkiye" = "Türkiye",
    "Turkey" = "Türkiye",
    "Russian Federation" = "Russia",
    .default = as.character(x)
  )
}

add_iso2 <- function(data) {
  data %>%
    mutate(
      country_name =
        standardize_country_name(
          country_name
        ),
      iso_a2 =
        countrycode(
          country_name,
          origin = "country.name",
          destination = "iso2c"
        )
    )
}

make_panel_map <- function(
    values,
    title,
    title_size = 10.5
) {
  plot_data <- map_base %>%
    left_join(
      values %>%
        select(
          iso_a2,
          value
        ),
      by = "iso_a2"
    )

  ggplot(
    plot_data
  ) +
    geom_sf(
      aes(
        fill = value
      ),
      color = "black",
      linewidth = 0.30
    ) +
    coord_sf(
      xlim = c(
        -25,
        45
      ),
      ylim = c(
        33,
        72
      ),
      datum = NA,
      expand = FALSE
    ) +
    scale_fill_viridis_c(
      option = "C",
      limits = c(
        0,
        100
      ),
      breaks =
        seq(
          0,
          100,
          20
        ),
      na.value = "#EEE9E9",
      name = NULL
    ) +
    labs(
      title = title
    ) +
    theme_void(
      base_size = 11
    ) +
    theme(
      plot.background =
        element_rect(
          fill = "white",
          color = NA
        ),
      plot.title =
        element_text(
          hjust = 0.5,
          face = "bold",
          size = title_size,
          margin =
            margin(
              b = 4
            )
        ),
      plot.subtitle =
        element_text(
          hjust = 0.5
        ),
      legend.position =
        "none",
      plot.margin =
        margin(
          2,
          2,
          2,
          2
        )
    )
}

build_colorbar <- function() {
  colorbar_data <- tibble(
    value =
      seq(
        0,
        100,
        length.out = 501
      ),
    y = 1
  )

  ggplot(
    colorbar_data,
    aes(
      x = value,
      y = y,
      fill = value
    )
  ) +
    geom_raster() +
    annotate(
      "rect",
      xmin = 0,
      xmax = 100,
      ymin = 0.5,
      ymax = 1.5,
      fill = NA,
      color = "black",
      linewidth = 0.4
    ) +
    scale_fill_viridis_c(
      option = "C",
      limits = c(
        0,
        100
      ),
      guide = "none"
    ) +
    scale_x_continuous(
      breaks =
        seq(
          0,
          100,
          20
        ),
      expand = c(
        0,
        0
      )
    ) +
    coord_cartesian(
      xlim = c(
        0,
        100
      ),
      expand = FALSE
    ) +
    scale_y_continuous(
      limits = c(
        0.5,
        1.5
      ),
      expand = c(
        0,
        0
      )
    ) +
    theme_void(
      base_size = 11
    ) +
    theme(
      axis.text.x =
        element_text(
          color = "black",
          size = 9,
          margin =
            margin(
              t = 3
            )
        ),
      axis.ticks.x =
        element_blank(),
      plot.margin =
        margin(
          0,
          0,
          0,
          0
        )
    )
}

build_colorbar_row <- function(
    colorbar_plot
) {
  plot_spacer() +
    colorbar_plot +
    plot_spacer() +
    plot_layout(
      widths = c(
        2.1,
        1.8,
        2.1
      )
    )
}

# ==============================================================================
# 3. Read and prepare analytical inputs
# ==============================================================================

region_key <- read_required_csv(
  region_file
)

context_data <- read_required_csv(
  context_file
)

challenge_data <- read_required_csv(
  challenge_file
)

check_required_columns(
  region_key,
  c(
    "country_name",
    "region"
  ),
  "region_key.csv"
)

check_required_columns(
  context_data,
  c(
    "country_name",
    "contextual_index",
    "gdp_scaled",
    "governance_scaled",
    "education_scaled",
    "health_scaled"
  ),
  "contextual_component_breakdown.csv"
)

check_required_columns(
  challenge_data,
  c(
    "country_name",
    "disease",
    "challenge_index",
    "livestock_population_scaled",
    "livestock_density_scaled",
    "live_animal_imports_scaled",
    "wildlife_abundance_scaled"
  ),
  "challenge_component_breakdown.csv"
)

region_key <- region_key %>%
  add_iso2() %>%
  select(
    country_name,
    iso_a2,
    region
  )

context_data <- context_data %>%
  add_iso2()

challenge_data <- challenge_data %>%
  add_iso2() %>%
  mutate(
    disease =
      as.character(
        disease
      )
  )

check_unique_keys(
  region_key,
  "country_name",
  "Region key"
)

check_unique_keys(
  context_data,
  "country_name",
  "Context component data"
)

check_unique_keys(
  challenge_data,
  c(
    "country_name",
    "disease"
  ),
  "Challenge component data"
)

if (
  anyNA(
    region_key$iso_a2
  ) ||
    anyNA(
      context_data$iso_a2
    ) ||
    anyNA(
      challenge_data$iso_a2
    )
) {
  stop(
    "At least one study country could not be converted to ISO2.",
    call. = FALSE
  )
}

# ==============================================================================
# 4. Build common European map layer
# ==============================================================================

map_base <- ne_countries(
  scale = "medium",
  returnclass = "sf"
) %>%
  filter(
    continent == "Europe",
    !name_long %in%
      c(
        "Russia",
        "Russian Federation",
        "Turkey",
        "Türkiye"
      )
  ) %>%
  mutate(
    iso_a2 =
      coalesce(
        as.character(
          iso_a2_eh
        ),
        as.character(
          iso_a2
        )
      )
  )

# ==============================================================================
# 5. Study-region assignments
# ==============================================================================

region_map_data <- map_base %>%
  left_join(
    region_key %>%
      select(
        iso_a2,
        region
      ),
    by = "iso_a2"
  ) %>%
  mutate(
    region = if_else(
      is.na(region),
      "Not included",
      as.character(region)
    ),
    region = factor(
      region,
      levels = region_levels
    )
  )

region_plot <- ggplot(
  region_map_data
) +
  geom_sf(
    aes(
      fill = region
    ),
    color = "black",
    linewidth = 0.35
  ) +
  coord_sf(
    xlim = c(
      -25,
      45
    ),
    ylim = c(
      33,
      72
    ),
    datum = NA,
    expand = FALSE
  ) +
  scale_fill_manual(
    values = region_colors,
    breaks = region_levels,
    drop = FALSE,
    name = NULL
  ) +
  labs(
    title =
      "Study countries across study regions"
  ) +
  theme_void(
    base_size = 11
  ) +
  theme(
    plot.background =
      element_rect(
        fill = "white",
        color = NA
      ),
    plot.title =
      element_text(
        hjust = 0.5,
        face = "bold",
        margin =
          margin(
            b = 8
          )
      ),
    plot.subtitle =
      element_text(
        hjust = 0.5
      ),
    legend.position =
      "bottom",
    legend.key.height =
      grid::unit(
        0.35,
        "cm"
      ),
    legend.key.width =
      grid::unit(
        0.8,
        "cm"
      ),
    legend.key.spacing.x =
      grid::unit(
        0.7,
        "cm"
      ),
    legend.text =
      element_text(
        size = 9.5
      ),
    plot.margin =
      margin(
        5,
        5,
        5,
        5
      )
  ) +
  guides(
    fill =
      guide_legend(
        nrow = 1,
        byrow = TRUE
      )
  )

ggsave(
  filename =
    file.path(
      output_dir,
      "study_regions.png"
    ),
  plot =
    region_plot,
  width =
    8,
  height =
    8,
  dpi =
    plot_dpi,
  bg =
    "white"
)

# ==============================================================================
# 6. Context variables and Contextual Index
# ==============================================================================

context_values <- list(
  gdp =
    context_data %>%
    transmute(
      iso_a2,
      value =
        100 *
        gdp_scaled
    ),
  governance =
    context_data %>%
    transmute(
      iso_a2,
      value =
        100 *
        governance_scaled
    ),
  education =
    context_data %>%
    transmute(
      iso_a2,
      value =
        100 *
        education_scaled
    ),
  health =
    context_data %>%
    transmute(
      iso_a2,
      value =
        100 *
        health_scaled
    ),
  overall =
    context_data %>%
    transmute(
      iso_a2,
      value =
        contextual_index
    )
)

context_maps <- wrap_plots(
  A =
    make_panel_map(
      context_values$health,
      "A. Health expenditure per capita (PPP)"
    ),
  B =
    make_panel_map(
      context_values$gdp,
      "B. GDP per capita (PPP)"
    ),
  C =
    make_panel_map(
      context_values$governance,
      "C. Government effectiveness score"
    ),
  D =
    make_panel_map(
      context_values$education,
      "D. Advanced education (% working-age pop.)"
    ),
  E =
    make_panel_map(
      context_values$overall,
      "E. Contextual Index",
      title_size = 12
    ),
  design =
    "
ABE
CDE
",
  widths =
    c(
      1,
      1,
      2.05
    ),
  heights =
    c(
      1,
      1
    )
)

context_panel <- (
  build_colorbar_row(
    build_colorbar()
  ) /
    context_maps
) +
  plot_layout(
    heights =
      c(
        0.03,
        1
      )
  ) +
  plot_annotation(
    title =
      "Contextual indicators and Contextual Index across study countries",
    theme =
      theme(
        plot.title =
          element_text(
            hjust = 0.5,
            face = "bold",
            size = 16,
            margin =
              margin(
                b = 4
              )
          ),
        plot.subtitle =
          element_text(
            hjust = 0.5
          )
      )
  )

ggsave(
  filename =
    file.path(
      output_dir,
      "context_variables_and_index.png"
    ),
  plot =
    context_panel,
  width =
    13,
  height =
    7.8,
  dpi =
    plot_dpi,
  bg =
    "white"
)

# ==============================================================================
# 7. Challenge Index and component figures
# ==============================================================================

get_challenge_values <- function(
    disease_code
) {
  disease_data <-
    challenge_data %>%
    filter(
      disease ==
        disease_code
    )

  list(
    population =
      disease_data %>%
      transmute(
        iso_a2,
        value =
          100 *
          livestock_population_scaled
      ),
    density =
      disease_data %>%
      transmute(
        iso_a2,
        value =
          100 *
          livestock_density_scaled
      ),
    imports =
      disease_data %>%
      transmute(
        iso_a2,
        value =
          100 *
          live_animal_imports_scaled
      ),
    wildlife =
      disease_data %>%
      transmute(
        iso_a2,
        value =
          100 *
          wildlife_abundance_scaled
      ),
    overall =
      disease_data %>%
      transmute(
        iso_a2,
        value =
          challenge_index
      )
  )
}

challenge_ai <-
  get_challenge_values(
    "aiv_poultry"
  )

challenge_asf <-
  get_challenge_values(
    "asf"
  )

challenge_colorbar_row <-
  build_colorbar_row(
    build_colorbar()
  )

challenge_index_maps <- wrap_plots(
  A =
    make_panel_map(
      challenge_ai$overall,
      "A. Challenge Index (AI)",
      title_size = 12
    ),
  B =
    make_panel_map(
      challenge_asf$overall,
      "B. Challenge Index (ASF)",
      title_size = 12
    ),
  ncol = 2
)

challenge_index_figure <- (
  challenge_colorbar_row /
    challenge_index_maps
) +
  plot_layout(
    heights =
      c(
        0.045,
        1
      )
  ) +
  plot_annotation(
    title =
      "Disease-specific Challenge Indices across study countries",
    theme =
      theme(
        plot.title =
          element_text(
            hjust = 0.5,
            face = "bold",
            size = 16,
            margin =
              margin(
                b = 4
              )
          ),
        plot.subtitle =
          element_text(
            hjust = 0.5
          )
      )
  )

ggsave(
  filename =
    file.path(
      output_dir,
      "challenge_indices_AI_ASF.png"
    ),
  plot =
    challenge_index_figure,
  width =
    15,
  height =
    8,
  dpi =
    plot_dpi,
  bg =
    "white"
)

make_challenge_component_panel <- function(
    title,
    population,
    density,
    imports,
    wildlife,
    population_title,
    density_title,
    imports_title,
    wildlife_title,
    output_filename
) {
  component_maps <- wrap_plots(
    A =
      make_panel_map(
        population,
        paste0(
          "A. ",
          population_title
        ),
        title_size = 10.2
      ),
    B =
      make_panel_map(
        density,
        paste0(
          "B. ",
          density_title
        ),
        title_size = 10.2
      ),
    C =
      make_panel_map(
        imports,
        paste0(
          "C. ",
          imports_title
        ),
        title_size = 10.2
      ),
    D =
      make_panel_map(
        wildlife,
        paste0(
          "D. ",
          wildlife_title
        ),
        title_size = 10.2
      ),
    ncol = 2,
    byrow = TRUE
  )

  figure <- (
    challenge_colorbar_row /
      component_maps
  ) +
    plot_layout(
      heights =
        c(
          0.05,
          1
        )
    ) +
    plot_annotation(
      title = title,
      theme =
        theme(
          plot.title =
            element_text(
              hjust = 0.5,
              face = "bold",
              size = 16,
              margin =
                margin(
                  b = 4
                )
            ),
          plot.subtitle =
            element_text(
              hjust = 0.5
            )
        )
    )

  ggsave(
    filename =
      file.path(
        output_dir,
        output_filename
      ),
    plot =
      figure,
    width =
      9,
    height =
      9,
    dpi =
      plot_dpi,
    bg =
      "white"
  )
}

make_challenge_component_panel(
  title =
    "Challenge indicators across study countries (AI)",
  population =
    challenge_ai$population,
  density =
    challenge_ai$density,
  imports =
    challenge_ai$imports,
  wildlife =
    challenge_ai$wildlife,
  population_title =
    "Poultry population",
  density_title =
    "Poultry density",
  imports_title =
    "Poultry imports",
  wildlife_title =
    "Wild bird abundance",
  output_filename =
    "challenge_components_AI.png"
)

make_challenge_component_panel(
  title =
    "Challenge indicators across study countries (ASF)",
  population =
    challenge_asf$population,
  density =
    challenge_asf$density,
  imports =
    challenge_asf$imports,
  wildlife =
    challenge_asf$wildlife,
  population_title =
    "Pig population",
  density_title =
    "Pig density",
  imports_title =
    "Pig imports",
  wildlife_title =
    "Wild boar abundance",
  output_filename =
    "challenge_components_ASF.png"
)

message(
  "\nMap plotting completed.\n",
  "Outputs written to:\n  ",
  output_dir,
  "\n"
)
