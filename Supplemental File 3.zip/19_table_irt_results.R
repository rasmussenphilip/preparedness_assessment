# ==============================================================================
# 19_table_irt_results.R
#
# PURPOSE
# Create the supplementary country-level table of deterministic IRT results for
# the single overall Preparedness capacity model fitted for AI and ASF.
#
# Anonymous country numbering is aligned with Script 17 by ordering countries
# on their mean disease-specific Preparedness capacity index.
#
# INPUT
# data/exported/raw_irt_factor_scores_long.csv
#
# OUTPUT
# results/tables/irt_results.csv
# ==============================================================================

suppressPackageStartupMessages({
  library(dplyr)
  library(readr)
})

# ==============================================================================
# 1. Paths and settings
# ==============================================================================

input_file <- file.path(
  "data",
  "exported",
  "raw_irt_factor_scores_long.csv"
)

output_dir <- file.path(
  "results",
  "tables"
)

output_file <- file.path(
  output_dir,
  "irt_results.csv"
)

analysis_model <- "overall_preparedness"

required_diseases <- c(
  "aiv_poultry",
  "asf"
)

expected_n_countries <- 26L

dir.create(
  output_dir,
  recursive = TRUE,
  showWarnings = FALSE
)

# ==============================================================================
# 2. Helpers
# ==============================================================================

standardize_country_name <- function(x) {
  recode(
    as.character(x),
    "Czech Republic" = "Czechia",
    "Turkiye" = "Türkiye",
    "Turkey" = "Türkiye",
    "Slovak Republic" = "Slovakia",
    "Russian Federation" = "Russia",
    .default = as.character(x)
  )
}

standardize_disease <- function(x) {
  x <- tolower(
    trimws(
      as.character(x)
    )
  )

  case_when(
    x %in% c(
      "aiv",
      "ai",
      "aiv_poultry",
      "avian influenza",
      "avian influenza in poultry",
      "avian influenza poultry"
    ) ~ "aiv_poultry",

    x %in% c(
      "asf",
      "african swine fever"
    ) ~ "asf",

    TRUE ~ x
  )
}

rank_scale <- function(
    x,
    lower = 0.05,
    upper = 0.95
) {
  output <- rep(
    NA_real_,
    length(x)
  )

  usable <- is.finite(x)

  if (
    sum(
      usable
    ) < 2L
  ) {
    return(
      output
    )
  }

  x_use <- x[
    usable
  ]

  if (
    length(
      unique(
        x_use
      )
    ) == 1L
  ) {
    output[usable] <-
      (
        lower +
          upper
      ) /
      2

    return(
      output
    )
  }

  output[usable] <-
    lower +
    (
      upper -
        lower
    ) *
    (
      rank(
        x_use,
        ties.method = "average"
      ) -
        1
    ) /
    (
      length(
        x_use
      ) -
        1
    )

  output
}

check_required_columns <- function(
    data,
    required_columns,
    object_name
) {
  missing_columns <- setdiff(
    required_columns,
    names(
      data
    )
  )

  if (
    length(
      missing_columns
    ) > 0L
  ) {
    stop(
      object_name,
      " is missing required columns: ",
      paste(
        missing_columns,
        collapse = ", "
      ),
      call. = FALSE
    )
  }
}

check_unique_keys <- function(
    data,
    keys,
    object_name
) {
  duplicates <- data %>%
    count(
      across(
        all_of(
          keys
        )
      )
    ) %>%
    filter(
      n != 1L
    )

  if (
    nrow(
      duplicates
    ) > 0L
  ) {
    stop(
      object_name,
      " must contain exactly one row per ",
      paste(
        keys,
        collapse = " × "
      ),
      ".",
      call. = FALSE
    )
  }
}

# ==============================================================================
# 3. Read and validate IRT results
# ==============================================================================

if (
  !file.exists(
    input_file
  )
) {
  stop(
    "Required IRT factor-score file was not found: ",
    input_file,
    call. = FALSE
  )
}

irt <- read_csv(
  input_file,
  show_col_types = FALSE,
  progress = FALSE
)

check_required_columns(
  irt,
  c(
    "country_name",
    "disease",
    "model",
    "score",
    "score_se"
  ),
  "raw_irt_factor_scores_long.csv"
)

irt <- irt %>%
  transmute(
    country_name =
      standardize_country_name(
        country_name
      ),
    disease =
      standardize_disease(
        disease
      ),
    model =
      as.character(
        model
      ),
    score =
      as.numeric(
        score
      ),
    score_se =
      as.numeric(
        score_se
      )
  ) %>%
  filter(
    model ==
      analysis_model,
    disease %in%
      required_diseases
  )

check_unique_keys(
  irt,
  c(
    "country_name",
    "disease"
  ),
  "IRT results"
)

missing_diseases <- setdiff(
  required_diseases,
  unique(
    irt$disease
  )
)

if (
  length(
    missing_diseases
  ) > 0L
) {
  stop(
    "IRT results are missing required diseases: ",
    paste(
      missing_diseases,
      collapse = ", "
    ),
    call. = FALSE
  )
}

if (
  anyNA(
    irt$score
  ) ||
    anyNA(
      irt$score_se
    ) ||
    any(
      !is.finite(
        irt$score
      )
    ) ||
    any(
      !is.finite(
        irt$score_se
      )
    ) ||
    any(
      irt$score_se < 0
    )
) {
  stop(
    "IRT scores and posterior SEs must be complete, finite, and valid.",
    call. = FALSE
  )
}

# ==============================================================================
# 4. Construct disease-specific Preparedness capacity indices
# ==============================================================================

irt_indexed <- irt %>%
  group_by(
    disease
  ) %>%
  mutate(
    preparedness_capacity_index =
      100 *
      rank_scale(
        score
      )
  ) %>%
  ungroup()

# ==============================================================================
# 5. Shared anonymous-country key
# ==============================================================================

country_key <- irt_indexed %>%
  group_by(
    country_name
  ) %>%
  summarise(
    preparedness_capacity_mean =
      mean(
        preparedness_capacity_index,
        na.rm = TRUE
      ),
    .groups =
      "drop"
  ) %>%
  mutate(
    preparedness_capacity_rank =
      rank(
        -preparedness_capacity_mean,
        ties.method = "average",
        na.last = "keep"
      )
  ) %>%
  arrange(
    preparedness_capacity_rank,
    country_name
  ) %>%
  mutate(
    Country =
      paste0(
        "Country ",
        sprintf(
          "%02d",
          row_number()
        )
      )
  ) %>%
  select(
    country_name,
    Country
  )

if (
  nrow(
    country_key
  ) != expected_n_countries
) {
  stop(
    "Expected ",
    expected_n_countries,
    " unique countries, but found ",
    nrow(
      country_key
    ),
    ".",
    call. = FALSE
  )
}

check_unique_keys(
  country_key,
  "country_name",
  "Anonymous-country key"
)

irt_indexed <- irt_indexed %>%
  left_join(
    country_key,
    by = "country_name",
    relationship = "many-to-one"
  )

if (
  anyNA(
    irt_indexed$Country
  )
) {
  stop(
    "At least one IRT result could not be matched to the anonymous-country key.",
    call. = FALSE
  )
}

# ==============================================================================
# 6. Build supplementary table
# ==============================================================================

ai_table <- irt_indexed %>%
  filter(
    disease ==
      "aiv_poultry"
  ) %>%
  transmute(
    Country,
    `AI latent Preparedness capacity (MAP)` =
      round(
        score,
        3
      ),
    `AI posterior SE` =
      round(
        score_se,
        3
      ),
    `AI Preparedness capacity index` =
      round(
        preparedness_capacity_index,
        1
      )
  )

asf_table <- irt_indexed %>%
  filter(
    disease ==
      "asf"
  ) %>%
  transmute(
    Country,
    `ASF latent Preparedness capacity (MAP)` =
      round(
        score,
        3
      ),
    `ASF posterior SE` =
      round(
        score_se,
        3
      ),
    `ASF Preparedness capacity index` =
      round(
        preparedness_capacity_index,
        1
      )
  )

supplementary_table <- country_key %>%
  select(
    Country
  ) %>%
  left_join(
    ai_table,
    by = "Country",
    relationship = "one-to-one"
  ) %>%
  left_join(
    asf_table,
    by = "Country",
    relationship = "one-to-one"
  ) %>%
  mutate(
    country_number =
      as.integer(
        sub(
          "Country ",
          "",
          Country
        )
      )
  ) %>%
  arrange(
    country_number
  ) %>%
  select(
    -country_number
  )

# ==============================================================================
# 7. Export
# ==============================================================================

write_csv(
  supplementary_table,
  output_file,
  na = ""
)

message(
  "\nIRT table completed.\n",
  "Output:\n  ",
  output_file,
  "\n"
)
