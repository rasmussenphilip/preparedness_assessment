# ==============================================================================
# 14_plot_chord_diagram.R
#
# PURPOSE
# Plot the conceptual mapping of questionnaire items across the three
# preparedness domains:
# - Veterinary workforce and education
# - Monitoring and surveillance
# - Emergency response
#
# All mapped questionnaire items contribute to the single overall Preparedness
# capacity IRT model. The three domains shown here are conceptual mappings for
# interpretation and display; they are not separately fitted IRT models.
#
# INPUT
# data/mapping.xlsx
#
# OUTPUT
# results/plots/chord_diagrams/preparedness_capacity_item_mapping.png
# ==============================================================================

suppressPackageStartupMessages({
  library(dplyr)
  library(tidyr)
  library(readxl)
  library(circlize)
})

# ==============================================================================
# 1. Input and output paths
# ==============================================================================

# `mapping.xlsx` is the authoritative source of questionnaire-item definitions
# and preparedness-domain assignments used by this visualization.

mapping_file <- file.path("data", "mapping.xlsx")
output_dir <- file.path("results", "plots", "chord_diagrams")

dir.create(
  output_dir,
  recursive = TRUE,
  showWarnings = FALSE
)

# ==============================================================================
# 2. User-adjustable figure settings
# ==============================================================================

# The settings in this section control display only. They do not alter the
# underlying item-to-domain mappings in `mapping.xlsx`.

# Display labels for the three preparedness domains. Change only the
# right-hand text if figure wording needs revision. The names `wor`, `mas`, and
# `res` are fixed internal domain-mapping codes from `mapping.xlsx`.
component_names <- c(
  wor = "Workforce\nand education",
  mas = "Monitoring and\nsurveillance",
  res = "Emergency\nresponse"
)

# Component colors are keyed to the fixed mapping codes. These colors are carried
# primarily by the ribbons; item sectors remain neutral/white.
component_colors <- c(
  wor = "#65CCFF",
  mas = "#FF99BF",
  res = "#95CC5E"
)

# Clockwise component-sector order within the component block. The entire block
# is centered at the top of the circle later in `plot_chord()`.
component_order <- c(
  "wor",
  "mas",
  "res"
)

# Figure title. Set to NULL to omit the title.
figure_title <-
  "Conceptual mappings across questionnaire items"

# Figure subtitle. The overall IRT model is fitted once; colored links
# show the three conceptual preparedness domains used for interpretation.
figure_subtitle <-
  paste0(
    "Colored links show conceptual questionnaire item mappings across three preparedness domains;\n",
    "Items marked with an astrisk (*) have disease- and/or species-specific variants"
  )

# Title/subtitle placement. More negative values move the text farther
# down, closer to the chord diagram.
figure_title_line <- 2
figure_title_cex <- 1.6

figure_subtitle_line <- -0.5
figure_subtitle_cex <- 1

# Spacing in degrees.
component_gap <- 6
item_gap <- 3
block_gap <- 20

# Label sizes.
component_label_cex <- 1
item_label_cex <- 0.9

# Target number of lines for automatically wrapped questionnaire definitions.
# Labels with at least four words use exactly four lines; shorter labels cannot
# use more lines than they contain words.
item_label_lines <- 4L

# Output dimensions.
figure_width <- 10
figure_height <- 10
figure_dpi <- 600

# ==============================================================================
# 3. Mapping-preparation, label, device, and plotting helpers
# ==============================================================================

# ------------------------------------------------------------------------------
# 3.1 Manual item-label wrapping overrides
# ------------------------------------------------------------------------------

# Selected labels use manual line breaks for improved readability.
# All other labels are wrapped automatically below.
manual_item_wraps <- c(
  "Number of veterinary graduates" =
    "Number of\nveterinary\ngraduates",

  "Number of licensed veterinarians" =
    "Number of\nlicensed\nveterinarians",

  "Data collected on graduate retention" =
    "Data collected\non graduate\nretention",

  "Frequency of training exercises" =
    "Frequency of\ntraining\nexercises",

  "Dedicated vehicles (live animals)" =
    "Dedicated\nvehicles\n(live animals)"
)

# Split a label into a requested number of balanced lines while
# preserving word order. Manual overrides above are applied first.
# ------------------------------------------------------------------------------
# 3.2 Automatically wrap an item definition into balanced lines
# ------------------------------------------------------------------------------

# Manual overrides are checked first. Otherwise, evaluate all possible
# word-boundary partitions for the requested number of lines and select the
# lowest-scoring (most balanced) arrangement.
wrap_balanced_lines <- function(text, n_lines = 4L) {
  text <- trimws(as.character(text))

  if (is.na(text) || text == "") {
    return(text)
  }

  if (text %in% names(manual_item_wraps)) {
    return(unname(manual_item_wraps[[text]]))
  }

  words <- strsplit(text, "\\s+")[[1]]
  n_words <- length(words)

  # Use the requested number of lines whenever enough words are
  # available. Labels with fewer words use one word per line.
  n_lines <- min(
    max(1L, as.integer(n_lines)),
    n_words
  )

  if (n_lines == 1L) {
    return(text)
  }

  # Choose n_lines - 1 split positions from the spaces between words.
  # All valid arrangements are assessed, and the most balanced set of
  # lines is retained while preserving the original word order.
  split_candidates <- combn(
    seq_len(n_words - 1L),
    n_lines - 1L,
    simplify = FALSE
  )

  candidates <- lapply(
    split_candidates,
    function(breaks) {
      starts <- c(1L, breaks + 1L)
      ends <- c(breaks, n_words)

      lines <- vapply(
        seq_len(n_lines),
        function(i) {
          paste(
            words[starts[i]:ends[i]],
            collapse = " "
          )
        },
        character(1)
      )

      lengths <- nchar(lines)

      # First minimize the longest line, then favor similar line lengths.
      score <- max(lengths) * 100 +
        stats::sd(lengths) * 10 +
        (max(lengths) - min(lengths))

      list(
        lines = lines,
        score = score
      )
    }
  )

  best_index <- which.min(
    vapply(
      candidates,
      function(x) x$score,
      numeric(1)
    )
  )

  paste(
    candidates[[best_index]]$lines,
    collapse = "\n"
  )
}

# ------------------------------------------------------------------------------
# 3.3 Read and validate the mapping workbook
# ------------------------------------------------------------------------------

# Require the three fields needed by the figure. Additional workbook columns are
# allowed but ignored by this script.
read_mapping <- function(path) {
  if (!file.exists(path)) {
    stop(
      "Required mapping file was not found: ",
      path,
      call. = FALSE
    )
  }

  mapping <- read_excel(path)

  required_columns <- c(
    "item",
    "model",
    "definition"
  )

  missing_columns <- setdiff(
    required_columns,
    names(mapping)
  )

  if (length(missing_columns) > 0L) {
    stop(
      "mapping.xlsx is missing required columns: ",
      paste(missing_columns, collapse = ", "),
      call. = FALSE
    )
  }

  mapping
}

# ------------------------------------------------------------------------------
# 3.4 Normalize displayed questionnaire definitions
# ------------------------------------------------------------------------------

# Trim leading/trailing whitespace and collapse repeated internal whitespace so
# visually identical definitions are recognized as the same conceptual item.
normalize_definition <- function(x) {
  x <- trimws(as.character(x))
  x <- gsub("\\s+", " ", x)
  x
}

# Identify source variables that are explicitly disease- or species-specific.
# The pipeline uses ASF/pig and AI/poultry tokens in questionnaire item codes.
is_disease_or_species_specific <- function(item_code) {
  grepl(
    "(^|_)(asf|aiv|pig|pou)(_|$)",
    as.character(item_code),
    ignore.case = TRUE
  )
}

# ------------------------------------------------------------------------------
# 3.5 Convert workbook rows into chord links and displayed item sectors
# ------------------------------------------------------------------------------

# Expand multiple domain assignments, validate mapping codes, collapse
# identical displayed definitions, remove duplicate definition-component links,
# and create wrapped labels keyed to anonymous internal item-sector IDs.
prepare_mapping <- function(mapping) {
  prepared <- mapping %>%
    transmute(
      item = trimws(as.character(item)),
      model = as.character(model),
      definition = normalize_definition(definition),
      disease_or_species_specific =
        is_disease_or_species_specific(item)
    ) %>%
    filter(
      item != "",
      !is.na(definition),
      definition != ""
    ) %>%
    mutate(
      # Normalize apostrophes and other separators before expanding
      # multiple component assignments.
      model = gsub(
        "['’|,/]",
        ";",
        model
      ),
      model = gsub(
        "\\s+",
        "",
        model
      )
    ) %>%
    separate_rows(
      model,
      sep = ";"
    ) %>%
    mutate(
      model = tolower(trimws(model)),
      value = 1
    ) %>%
    filter(
      model != ""
    )

  invalid_codes <- prepared %>%
    filter(
      !model %in% component_order
    ) %>%
    distinct(model) %>%
    pull(model)

  if (length(invalid_codes) > 0L) {
    stop(
      "Unrecognized preparedness-domain mapping codes in mapping.xlsx: ",
      paste(invalid_codes, collapse = ", "),
      call. = FALSE
    )
  }

  # Assign a neutral internal sector ID to each unique normalized definition.
  # These IDs keep circlize sector names short and unique while the publication
  # labels remain the human-readable definitions.
  #
  # Rows with the same displayed definition are represented by one item sector.
  # Duplicate definition-component links are reduced to one link.
  definition_key <- prepared %>%
    group_by(definition) %>%
    summarise(
      disease_or_species_specific =
        any(disease_or_species_specific),
      .groups = "drop"
    ) %>%
    arrange(definition) %>%
    mutate(
      item_sector = paste0(
        "item_",
        sprintf("%02d", row_number())
      )
    )

  links <- prepared %>%
    left_join(
      definition_key,
      by = "definition"
    ) %>%
    distinct(
      model,
      item_sector,
      .keep_all = TRUE
    ) %>%
    transmute(
      component = model,
      item = item_sector,
      value
    )

  list(
    links = links,
    item_labels = setNames(
      ifelse(
        definition_key$disease_or_species_specific,
        paste0(
          vapply(
            definition_key$definition,
            wrap_balanced_lines,
            character(1),
            n_lines = item_label_lines
          ),
          "*"
        ),
        vapply(
          definition_key$definition,
          wrap_balanced_lines,
          character(1),
          n_lines = item_label_lines
        )
      ),
      definition_key$item_sector
    )
  )
}

# ------------------------------------------------------------------------------
# 3.6 Order displayed item sectors by preparedness-domain membership
# ------------------------------------------------------------------------------

# Arrange items along the arc from the emergency-response side toward the
# workforce/education side. Single-component items sit nearest their component;
# shared items are positioned between relevant component groups.
order_items_by_component <- function(links) {
  membership_order <- c(
    "res",
    "mas|res",
    "mas",
    "wor|mas|res",
    "wor|res",
    "wor|mas",
    "wor"
  )

  links %>%
    distinct(item, component) %>%
    mutate(
      component = factor(
        component,
        levels = component_order
      )
    ) %>%
    arrange(item, component) %>%
    group_by(item) %>%
    summarise(
      membership = paste(
        as.character(component),
        collapse = "|"
      ),
      .groups = "drop"
    ) %>%
    mutate(
      membership_rank = match(
        membership,
        membership_order
      ),
      membership_rank = if_else(
        is.na(membership_rank),
        length(membership_order) + 1L,
        membership_rank
      )
    ) %>%
    arrange(
      membership_rank,
      item
    ) %>%
    pull(item)
}

# ------------------------------------------------------------------------------
# 3.7 Open the requested graphics device
# ------------------------------------------------------------------------------

# PNG is the final output format. TIFF support is retained as a convenience for
# possible publication/export requirements without changing plotting logic.
open_device <- function(path, format) {
  if (format == "png") {
    png(
      filename = path,
      width = figure_width,
      height = figure_height,
      units = "in",
      res = figure_dpi,
      bg = "white"
    )
  } else if (format == "tiff") {
    tiff(
      filename = path,
      width = figure_width,
      height = figure_height,
      units = "in",
      res = figure_dpi,
      compression = "lzw",
      bg = "white"
    )
  } else {
    stop(
      "Unsupported output format: ",
      format,
      call. = FALSE
    )
  }
}

# ------------------------------------------------------------------------------
# 3.8 Draw and export the chord diagram
# ------------------------------------------------------------------------------

# Construct sector order, gaps, start angle, directional ribbons, custom labels,
# and title/subtitle on the selected graphics device.
plot_chord <- function(mapping_object, format) {
  links <- mapping_object$links
  item_labels <- mapping_object$item_labels

  items <- order_items_by_component(
    links
  )

  all_sectors <- c(
    component_order,
    items
  )

  # Colours are keyed to internal sector names. The item colours are
  # neutral because the ribbons carry the component colour coding.
  sector_colors <- c(
    component_colors[component_order],
    setNames(
      rep("#FFFFFF", length(items)),
      items
    )
  )

  output_path <- file.path(
    output_dir,
    paste0(
      "preparedness_capacity_item_mapping.",
      format
    )
  )

  open_device(
    output_path,
    format
  )

  # Guarantee that circlize's global plotting state is reset and the graphics
  # device is closed even if an error occurs later in the plotting routine.
  on.exit(
    {
      circos.clear()
      dev.off()
    },
    add = TRUE
  )

  circos.clear()

  # `gap.after` requires one angular gap after every sector. Use small gaps
  # within each block and large gaps at the two component/item boundaries.
  gap_after <- c(
    rep(
      component_gap,
      length(component_order) - 1L
    ),
    block_gap,
    rep(
      item_gap,
      length(items) - 1L
    ),
    block_gap
  )

  # Compute the angular width available to actual sectors after all configured
  # gaps are removed. Because `scale = TRUE` is used below, this calculation is
  # used specifically to determine the centering start angle.
  available_degrees <- 360 - sum(gap_after)
  sector_width <- available_degrees / length(all_sectors)

  component_block_width <-
    length(component_order) * sector_width +
    (length(component_order) - 1L) * component_gap

  # circlize proceeds clockwise, so this centers the complete three-
  # component block at 12 o'clock.
  start_degree <- 90 + component_block_width / 2

  par(
    mar = c(0.5, 0.5, 5.0, 0.5),
    oma = c(0, 0, 0, 0),
    xpd = NA
  )

  circos.par(
    start.degree = start_degree,
    gap.after = gap_after,
    track.margin = c(0.005, 0.005),
    cell.padding = c(0, 0, 0, 0),
    canvas.ylim = c(-1.10, 0.90)
  )

  # Draw only ribbons here (`annotationTrack = NULL`). Sector labels are added
  # manually in the preallocated track so component and item labels can use
  # different orientation and typography.
  chordDiagram(
    x = links,
    order = all_sectors,
    directional = TRUE,
    direction.type = "diffHeight",
    link.arr.type = "big.arrow",
    annotationTrack = NULL,
    preAllocateTracks = list(
      track.height = 0.16
    ),
    link.sort = TRUE,
    link.largest.ontop = FALSE,
    link.lwd = 0.5,
    link.lty = 1,
    link.border = 1,
    transparency = 0.2,
    scale = TRUE,
    grid.col = sector_colors
  )

  # ----------------------------------------------------------
  # CUSTOM LABELS
  # ----------------------------------------------------------

  circos.trackPlotRegion(
    track.index = 1,
    bg.border = NA,
    panel.fun = function(x, y) {
      sector_name <- CELL_META$sector.index
      x_center <- CELL_META$xcenter
      y_center <- CELL_META$ylim[1]

      # Component sectors receive bold inward-facing multiline labels; item
      # sectors receive clockwise, automatically flipped definition labels.
      if (sector_name %in% component_order) {
        circos.text(
          x = x_center,
          y = y_center,
          labels = unname(
            component_names[sector_name]
          ),
          facing = "inside",
          niceFacing = FALSE,
          adj = c(0.5, 0),
          cex = component_label_cex,
          font = 2
        )
      } else {
        circos.text(
          x = x_center,
          y = y_center,
          labels = unname(
            item_labels[sector_name]
          ),
          facing = "clockwise",
          niceFacing = TRUE,
          adj = c(0, 0.5),
          cex = item_label_cex,
          font = 1
        )
      }
    }
  )

# Title and subtitle are drawn with base-graphics `mtext()` after circlize has
  # finished the chord and labels. This makes their vertical positions tunable
  # independently of the circular plotting coordinates.
  if (!is.null(figure_title) && nzchar(figure_title)) {
    # Draw the title relative to the main plotting region rather than
    # the outer device margin. xpd = NA prevents clipping.
    mtext(
      figure_title,
      side = 3,
      outer = FALSE,
      line = figure_title_line,
      cex = figure_title_cex,
      font = 2
    )
  }

  if (!is.null(figure_subtitle) && nzchar(figure_subtitle)) {
    mtext(
      figure_subtitle,
      side = 3,
      outer = FALSE,
      line = figure_subtitle_line,
      cex = figure_subtitle_cex,
      font = 1
    )
  }

  invisible(output_path)
}

# ==============================================================================
# 4. Validate settings, prepare the mapping, and generate the final figure
# ==============================================================================

# Perform final configuration/mapping checks before opening the graphics device.
# The final workflow exports PNG only.

# The displayed-name vector must remain keyed to the exact internal component
# order expected throughout the plotting code.
if (
  !identical(
    names(component_names),
    component_order
  )
) {
  stop(
    "component_names must be named wor, mas, and res in that order.",
    call. = FALSE
  )
}

if (
  anyNA(component_names) ||
  any(trimws(component_names) == "")
) {
  stop(
    "All three component_names values must be non-empty.",
    call. = FALSE
  )
}

# Read the authoritative workbook only after validating the display settings.
mapping_raw <- read_mapping(
  mapping_file
)

# Convert raw workbook rows to unique displayed item sectors and component-item
# chord links.
mapping_object <- prepare_mapping(
  mapping_raw
)

# A valid final figure must contain at least one mapping for every required
# preparedness domain.
missing_components <- setdiff(
  component_order,
  unique(mapping_object$links$component)
)

if (length(missing_components) > 0L) {
  stop(
    "mapping.xlsx does not contain all three required components: ",
    paste(missing_components, collapse = ", "),
    call. = FALSE
  )
}

# Final production export. The helper also supports TIFF, but the pipeline
# intentionally writes only the PNG figure.
plot_chord(
  mapping_object,
  "png"
)

message(
  "\nChord diagram completed successfully.\n",
  "Definitions displayed: ",
  length(mapping_object$item_labels),
  "\n",
  "Definition-component links displayed: ",
  nrow(mapping_object$links),
  "\n",
  "Outputs written to: ",
  output_dir,
  "\n"
)
