# ==============================================================================
# 03_irt_preparation.R
#
# PURPOSE
# Prepare the disease-specific questionnaire datasets and overall Preparedness
# capacity item specifications used by Script 04.
#
# INPUTS
# data/exported/data_primary_long.csv
# data/exported/irt_items.rds
#
# OUTPUTS
# data/exported/data_primary_long_asf.csv
# data/exported/irt_model_specification_asf.rds
# data/exported/data_primary_long_aiv_poultry.csv
# data/exported/irt_model_specification_aiv_poultry.rds
# ==============================================================================

suppressPackageStartupMessages({
  library(dplyr)
})

# ==============================================================================
# 1. Paths and settings
# ==============================================================================

export_dir <- file.path("data", "exported")

primary_file <- file.path(
  export_dir,
  "data_primary_long.csv"
)

item_specification_file <- file.path(
  export_dir,
  "irt_items.rds"
)

required_diseases <- c("asf", "aiv")

dir.create(
  export_dir,
  recursive = TRUE,
  showWarnings = FALSE
)

# ==============================================================================
# 2. Helpers
# ==============================================================================

convert_to_graded <- function(x, bins = 5L) {
  x <- as.numeric(x)
  observed <- x[!is.na(x)]

  if (length(observed) == 0L) {
    return(rep(NA_integer_, length(x)))
  }

  if (length(unique(observed)) == 1L) {
    return(ifelse(is.na(x), NA_integer_, 1L))
  }

  breaks <- unique(
    quantile(
      observed,
      probs = seq(0, 1, length.out = bins + 1L),
      na.rm = TRUE,
      names = FALSE,
      type = 7
    )
  )

  if (length(breaks) < 2L) {
    return(ifelse(is.na(x), NA_integer_, 1L))
  }

  as.integer(
    cut(
      x,
      breaks = breaks,
      labels = FALSE,
      include.lowest = TRUE,
      right = TRUE
    )
  )
}

graded_item_name <- function(x) {
  sub("^n_", "g_", x)
}

# ==============================================================================
# 3. Read and validate inputs
# ==============================================================================

required_files <- c(
  primary_file,
  item_specification_file
)

missing_files <- required_files[!file.exists(required_files)]

if (length(missing_files) > 0L) {
  stop(
    "The following required input files are missing: ",
    paste(missing_files, collapse = ", "),
    call. = FALSE
  )
}

primary_data <- read.csv(
  primary_file,
  stringsAsFactors = FALSE,
  check.names = FALSE
)

item_specification <- readRDS(
  item_specification_file
)

if (!"country_name" %in% names(primary_data)) {
  stop(
    "data_primary_long.csv must contain country_name.",
    call. = FALSE
  )
}

if (anyDuplicated(primary_data$country_name) > 0L) {
  stop(
    "data_primary_long.csv contains duplicate country names.",
    call. = FALSE
  )
}

if (!"overall_items" %in% names(item_specification)) {
  stop(
    "irt_items.rds must contain overall_items.",
    call. = FALSE
  )
}

missing_diseases <- setdiff(
  required_diseases,
  names(item_specification$overall_items)
)

if (length(missing_diseases) > 0L) {
  stop(
    "IRT item specifications are missing: ",
    paste(missing_diseases, collapse = ", "),
    call. = FALSE
  )
}

# ==============================================================================
# 4. Prepare one disease
# ==============================================================================

prepare_disease_data <- function(disease) {
  disease <- match.arg(
    disease,
    required_diseases
  )

  overall_items_original <- unique(
    item_specification$overall_items[[disease]]
  )

  if (length(overall_items_original) == 0L) {
    stop(
      disease,
      ": overall Preparedness capacity item list is empty.",
      call. = FALSE
    )
  }

  missing_items <- setdiff(
    overall_items_original,
    names(primary_data)
  )

  if (length(missing_items) > 0L) {
    stop(
      disease,
      ": items missing from data_primary_long.csv: ",
      paste(missing_items, collapse = ", "),
      call. = FALSE
    )
  }

  disease_primary <- primary_data %>%
    select(
      country_name,
      all_of(overall_items_original)
    )

  if ("g_operational_agreements" %in% names(disease_primary)) {
    x <- disease_primary$g_operational_agreements

    invalid <- !is.na(x) & (
      x < 0 |
        x > 5 |
        x != floor(x)
    )

    if (any(invalid)) {
      stop(
        disease,
        ": g_operational_agreements must contain integers from 0 to 5.",
        call. = FALSE
      )
    }
  }

  continuous_items <- names(disease_primary)[
    startsWith(names(disease_primary), "n_")
  ]

  if (length(continuous_items) > 0L) {
    disease_primary[continuous_items] <- lapply(
      disease_primary[continuous_items],
      convert_to_graded
    )

    names(disease_primary) <- graded_item_name(
      names(disease_primary)
    )
  }

  overall_items_final <- graded_item_name(
    overall_items_original
  )

  missing_final_items <- setdiff(
    overall_items_final,
    names(disease_primary)
  )

  if (length(missing_final_items) > 0L) {
    stop(
      disease,
      ": post-grading item names are missing: ",
      paste(missing_final_items, collapse = ", "),
      call. = FALSE
    )
  }

  invalid_prefix <- overall_items_final[
    !startsWith(overall_items_final, "b_") &
      !startsWith(overall_items_final, "g_")
  ]

  if (length(invalid_prefix) > 0L) {
    stop(
      disease,
      ": final IRT items must begin with b_ or g_: ",
      paste(invalid_prefix, collapse = ", "),
      call. = FALSE
    )
  }

  final_specification <- list(
    disease = disease,
    overall_items = overall_items_final
  )

  if (disease == "asf") {
    primary_output <- file.path(
      export_dir,
      "data_primary_long_asf.csv"
    )

    specification_output <- file.path(
      export_dir,
      "irt_model_specification_asf.rds"
    )
  } else {
    primary_output <- file.path(
      export_dir,
      "data_primary_long_aiv_poultry.csv"
    )

    specification_output <- file.path(
      export_dir,
      "irt_model_specification_aiv_poultry.rds"
    )
  }

  write.csv(
    disease_primary,
    primary_output,
    row.names = FALSE
  )

  saveRDS(
    final_specification,
    specification_output
  )

  invisible(final_specification)
}

# ==============================================================================
# 5. Run both disease preparations
# ==============================================================================

prepare_disease_data("asf")
prepare_disease_data("aiv")

message(
  "\nIRT preparation completed.\n",
  "Outputs:\n",
  "  ", file.path(export_dir, "data_primary_long_asf.csv"), "\n",
  "  ", file.path(export_dir, "irt_model_specification_asf.rds"), "\n",
  "  ", file.path(export_dir, "data_primary_long_aiv_poultry.csv"), "\n",
  "  ", file.path(export_dir, "irt_model_specification_aiv_poultry.rds"), "\n"
)
