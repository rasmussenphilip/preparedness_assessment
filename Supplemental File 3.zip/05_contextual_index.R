# ==============================================================================
# 05_contextual_index.R
#
# PURPOSE
# Construct the disease-independent Contextual Index from four country-level
# socioeconomic and institutional variables.
#
# INPUT
# data/exported/data_secondary.csv
#
# OUTPUTS
# results/indices/contextual_index.csv
# results/indices/contextual_diagnostics/contextual_component_breakdown.csv
# ==============================================================================

suppressPackageStartupMessages({
  library(dplyr)
  library(readr)
})

# ==============================================================================
# 1. Paths and settings
# ==============================================================================

input_file <- file.path(
  "data",
  "exported",
  "data_secondary.csv"
)

output_dir <- file.path(
  "results",
  "indices"
)

diagnostics_dir <- file.path(
  output_dir,
  "contextual_diagnostics"
)

scale_lower <- 0.05
scale_upper <- 0.95

context_variables <- c(
  "gdppc_ppp",
  "ge_score",
  "adv_ed",
  "health_exp_pc_ppp"
)

dir.create(
  output_dir,
  recursive = TRUE,
  showWarnings = FALSE
)

dir.create(
  diagnostics_dir,
  recursive = TRUE,
  showWarnings = FALSE
)

# ==============================================================================
# 2. Helpers
# ==============================================================================

rank_scale <- function(
    x,
    lower = scale_lower,
    upper = scale_upper
) {
  if (!is.numeric(x)) {
    stop(
      "rank_scale() requires a numeric vector.",
      call. = FALSE
    )
  }

  if (
    anyNA(x) ||
      any(!is.finite(x))
  ) {
    stop(
      "rank_scale() cannot process missing or non-finite values.",
      call. = FALSE
    )
  }

  n <- length(x)

  if (n < 2L) {
    stop(
      "At least two observations are required for rank scaling.",
      call. = FALSE
    )
  }

  if (length(unique(x)) == 1L) {
    return(
      rep(
        (lower + upper) / 2,
        n
      )
    )
  }

  lower +
    (upper - lower) *
    (rank(x, ties.method = "average") - 1) /
    (n - 1)
}

# ==============================================================================
# 3. Read and validate input
# ==============================================================================

if (!file.exists(input_file)) {
  stop(
    "Required input file was not found: ",
    input_file,
    call. = FALSE
  )
}

secondary_data <- read_csv(
  input_file,
  show_col_types = FALSE,
  progress = FALSE
)

required_columns <- c(
  "country_name",
  context_variables
)

missing_columns <- setdiff(
  required_columns,
  names(secondary_data)
)

if (length(missing_columns) > 0L) {
  stop(
    "data_secondary.csv is missing required columns: ",
    paste(missing_columns, collapse = ", "),
    call. = FALSE
  )
}

context_data <- secondary_data %>%
  select(
    all_of(required_columns)
  )

if (anyDuplicated(context_data$country_name) > 0L) {
  stop(
    "data_secondary.csv contains duplicate country names.",
    call. = FALSE
  )
}

non_numeric <- context_variables[
  !vapply(
    context_data[context_variables],
    is.numeric,
    logical(1)
  )
]

if (length(non_numeric) > 0L) {
  stop(
    "Context variables must be numeric: ",
    paste(non_numeric, collapse = ", "),
    call. = FALSE
  )
}

invalid_values <- context_variables[
  vapply(
    context_data[context_variables],
    function(x) {
      anyNA(x) ||
        any(!is.finite(x))
    },
    logical(1)
  )
]

if (length(invalid_values) > 0L) {
  stop(
    "Context variables contain missing or non-finite values: ",
    paste(invalid_values, collapse = ", "),
    call. = FALSE
  )
}

# ==============================================================================
# 4. Scale components and construct the Contextual Index
# ==============================================================================

contextual_components <- context_data %>%
  mutate(
    gdp_scaled = rank_scale(gdppc_ppp),
    governance_scaled = rank_scale(ge_score),
    education_scaled = rank_scale(adv_ed),
    health_scaled = rank_scale(health_exp_pc_ppp)
  )

contextual_index <- contextual_components %>%
  mutate(
    contextual_score = exp(
      (
        log(gdp_scaled) +
          log(governance_scaled) +
          log(education_scaled) +
          log(health_scaled)
      ) / 4
    ),
    contextual_index = 100 * contextual_score,
    contextual_rank = rank(
      -contextual_index,
      ties.method = "min"
    ),
    contextual_percentile = if (n() > 1L) {
      100 *
        (n() - contextual_rank) /
        (n() - 1)
    } else {
      100
    }
  ) %>%
  select(
    country_name,
    contextual_score,
    contextual_index,
    contextual_rank,
    contextual_percentile
  ) %>%
  arrange(
    contextual_rank,
    country_name
  )

if (
  any(
    contextual_index$contextual_index <
      100 * scale_lower - 1e-10 |
      contextual_index$contextual_index >
        100 * scale_upper + 1e-10
  )
) {
  stop(
    "Contextual Index values fall outside the expected 5-95 range.",
    call. = FALSE
  )
}

contextual_component_breakdown <- contextual_components %>%
  left_join(
    contextual_index,
    by = "country_name"
  ) %>%
  select(
    country_name,
    contextual_score,
    contextual_index,
    contextual_rank,
    contextual_percentile,
    gdppc_ppp,
    ge_score,
    adv_ed,
    health_exp_pc_ppp,
    gdp_scaled,
    governance_scaled,
    education_scaled,
    health_scaled
  ) %>%
  arrange(
    contextual_rank,
    country_name
  )

# ==============================================================================
# 5. Export retained outputs
# ==============================================================================

write_csv(
  contextual_index,
  file.path(
    output_dir,
    "contextual_index.csv"
  )
)

write_csv(
  contextual_component_breakdown,
  file.path(
    diagnostics_dir,
    "contextual_component_breakdown.csv"
  )
)

message(
  "\nContextual Index completed.\n",
  "Countries indexed: ",
  nrow(contextual_index),
  "\nOutputs:\n",
  "  ",
  file.path(output_dir, "contextual_index.csv"),
  "\n  ",
  file.path(
    diagnostics_dir,
    "contextual_component_breakdown.csv"
  ),
  "\n"
)
